#include "r8.h"
SC_MODULE(display) {
    sc_in<sc_logic> rst;        // input port 1
    sc_in<sc_logic> ck;       // clock
    sc_in<sc_logic> ce;
    sc_in<sc_logic> rs2;
    sc_in<sc_lv<LENGHTR8> > ir;
    sc_in<sc_lv<LENGHTR8> > inREG;
    sc_in<sc_lv<LENGHTR8> > D;
    sc_in<sc_lv<LENGHTR8> > Q;
    void print_result();     // method to display input port values
   
    //Constructor
    SC_CTOR(display){
	SC_METHOD(print_result); // declare print_result as SC_METHOD and 
        dont_initialize();
	sensitive << ck << rst << ce << rs2 << ir << inREG << D << Q;// make it sensitive to positive clock edge
    }
	
};
