#include "display.h"
#include "iostream.h"

//Definition of print_result method 
void display::print_result()
{
  cout << "CLOCK =" << ck.read()<<"\n"
	<<"RESET =" << rst.read()<<"\n"
	<<"CHIP ENABLE ="<< ce.read()<<"\n"
	<<"rs2:"<< rs2.read()<<"\n"
	<<"ir:"<< ir.read()<<"\n"
	<<"inREG:"<< inREG.read()<<"\n"
	<<"SOURCE1 ="<< D.read()<<"\n"
	<<"SOURCE2 ="<< Q.read()<<"\n"
	<<"Time Simulation:"<< sc_time_stamp()<<"\n"
//	<<"Time Simulation:"<< sc_simulation_time()<<"ns\n"
	<<"#################################################"<< endl; 
    
} // end of print method

