#include "test_bench.h"

void test_bench::converte(){
sc_logic auxck;
auxck=(sc_logic) clk.read();
ck.write(auxck);
}

void test_bench::resetprocessor(){
 ++cycle;
 if(cycle==2)rst.write(SC_LOGIC_1);
 else if(cycle==3)rst.write(SC_LOGIC_0);
}

void test_bench::entry(){
sc_lv<LENGHTR8> tmp, tmp1;
tmp="0001000000010001";
tmp1="0000001001010101";
 switch(cycle){
 	case 7:
		rs2.write(SC_LOGIC_0);
		ce.write(SC_LOGIC_1);
		ir.write(tmp);
		inREG.write(tmp1);
		break;
	case 9:
		rs2.write(SC_LOGIC_1);
		ce.write(SC_LOGIC_0);
		ir.write(tmp);
		break;
	case 11:
		ce.write(SC_LOGIC_1);
		break;	
	default:
		ce.write(SC_LOGIC_0);
		
 }
}
