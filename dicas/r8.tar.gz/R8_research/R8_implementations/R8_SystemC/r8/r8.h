#include <systemc.h>
#define LENGHTR8 16
#define SIMULATION_TIME 10

typedef sc_lv<4> reg4;

typedef sc_lv<16> reg16;

typedef enum instruction {add, sub, e, ou, oux, addi, subi, ldl, ldh, ld, st, sl0, sl1, sr0, sr1, notA, nop, halt, ldsp, rts, pop, push, saltoR, salto, saltoD, jsrr, jsr, jsrd};

typedef struct{
	sc_lv<2> mpc;
	sc_logic msp;
	sc_lv<2> mad;
	sc_logic mreg;
	sc_logic ms2;
	sc_logic ma;
	sc_lv<2> mb;
	sc_logic wpc;
	sc_logic wsp;
	sc_logic wir;
	sc_logic wab;
	sc_logic wula;
	sc_logic wreg;
	sc_logic wnz;
	sc_logic wcv;
	sc_logic ce;
	sc_logic rw;
	instruction ula;
}microinstruction;
