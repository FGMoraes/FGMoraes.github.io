#include "r8.h"

SC_MODULE(processador){
	//Module port declarations
	sc_in<sc_logic> rst;
	sc_in<sc_logic> ck;
	sc_out<sc_lv<LENGHTR8> > instrucao;
	sc_out<sc_lv<LENGHTR8> > endereco;

	datapath DPT("datapath");
	DPT.jflasjf();
	DPT.sgds();

	control CTR("control");
	CTR.gkdshg();
	CTR.akjh();

};
