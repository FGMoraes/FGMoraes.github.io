#include "bcregs.h"

void bcregs::chipenable(){
sc_lv<4> subv;
int i;
int t=1;
subv=ir.read().range(11,8);
for(int d=3;d>=0;d--){
if((subv[d]!='0')&&(subv[d]!='1'))t=0;
}
if(t==1){
	i=subv.to_int();
	if(wreg.read()==SC_LOGIC_1) wen[i]=SC_LOGIC_1;
	else wen[i]=SC_LOGIC_0;
}
}

void bcregs::outsource1(){
int conv, t=1;
sc_lv<LENGHTR8> iraux;
sc_lv<4> sublv;
iraux=ir.read();
sublv=iraux.range(7,4);
for(int d=3;d>=0;d--) if((sublv[d]!='0')&&(sublv[d]!='1'))t=0;
if(t==1){
conv=sublv.to_int();
source1.write(reg[conv].read());
}
}

void bcregs::outsource2(){
int conv, t=1;
sc_lv<LENGHTR8> iraux;
sc_lv<4> sublv;
iraux=ir.read();
if(rs2.read()==SC_LOGIC_0)
	sublv=iraux.range(3,0);
else
	sublv=iraux.range(11,8);
for(int d=3;d>=0;d--) if((sublv[d]!='0')&&(sublv[d]!='1'))t=0;
if(t==1){
	conv=sublv.to_int();
	source2.write(reg[conv].read());
}
}
