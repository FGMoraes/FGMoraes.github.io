#include "r8.h"

SC_MODULE(test_bench){
	//Module port declarations
	sc_in_clk clk;
	sc_out<sc_logic> ck;
	sc_out<sc_logic> rst;
	sc_out<sc_logic> ce;
	sc_out<sc_logic> rs2;
	sc_out<sc_lv<LENGHTR8> > ir;
	sc_out<sc_lv<LENGHTR8> > inREG;
	unsigned cycle;

	void converte();
	void entry();
	void resetprocessor();

	//Module constructor
	SC_CTOR(test_bench){
		cycle=0;
		//ce.write(SC_LOGIC_0);
		//rs2.write(SC_LOGIC_0);
		SC_METHOD(converte);
		sensitive << clk;
		SC_METHOD(resetprocessor);
		dont_initialize();
		sensitive << clk.pos();
		SC_METHOD(entry);
		dont_initialize();
		sensitive << clk.pos();
	}
};
