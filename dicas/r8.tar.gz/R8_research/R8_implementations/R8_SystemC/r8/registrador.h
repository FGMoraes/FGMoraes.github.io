#include "r8.h"

SC_MODULE(registrador){
	//Module port declarations
	sc_in<sc_logic> rst;
	sc_in<sc_logic> ck;
	sc_in<sc_logic> ce;
	sc_in<sc_lv<LENGHTR8> > D;
	sc_out<sc_lv<LENGHTR8> > Q;

	//Method process declarations
	void bordadescida();

	//Module constructor
	SC_CTOR(registrador){
		//register process
		SC_METHOD(bordadescida);
		//Declare sensitivity list
		sensitive << rst << ck.neg();
	}
};
