#include "r8.h"
#include "bcregs.h"
#include "display.h"
#include "test_bench.h"

#define NS * 1e-9

int sc_main(int argc, char *argv[]){
 sc_clock clk("clk", 1, SC_NS, 0.5, 0, SC_NS, true); 
 sc_signal <sc_logic> ck("ck");
 sc_signal <sc_logic> rst("rst");
 sc_signal <sc_logic> ce("ce");
 sc_signal <sc_logic> rs2("rs2");
 sc_signal <sc_lv<LENGHTR8> > ir("ir");
 sc_signal <sc_lv<LENGHTR8> > inREG("inREG");
 sc_signal <sc_lv<LENGHTR8> > D("D");
 sc_signal <sc_lv<LENGHTR8> > Q("Q");

 test_bench TB1("test_bench");
 TB1.clk(clk.signal());
 TB1.ck(ck);
 TB1.rst(rst);
 TB1.ce(ce);
 TB1.rs2(rs2);
 TB1.ir(ir);
 TB1.inREG(inREG);

 bcregs BCREGS1("bcregs");  //instance of registrador module
 BCREGS1.ck(ck);
 BCREGS1.rst(rst);
 BCREGS1.wreg(ce);
 BCREGS1.rs2(rs2);
 BCREGS1.ir(ir);
 BCREGS1.inREG(inREG);
 BCREGS1.source1(D);
 BCREGS1.source2(Q);

 display DISP("display");
 DISP.rst(rst);
 DISP.ck(ck);
 DISP.ce(ce);
 DISP.rs2(rs2);
 DISP.ir(ir);
 DISP.inREG(inREG);
 DISP.D(D);
 DISP.Q(Q);

sc_start(clk, 15);
return 0;
}
