#include "controle.h"

void controle::set_flags(){
fn.write(flag<0>.read());
fz.write(flag<1>.read());
fc.write(flag<2>.read());
fv.write(flag<3>.read());
}
void controle::set_instruction(){
sc_lv<4> ir15_12=ir.read().range(15,12);
sc_lv<4> ir3_0=ir.read().range(15,12);
sc_lv<2> ir11_10=ir.read().range(11,10);
	if(ir15_12)==0)i.write(add);
	else if(ir15_12==1)i.write(sub);
	else if(ir15_12==2)i.write(e);
	else if(ir15_12==3)i.write(ou);
	else if(ir15_12==4)i.write(oux);
	else if(ir15_12==5)i.write(addi);
	else if(ir15_12==6)i.write(subi);
	else if(ir15_12==7)i.write(ldl);
	else if(ir15_12==8)i.write(ldh);
	else if(ir15_12==9)i.write(ld);
	else if(ir15_12==10)i.write(st);
	else if((ir15_12==11)&&(ir3_0==0))i.write(sl0);
	else if((ir15_12==11)&&(ir3_0==1))i.write(sl1);
	else if((ir15_12==11)&&(ir3_0==2))i.write(sr0);
	else if((ir15_12==11)&&(ir3_0==3))i.write(sr1);
	else if((ir15_12==11)&&(ir3_0==4))i.write(notA);
	else if((ir15_12==11)&&(ir3_0==5))i.write(nop);
	else if((ir15_12==11)&&(ir3_0==6))i.write(halt);
	else if((ir15_12==11)&&(ir3_0==7))i.write(ldsp);
	else if((ir15_12==11)&&(ir3_0==8))i.write(rts);
	else if((ir15_12==11)&&(ir3_0==9))i.write(pop);
	else if((ir15_12==11)&&(ir3_0==10))i.write(push);

	else if( (ir15_12==12) && ( 
		(ir3_0==0) || 
		((ir3_0==1)&&(fn.read()==SC_LOGIC_1)) || 
		((ir3_0==2)&&(fz.read()==SC_LOGIC_1)) ||
		((ir3_0==3)&&(fc.read()==SC_LOGIC_1)) ||
		((ir3_0==4)&&(fv.read()==SC_LOGIC_1)) ) )i.write(saltoR);
	else if( (ir15_12==12) && (
		((ir3_0==5) ||
		((ir3_0==6)&&(fn.read()==SC_LOGIC_1)) ||
		((ir3_0==7)&&(fz.read()==SC_LOGIC_1)) ||
		((ir3_0==8)&&(fc.read()==SC_LOGIC_1)) ||
		((ir3_0==9)&&(fv.read()==SC_LOGIC_1)) ) )i.write(salto);
	else if( (ir15_12==13) || (
		 (ir15_12==14)&& (
		((ir11_10==0)&&(fn.read()==SC_LOGIC_1)) ||
		((ir11_10==1)&&(fz.read()==SC_LOGIC_1)) ||
		((ir11_10==2)&&(fc.read()==SC_LOGIC_1)) ||
		((ir11_10==3)&&(fv.read()==SC_LOGIC_1)) ) ) )i.write(saltoD);
	else if((ir15_12==12)&&(ir3_0==10))i.write(jsrr);
	else if((ir15_12==12)&&(ir3_0==11))i.write(jsr);
	else if(ir15_12==15)i.write(jsrd);
	else i.write(nop);
}
void controle:: set_uins_instruction(){
uins.ula.write(i);
}
void controle::set_inst_la(){
	switch(i){
		case add: case sub: case e: case ou: case oux: case notA:
		case sl0: case sr0: case sl1: case sr1:
		inst_la1.write(SC_LOGIC_1);
		break;
		default:inst_la1.write(SC_LOGIC_0);		
	}
inst_la2.write(((i==addi)||(i==subi)||(i==ldl)||(i==ldh))?SC_LOGIC_1:SC_LOGIC_0);
}
void controle::set_c_i(){
	uins.msp.write(((i==jsrr)||(i==jsr)||(i==jsrd)||(i==push))?SC_LOGIC_1:SC_LOGIC_0);
	uins.mreg.write(((i==ld)||(i==pop))?SC_LOGIC_1:SC_LOGIC_0);
	if((i==rts)||(i==pop)) uins.mb.write("01");
	else if((i==saltoR)||(i==salto)||(i==saltoD)||(i==jsrr)||(i==jsr)||(i==jsrd))uins.mb.write("10");
	else uins.mb.write("00");
}
void controle::set_change_EA(){
	if(EA==Sfetch) uins.mpc.write("10");
	else if(EA==Srts) uins.mpc.write("00");
	else uins.mpc.write("01");

	if((EA==Spush)||(EA==Ssbrt)) uins.mad.write("10");
	else if(EA==Sfetch) uins.mad.write("01");
	else uins.mad.write("00");

	if((EA==Sfetch)||(EA==Sjmp)||(Ssbrt)||(Srts))uins.wpc.write(SC_LOGIC_1);	else uins.wpc.write(SC_LOGIC_0);

	if((EA==Sldsp)||(EA==Srts)||(Ssbrt)||(Spush)||(Spop))uins.wsp.write(SC_LOGIC_1);
	else uins.wsp.write(SC_LOGIC_0);

	if(EA==Sfetch) uins.wir.write(SC_LOGIC_1);
	else uins.wir.write(SC_LOGIC_0);

	if(EA==Srreg) uins.wab.write(SC_LOGIC_1);
	else uins.wab.write(SC_LOGIC_0);

	if(EA==Sula) uins.wula.write(SC_LOGIC_1);
	else uins.wula.write(SC_LOGIC_0);
	
	if((EA==Swbk)||(EA==Sld)||(Spop)) uins.wreg.write(SC_LOGIC_1);
	else uins.wreg.write(SC_LOGIC_0);
	switch(EA){
		case Sfetch: case Srts: case Spop: case Sld: case Ssbrt: 
		case Spush: case Sst: 
		uins.ce.write(SC_LOGIC_1);
		break;
		default: uins.ce.write(SC_LOGIC_0); 
	}

	if((EA==Sfetch)||(EA==Srts)||(EA==Spop)||(EA==Sld)) uins.rw.write(SC_LOGIC_1);
	else uins.rw.write(SC_LOGIC_0);
}
void controle::set_c_EA_i(){
uins.wcv.write(((EA==Sula)&&((i==add)||(i==addi)||(i==sub)||(i==subi)))?SC_LOGIC_1:SC_LOGIC_0);
}
void controle::set_inst_la2_i_EA(){
	uins.ms2.write(((inst_la2==SC_LOGIC_1)||(i==push)||(EA==push))?SC_LOGIC_1:SC_LOGIC_0);
	uins.ma.write(((inst_la2==SC_LOGIC_1)||(i==saltoD)||(i==jsrd))?SC_LOGIC_1:SC_LOGIC_0);
}
void controle::set_inst_la1_i(){
	uins.wnz.write((EA==Sula)||((inst_la1==SC_LOGIC_1)||(i==addi)||(i==subi)))?SC_LOGIC_1:SC_LOGIC_0);
}
void controle::process_EA(){
	if(rst==SC_LOGIC_1)EA.write(Sfetch);
	else EA.write(PE);
}
void controle::process_PE(){
instruction iaux=i.read();
	switch(EA.read()){
	case Sfetch:
		if(iaux==halt) PE.write(Shalt);
		else PE.write(Srreg);

	case Shalt:
		PE.write(Shalt);
	case Srreg:
		PE.write(Sula);
	case Sula:
		if(iaux==pop) PE.write(Spop);
		else if(iaux==rts) PE.write(Srts);
		else if(iaux==ldsp) PE.write(Sldsp);
		else if(iaux==ld) PE.write(Sld);
		else if(iaux==st) PE.write(Sst);
		else if((inst_la1==SC_LOGIC_1)||(inst_la2==SC_LOGIC_0))PE.write(Swbk);
		else if((iaux==saltoR)||(iaux==salto)||(iaux==saltoD)) PE.write(Sjmp);
		else if((iaux==jsrr)||(i==jsr)||(i==jsrd)) PE.write(Ssbrt);
		else if(iaux==push) PE.write(Spush);
		else PE.write(Sfetch);
	case Spop: 
	case Srts:
	case Sldsp:
	case Sld:
	case Sst:
	case Swbk:
	case Sjmp:
	case Ssbrt:
	case Spush:
	default:
		PE.write(Sfetch);
	}
}
