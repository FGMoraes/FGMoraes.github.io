#include "registrador.h"

void registrador::bordadescida(){
	if(rst.read()==SC_LOGIC_1){ 
		Q.write(sc_lv<LENGHTR8>(SC_LOGIC_0));
	}
	else if(ce.read()==SC_LOGIC_1)
		Q.write(D.read());
} 
