#include "r8.h"

SC_MODULE(registrador){
	//Module port declarations
	sc_in<sc_logic> ck;
	sc_in<sc_logic> rst;
	sc_in<reg4> flag;
	sc_in<reg16> ir;
	sc_out<microinstruction> uins;
	
	typedef enum type_state {Sfetch, Srreg, Shalt, Sula, Srts, Spop, Sldsp, Sld, Sst, Swbk, Sjmp, Ssbrt, Spush};
 
 	//Signal declarations
	sc_signal<type_state> EA;
	sc_signal<type_state> PE;
	sc_signal<sc_logic> fn;
	sc_signal<sc_logic> fz;
	sc_signal<sc_logic> fc;
	sc_signal<sc_logic> fv;
	sc_signal<sc_logic> inst_la1;
	sc_signal<sc_logic> inst_la2;
	sc_signal<instruction> i;
	
	//Method process declarations
	void set_flags();
	void set_instruction();
	void set_uins_instruction();
	void set_inst_la();
	void set_c_i();
	void set_change_EA();
	void set_c_EA_i();
	void set_inst_la2_i_EA();
	void set_inst_la1_i();
	void process_EA();
	void process_PE();
	//Module constructor
	SC_CTOR(registrador){
		//register process
		SC_METHOD(set_flags);
		sensitive << flag;
		SC_METHOD(set_instruction);
		sensitive << ir << fn << fz << fc << fv;
		SC_METHOD(set_uins_instruction);
		sensitive << i;
		SC_METHOD(set_inst_la);
		sensitive << i;
		SC_METHOD(set_c_i);
		sensitive << i;
		SC_METHOD(set_change_EA);
		sensitive << EA;
		SC_METHOD(set_c_EA_i);
		sensitive << EA << i;
		SC_METHOD(set_inst_la2_i_EA);
		sensitive << inst_la2 << i << EA;
		SC_METHOD(set_inst_la1_i);
		sensitive << EA << inst_la1 << i;
		SC_METHOD(process_EA);
		sensitive << rst << ck;
		SC_METHOD(process_PE);
		sensitive << EA << i;
	}
};
