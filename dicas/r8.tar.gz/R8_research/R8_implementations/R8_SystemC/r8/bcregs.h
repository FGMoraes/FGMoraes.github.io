#include "r8.h"
#include "registrador.h"

SC_MODULE(bcregs){
	//Module port declarations
	sc_in<sc_logic> rst;
	sc_in<sc_logic> ck;
	sc_in<sc_logic> wreg;
	sc_in<sc_logic> rs2;
	sc_in<sc_lv<LENGHTR8> > ir;
	sc_in<sc_lv<LENGHTR8> > inREG;
	sc_out<sc_lv<LENGHTR8> > source1;
	sc_out<sc_lv<LENGHTR8> > source2;
	registrador **vregs;

	//Signal declarations
	sc_signal<sc_lv<LENGHTR8> > reg[LENGHTR8];
	sc_signal<sc_logic> wen[LENGHTR8];

	//Method process declarations
	void chipenable();
	void outsource1();
	void outsource2();
	//Module constructor
	SC_CTOR(bcregs){
		//register process
		SC_METHOD(chipenable);
		sensitive << ir << wreg; 
		SC_METHOD(outsource1);
		for(int v=0;v<LENGHTR8;v++)
		sensitive << reg[v];
		sensitive << ir;
		SC_METHOD(outsource2);
		for(int d=0;d<LENGHTR8;d++)
		sensitive << reg[d];
		sensitive << ir << rs2;
		//Instances of Modules
		vregs = new (registrador *) [LENGHTR8];
		for(int i=0; i<LENGHTR8;i++){
			sc_module_name name1= "registrador"+i;
			vregs[i]= new registrador(name1);
			vregs[i]->rst(rst);
			vregs[i]->ck(ck);
			vregs[i]->ce(wen[i]);
			vregs[i]->D(inREG);
			vregs[i]->Q(reg[i]);
		}
	}
};
