#ifndef __memInst_h
#define __memInst_h

SC_MODULE(memInst){

  typedef sc_uint<16> ad_type;
  typedef sc_lv<16> inst_type;

  sc_port<instR8If> porta;
  inst_type memoria[256];
  ad_type address;
  ad_type memPosition;

  inst_type instruction;

  FILE *instFile;
  int fileOk;
  int aux,aux2,i;

  char instruction_file[128];
  char inst[20];

  SC_HAS_PROCESS(memInst);

  memInst(sc_module_name name, char *file_name) : sc_module(name){

    //************************************************
    //**        CARGA DA MEMORIA DE INSTRUCOES      **
    //************************************************
    cout << "criando memoria de instrucoes..." << endl;
    strcpy(instruction_file,file_name);

    cout << instruction_file << endl;

    instFile = fopen(instruction_file,"r");

    if(instFile!=NULL){
      memPosition=0;
      while(true){

        fscanf(instFile,"%s",inst);
        if(feof(instFile)){break;}

        memoria[memPosition]=inst;

        memPosition++;
      }

      fclose(instFile);
    }

    //************************************************    

    SC_THREAD(sendInstruction);    
  }

  void sendInstruction();

};

#endif