#include "systemc.h"
#include "R8RegsIf.h"
#include "R8MemIf.h"
#include "R8InstIf.h"
#include "R8FlagsIf.h"
#include "common_defs.h"
#include "processor.h"
#include "processor_op.h"

void processor::mainAction(){
  inst_type instruction;
    
  while(true){
    // BUSCA
    portaInst->getNxtInstruction(&instruction);
    
    // LEITURA DE REGISTRADORES
    decodeInstruction(instruction);
    
    // OPERACAO COM A ULA
    switch(currentInstruction){
      case ADD:
        SC_ADD(rTarget,rSource1,rSource2);
        break;
      case SUB:
        SC_SUB(rTarget,rSource1,rSource2);
        break;
      case AND:
        SC_AND(rTarget,rSource1,rSource2);
        break;
      case OR:
        SC_OR(rTarget,rSource1,rSource2);
        break;
      case XOR:
        SC_XOR(rTarget,rSource1,rSource2);
        break;
      case ADDI:
        SC_ADDI(rTarget,vConst8);
        break;
      case SUBI:
        SC_SUBI(rTarget,vConst8);
        break;
      case LDL:
        SC_LDL(rTarget,vConst8);
        break;
      case LDH:
        SC_LDH(rTarget,vConst8);
        break;
      case LD:
        SC_LD(rTarget, rSource1, rSource2);
        break;
      case ST:
        SC_ST(rTarget, rSource1, rSource2);
        break;
      case SL0:
        SC_SL0(rTarget, rSource1);
        break;
      case SL1:
        SC_SL1(rTarget, rSource1);
        break;
      case SR0:
        SC_SR0(rTarget, rSource1);
        break;
      case SR1:
        SC_SR1(rTarget, rSource1);
        break;
      case NOT:
        SC_NOT(rTarget, rSource1);
        break;
      case NOP:
        SC_NOP();
        break;
      case HALT:
        SC_HALT();
        break;
      case LDSP:
        SC_LDSP(rSource1);
        break;
      case RTS:
        SC_RTS();
        break;
      case POP:
        SC_POP(rTarget);
        break;
      case PUSH:
        SC_PUSH(rTarget);
        break;
      case JMPR:
        SC_JMPR(rSource1);
        break;
      case JMPNR:
        SC_JMPNR(rSource1);
        break;
      case JMPZR:
        SC_JMPZR(rSource1);
        break;
      case JMPCR:
        SC_JMPCR(rSource1);
        break;
      case JMPVR:
        SC_JMPVR(rSource1);
        break;
      case JMP:
        SC_JMP(rSource1);
        break;
      case JMPN:
        SC_JMPN(rSource1);
        break;
      case JMPZ:
        SC_JMPZ(rSource1);
        break;
      case JMPC:
        SC_JMPC(rSource1);
        break;
      case JMPV:
        SC_JMPV(rSource1);
        break;
      case JSRR:
        SC_JSRR(rSource1);
        break;
      case JSR:
        SC_JSR(rSource1);
        break;
      case JMPD:
        SC_JMPD(rSource1);
        break;
      case JMPND:
        SC_JMPND(vConst16);
        break;
      case JMPZD:
        SC_JMPZD(vConst16);
        break;
      case JMPCD:
        SC_JMPCD(vConst16);
        break;
      case JMPVD:
        SC_JMPVD(vConst16);
        break;
      case JSRD:
        SC_JSRD(vConst16);
        break;
    }

    // EXECUCAO
    if(currentInstruction==HALT){break;}
  }

};

void processor::decodeInstruction(inst_type inst){

  sc_uint<4> operation;
  sc_lv<16> temp16;
  sc_lv<12> temp12;
  sc_lv<10> temp10;
  sc_lv<8>  temp8;
  sc_lv<4>  temp4;

  temp4 = inst.range(15,12);
  operation = temp4;

  switch(operation){
    case 0: 
      currentInstruction=ADD;
      temp4    = inst.range(11,8);
      rTarget  = temp4;
      temp4    = inst.range(7,4);
      rSource1 = temp4;
      temp4    = inst.range(3,0);
      rSource2 = temp4;
      break;
    case 1: 
      currentInstruction=SUB;
      temp4    = inst.range(11,8);
      rTarget  = temp4;
      temp4    = inst.range(7,4);
      rSource1 = temp4;
      temp4    = inst.range(3,0);
      rSource2 = temp4;
      break;
    case 2: 
      currentInstruction=AND;
      temp4    = inst.range(11,8);
      rTarget  = temp4;
      temp4    = inst.range(7,4);
      rSource1 = temp4;
      temp4    = inst.range(3,0);
      rSource2 = temp4;
      break;
    case 3: 
      currentInstruction=OR;
      temp4    = inst.range(11,8);
      rTarget  = temp4;
      temp4    = inst.range(7,4);
      rSource1 = temp4;
      temp4    = inst.range(3,0);
      rSource2 = temp4;
      break;
    case 4: 
      currentInstruction=XOR;
      temp4    = inst.range(11,8);
      rTarget  = temp4;
      temp4    = inst.range(7,4);
      rSource1 = temp4;
      temp4    = inst.range(3,0);
      rSource2 = temp4;
      break;
    case 5: 
      currentInstruction=ADDI;
      temp4    = inst.range(11,8);
      rTarget  = temp4;
      vConst8  = inst.range(7,0);
      break;
    case 6: 
      currentInstruction=SUBI;
      temp4    = inst.range(11,8);
      rTarget  = temp4;
      vConst8  = inst.range(7,0);
      break;
    case 7: 
      currentInstruction=LDL;
      temp4    = inst.range(11,8);
      rTarget  = temp4;
      vConst8  = inst.range(7,0);
      break;
    case 8: 
      currentInstruction=LDH;
      temp4    = inst.range(11,8);
      rTarget  = temp4;
      vConst8  = inst.range(7,0);
      break;
    case 9: 
      currentInstruction=LD;
      temp4    = inst.range(11,8);
      rTarget  = temp4;
      temp4    = inst.range(7,4);
      rSource1 = temp4;
      temp4    = inst.range(3,0);
      rSource2 = temp4;
      break;
    case 10: 
      currentInstruction=ST;
      temp4    = inst.range(11,8);
      rTarget  = temp4;
      temp4    = inst.range(7,4);
      rSource1 = temp4;
      temp4    = inst.range(3,0);
      rSource2 = temp4;
      break;
    case 11: 
      temp4    = inst.range(3,0);
      operation = temp4;
      switch(operation){
        case 0:
          currentInstruction=SL0;
          temp4 = inst.range(11,8);
          rTarget = temp4;
          temp4 = inst.range(7,4);
          rSource1 = temp4;
          break;
        case 1:
          currentInstruction=SL1;
          temp4 = inst.range(11,8);
          rTarget = temp4;
          temp4 = inst.range(7,4);
          rSource1 = temp4;
          break;
        case 2:
          currentInstruction=SR0;
          temp4 = inst.range(11,8);
          rTarget = temp4;
          temp4 = inst.range(7,4);
          rSource1 = temp4;
          break;
        case 3:
          currentInstruction=SR1;
          temp4 = inst.range(11,8);
          rTarget = temp4;
          temp4 = inst.range(7,4);
          rSource1 = temp4;
          break;
        case 4:
          currentInstruction=NOT;
          temp4 = inst.range(11,8);
          rTarget = temp4;
          temp4 = inst.range(7,4);
          rSource1 = temp4;
          break;
        case 5:
          currentInstruction=NOP;
          break;
        case 6:
          currentInstruction=HALT;
          break;
        case 7:
          currentInstruction=LDSP;
          temp4 = inst.range(7,4);
          rSource1 = temp4;
          break;
        case 8:
          currentInstruction=RTS;
          break;
        case 9:
          currentInstruction=POP;
          temp4 = inst.range(11,8);
          rTarget = temp4;
          break;
        case 10:
          currentInstruction=PUSH;
          temp4 = inst.range(11,8);
          rTarget = temp4;
          break;
      }
      break;
    case 12: 
      temp4    = inst.range(3,0);
      operation = temp4;
      temp4 = inst.range(7,4);
      rSource1 = temp4;
      switch(operation){
        case 0:
          currentInstruction=JMPR;
          break;
        case 1:
          currentInstruction=JMPNR;
          break;
        case 2:
          currentInstruction=JMPZR;
          break;
        case 3:
          currentInstruction=JMPCR;
          break;
        case 4:
          currentInstruction=JMPVR;
          break;
        case 5:
          currentInstruction=JMP;
          break;
        case 6:
          currentInstruction=JMPN;
          break;
        case 7:
          currentInstruction=JMPZ;
          break;
        case 8:
          currentInstruction=JMPC;
          break;
        case 9:
          currentInstruction=JMPV;
          break;
        case 10:
          currentInstruction=JSRR;
          break;
        case 11:
          currentInstruction=JSR;
          break;
      }
      break;
    case 13: 
      currentInstruction=JMPD;
      temp10 = inst.range(9,0);
      vConst16 = ("000000",temp10);
      break;
    case 14: 
      temp4    = ("00",inst.range(11,9));
      operation = temp4;
      switch(operation){
        case 0:
          currentInstruction=JMPND;
          break;
        case 1:
          currentInstruction=JMPZD;
          break;
        case 2:
          currentInstruction=JMPCD;
          break;
        case 3:
          currentInstruction=JMPVD;
          break;
      }
      break;
    case 15:
      currentInstruction=JSRD;
      vConst16=("0000",inst.range(11,0));
      break;
  }

}
