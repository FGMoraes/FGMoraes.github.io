
#define SC_ADD(Target,Source1,Source2) \
        portaRegs->readReg(Source1,&vSource1,Source2,&vSource2); \
        iSource1=vSource1; \
        iSource2=vSource2; \
        iResult=0; \
        iResult=iSource1+iSource2; \
        vResult=iResult; \
        portaFlag->lnz_lcv(vResult,vSource1,vSource2); \
        vTarget=vResult.range(15,0); \
        portaRegs->writeReg(Target,vTarget);

#define SC_SUB(Target,Source1,Source2) \
        portaRegs->readReg(Source1,&vSource1,Source2,&vSource2); \
        iSource1=vSource1; \
        iSource2=vSource2; \
        iResult=0; \
        iResult=iSource1-iSource2; \
        vResult=iResult; \
        portaFlag->lnz_lcv(vResult, vSource1, vSource2); \
        vTarget=vResult.range(15,0); \
        portaRegs->writeReg(Target,vTarget);

#define SC_AND(Target,Source1,Source2) \
        portaRegs->readReg(Source1,&vSource1,Source2,&vSource2); \
        iResult=0; \
        vResult=iResult; \
        vResult=vSource1&vSource2; \
        portaFlag->lnz(vResult); \
        vTarget= vResult(15,0); \
        portaRegs->writeReg(Target,vTarget);

#define SC_OR(Target,Source1,Source2)                            \
        portaRegs->readReg(Source1,&vSource1,Source2,&vSource2); \
        iResult=0; \
        vResult=iResult; \
        vResult=vSource1|vSource2; \
        portaFlag->lnz(vResult); \
        vTarget=vResult.range(15,0); \
        portaRegs->writeReg(Target,vTarget);

#define SC_XOR(Target,Source1,Source2)                           \
        portaRegs->readReg(Source1,&vSource1,Source2,&vSource2); \
        iResult=0; \
        vResult=iResult; \
        vResult=vSource1^vSource2; \
        portaFlag->lnz(vResult); \
        vTarget=vResult.range(15,0); \
        portaRegs->writeReg(Target,vTarget);

#define SC_ADDI(Target,Const) \
        portaRegs->readReg(Target,&vTarget); \
        iTarget=vTarget; \
        vConst16=("00000000",vConst8); \
        iConst16=vConst16; \
        iResult=0; \
        iResult=iTarget+iConst16; \
        vResult=iResult; \
        portaFlag->lnz_lcv(vResult, vTarget, vConst16); \
        vTarget=vResult.range(15,0); \
        portaRegs->writeReg(Target,vTarget);

#define SC_SUBI(Target,Const) \
        portaRegs->readReg(Target,&vTarget); \
        iTarget=vTarget; \
        vConst16=("00000000",vConst8); \
        iConst16=vConst16; \
        iResult=0; \
        iResult=iTarget-iConst16; \
        vResult=iResult; \
        portaFlag->lnz_lcv(vResult, vTarget, vConst16); \
        vTarget=vResult.range(15,0); \
        portaRegs->writeReg(Target,vTarget);

#define SC_LDL(Target,Const)                                     \
        portaRegs->readReg(Target,&vTarget);                     \
        vTarget=(vTarget.range(15,8),Const);                     \
        portaRegs->writeReg(Target,vTarget);

#define SC_LDH(Target,Const)                                     \
        portaRegs->readReg(Target,&vTarget);                     \
        vTarget=(Const,vTarget.range(7,0));                      \
        portaRegs->writeReg(Target,vTarget);

#define SC_LD(Target,Source1,Source2)                            \
        portaRegs->readReg(Source1,&vSource1,Source2,&vSource2);  \
        iSource1=vSource1; \
        iSource2=vSource2; \
        iSource1+=iSource2; \
        uSource1=iSource1; \
        portaData->readMemDat(uSource1,&vTarget); \
        portaRegs->writeReg(Target,vTarget);

#define SC_ST(Target,Source1,Source2)                            \
        portaRegs->readReg(Source1,&vSource1,Source2,&vSource2);  \
        iSource1=vSource1; \
        iSource2=vSource2; \
        iSource1+=iSource2; \
        uSource1=iSource1; \
        portaData->writeMemDat(uSource1,vTarget);

#define SC_SL0(Target,Source1) \
        portaRegs->readReg(Source1,&vSource1); \
        vTarget= (vSource1.range(14,0),"0"); \
        vResult= ("0",vTarget); \
        portaFlag->lnz(vResult); \
        portaRegs->writeReg(Target,vTarget);

#define SC_SL1(Target,Source1) \
        portaRegs->readReg(Source1,&vSource1); \
        vTarget = (vSource1.range(14,0),"1"); \
        vResult= ("0",vTarget); \
        portaFlag->lnz(vResult); \
        portaRegs->writeReg(Target,vTarget);

#define SC_SR0(Target,Source1) \
        portaRegs->readReg(Source1,&vSource1); \
        vTarget = ("0",vSource1.range(15,1)); \
        vResult= ("0",vTarget); \
        portaFlag->lnz(vResult); \
        portaRegs->writeReg(Target,vTarget);

#define SC_SR1(Target,Source1) \
        portaRegs->readReg(Source1,&vSource1); \
        vTarget = ("1",vSource1.range(15,1)); \
        vResult= ("0",vTarget); \
        portaFlag->lnz(vResult); \
        portaRegs->writeReg(Target,vTarget);

#define SC_NOT(Target,Source1) \
        portaRegs->readReg(Source1,&vSource1); \
        vTarget = ~ vSource1; \
        vResult= ("0",vTarget); \
        portaFlag->lnz(vResult); \
        portaRegs->writeReg(Target,vTarget);

#define SC_NOP()

#define SC_HALT()

#define SC_LDSP(Source) \
        portaRegs->readReg(Source,&vSource1); \
        uSource1=vSource1; \
        portaData->startupSP(uSource1);

#define SC_RTS() \
        portaData->execPOP(&vSource1); \
        uSource1=vSource1; \
        portaInst->updatePC(uSource1);

#define SC_POP(Target) \
        portaData->execPOP(&vSource1); \
        portaRegs->writeReg(Target,vSource1);

#define SC_PUSH(Source) \
        portaRegs->readReg(Source,&vSource1); \
        portaData->execPUSH(vSource1);

#define SC_JMPR(Source) \
        portaInst->getPC(&uSource2); \
        portaRegs->readReg(Source,&vSource1); \
        uSource1=vSource1; \
        uSource1+=uSource2; \
        portaInst->updatePC(uSource1);

#define SC_JMPNR(Source) \
        if(portaFlag->getFlag($negative)=="1"){SC_JMPR(Source);};

#define SC_JMPZR(Source) \
        if(portaFlag->getFlag($zero)=="1"){SC_JMPR(Source);} 

#define SC_JMPCR(Source) \
       if(portaFlag->getFlag($carry)=="1"){SC_JMPR(Source);} 

#define SC_JMPVR(Source) \
        if(portaFlag->getFlag($overflow)=="1"){SC_JMPR(Source);} 

#define SC_JMP(Source) \
        portaRegs->readReg(Source,&vSource1); \
        uSource1=vSource1; \
        portaInst->updatePC(uSource1);

#define SC_JMPN(Source) \
        if(portaFlag->getFlag($negative)=="1"){SC_JMP(Source);} 

#define SC_JMPZ(Source) \
        if(portaFlag->getFlag($zero)=="1"){SC_JMP(Source);} 

#define SC_JMPC(Source) \
        if(portaFlag->getFlag($carry)=="1"){SC_JMP(Source);} 

#define SC_JMPV(Source) \
        if(portaFlag->getFlag($overflow)=="1"){SC_JMP(Source);} 

#define SC_JSRR(Source) \
        portaInst->getPC(&uSource2); \
        vSource2=uSource2; \
        portaData->execPUSH(vSource2); \
        portaRegs->readReg(Source,&vSource1); \
        uSource1=vSource1; \
        uSource1+=uSource2; \
        portaInst->updatePC(uSource1);

#define SC_JSR(Source) \
        portaInst->getPC(&uSource2); \
        vSource2=uSource2; \
        portaData->execPUSH(vSource2); \
        portaRegs->readReg(Source,&vSource1); \
        uSource1=vSource1; \
        portaInst->updatePC(uSource1);        

#define SC_JMPD(Constant) \
        portaInst->getPC(&uSource2); \
        uSource1=Constant; \
        uSource1+=uSource2; \
        portaInst->updatePC(uSource1);

#define SC_JMPND(Constant) \
       if(portaFlag->getFlag($negative)=="1"){SC_JMPD(Constant);};

#define SC_JMPZD(Constant) \
        if(portaFlag->getFlag($zero)=="1"){SC_JMPD(Constant);};

#define SC_JMPCD(Constant) \
        if(portaFlag->getFlag($carry)=="1"){SC_JMPD(Constant);};

#define SC_JMPVD(Constant) \
        if(portaFlag->getFlag($overflow)=="1"){SC_JMPD(Constant);};

#define SC_JSRD(Constant) \
        portaInst->getPC(&uSource1); \
        vSource1=uSource1; \
        portaData->execPUSH(vSource1); \
        uSource2=Constant; \
        uSource1+=uSource2; \
        portaInst->updatePC(uSource1);

