#ifndef __R8MemIf_h
#define __R8MemIf_h

class R8MemIf : virtual public sc_interface{
  public:
    typedef sc_lv<16> dt_type;
    typedef sc_uint<16> ad_type;

    virtual void readMemDat(ad_type, dt_type *) = 0;
    virtual void writeMemDat(ad_type, dt_type) = 0;
    virtual void startupSP(ad_type) = 0;
    virtual void execPOP(dt_type *) = 0;
    virtual void execPUSH(dt_type) = 0;
};

#endif