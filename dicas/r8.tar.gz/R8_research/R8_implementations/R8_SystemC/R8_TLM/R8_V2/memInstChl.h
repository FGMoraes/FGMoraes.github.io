#ifndef _memInstChl_h
#define _memInstChl_h

#include "systemc.h"
#include "R8InstIf.h"
#include "instR8If.h"

class memInstChl: public sc_channel, public R8InstIf, public instR8If{
  public:

    typedef sc_lv<16>  inst_type;
    typedef sc_uint<16> ad_type;
    
    memInstChl(sc_module_name name) : sc_channel(name) {
      // carregar as instrucoes
      // inicializar variaveis
      PC=0;
    }

    ~memInstChl(){
      cout << "fim das instrucoes" << endl;
    }

    void getAddress(ad_type *memAddress){
      wait(getInst);
      *memAddress=PC;
    }

    void sendInstruction(inst_type instruction){
      inst=instruction;
      instructionAvailable.notify();
    }

    void getNxtInstruction(inst_type *instruction){
      getInst.notify();
      wait(instructionAvailable);
      *instruction=inst;
      PC++;      
    }

    void updatePC(ad_type newPC){
      PC= newPC;
    };

    void getPC(ad_type * PCValue){
      *PCValue=PC;
    };

  private:
    ad_type PC;
    inst_type inst;
    sc_event getInst, instructionAvailable;
};

#endif