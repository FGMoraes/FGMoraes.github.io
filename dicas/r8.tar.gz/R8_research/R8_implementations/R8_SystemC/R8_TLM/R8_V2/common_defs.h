// flags 
#define $zero     0
#define $negative 1
#define $carry    2
#define $overflow 3

// flags nz e cv
#define $lnz      0
#define $lcv      1
#define $lnz_$lcv 2

