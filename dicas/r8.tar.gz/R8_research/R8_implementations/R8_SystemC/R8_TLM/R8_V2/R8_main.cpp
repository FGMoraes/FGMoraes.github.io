#include "systemc.h"
// canais
#include "memDatChl.h"
#include "memInstChl.h"
#include "bcregsChl.h"
#include "flagNZCVChl.h"
// componentes
#include "processor.h"
#include "bcregs.h"
#include "memDat.h"
#include "memInst.h"

SC_MODULE(top){

  memDatChl   canalDados;
  memInstChl  canalInstrucoes;
  bcregsChl   canalRegs;
  flagNZCVChl canalFlags;
  memDat      memoriaDeDados;
  memInst     memoriaDeInstrucoes;
  bcregs      bancoRegs;
  processor   processador;

  top(sc_module_name name, char *file_name): sc_module(name),                             
                            canalDados("cnlData"),                             
                            canalInstrucoes("cnlInst"),
                            canalRegs("cnlRegs"),
                            canalFlags("cnlFlags"),
                            memoriaDeDados("memoriaDados"), 
                            memoriaDeInstrucoes("memoriaInstrucoes", file_name), 
                            bancoRegs("bancoDeRegistradores"), 
                            processador("processador"){

    memoriaDeDados.porta(canalDados);
    processador.portaData(canalDados);
    memoriaDeInstrucoes.porta(canalInstrucoes);
    processador.portaInst(canalInstrucoes);
    bancoRegs.porta(canalRegs);
    processador.portaRegs(canalRegs);
    processador.portaFlag(canalFlags);
  };


};

int sc_main(int argc, char *argv[]){

  top topo("topo", argv[1]);

  sc_start(-1);

  return 0;

}