#ifndef _bcregs_h
#define _bcregs_h

SC_MODULE(bcregs){

  typedef sc_uint<4> reg_type;
  typedef sc_lv<16>  value_type;

  sc_port<regR8If> porta;

  value_type registers[16];  
  reg_type reg1,reg2;
  value_type val1,val2;

  SC_HAS_PROCESS(bcregs);

  bcregs (sc_module_name name): sc_module(name){
    SC_THREAD(updateRegs);
    SC_THREAD(sendRegValue);
    SC_THREAD(sendRegsValue);
  }

  void updateRegs();
  void sendRegValue();
  void sendRegsValue();

};

#endif