#ifndef _R8InstIf
#define _R8InstIf

class R8InstIf : virtual public sc_interface{
  public:
    typedef sc_lv<16>   inst_type;
    typedef sc_uint<16> ad_type;

    virtual void getNxtInstruction(inst_type *) = 0;
    virtual void updatePC(ad_type) = 0;
    virtual void getPC(ad_type *) = 0;

};

#endif 