#include "systemc.h"
#include "InstR8If.h"
#include <stdio.h>
#include <stdlib.h>
#include "memInst.h"


void memInst::sendInstruction(){
  while(true){
    porta->getAddress(&memPosition);
    instruction=memoria[memPosition];
    porta->sendInstruction(instruction);
  }
}
