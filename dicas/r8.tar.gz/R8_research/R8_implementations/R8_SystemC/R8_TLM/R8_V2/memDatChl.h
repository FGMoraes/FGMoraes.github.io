#ifndef __memDatChl_h
#define __memDatChl_h

#include "systemc.h"
#include "R8MemIf.h"
#include "memR8If.h"

class memDatChl: public sc_channel, public R8MemIf, public memR8If{
  public:

    typedef sc_uint<16> ad_type;
    typedef sc_lv<16> dt_type;
    
    memDatChl(sc_module_name name) : sc_channel(name) {}
    ~memDatChl(){
      cout << "fim do processo" << endl;
    }

    void updateMem(ad_type *address, dt_type *data){
      // update wait a write process
      wait(writeMem);

      // after that receive data
      *address=memPosition;
      *data=memValue;

      memWrote.notify();
    };

    void getAddress(ad_type *address){
      wait(readMem);
      *address=memPosition;
    };

    void sendData(dt_type data){
      memValue=data;
      dataOk.notify();
    };


    void writeMemDat(ad_type memAddress, dt_type memData){
      // processor sends address and data to be written
      memPosition = memAddress;
      memValue = memData;

      // channel notify that an update process will occur
      writeMem.notify();

      wait(memWrote);

    };

    void readMemDat(ad_type memAddress, dt_type *memData){

      // channel capture the address
      memPosition = memAddress;

      // and notify a read process
      readMem.notify();

      // after that wait
      wait(dataOk);

      // finally the data is captured
      *memData = memValue;

    };

    void startupSP(ad_type upSP){
      SP = upSP;
    };

    void execPOP(dt_type *memData){
      memPosition=SP;
      SP++;
      readMem.notify();
      wait(dataOk);
      *memData=memValue;
    };

    void execPUSH(dt_type){
      memPosition=SP;
      SP--;
      writeMem.notify();
      wait(memWrote);
    };

  private:
    ad_type SP;
    ad_type memPosition;
    dt_type memValue;

    sc_event writeMem, readMem;
    sc_event dataOk, memWrote;

};

#endif