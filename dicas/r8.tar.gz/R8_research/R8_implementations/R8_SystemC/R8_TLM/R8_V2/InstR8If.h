#ifndef _instR8If
#define _instR8If

class instR8If : virtual public sc_interface{
  public:
    typedef sc_lv<16> inst_type;
    typedef sc_uint<16> ad_type;

    virtual void getAddress(ad_type *) = 0;
    virtual void sendInstruction(inst_type) = 0;

};

#endif