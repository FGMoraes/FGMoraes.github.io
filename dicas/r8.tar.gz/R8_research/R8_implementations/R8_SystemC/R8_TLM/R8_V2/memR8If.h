#ifndef __memR8If_h
#define __memR8If_h

class memR8If : virtual public sc_interface{
  public:
    typedef sc_lv<16> dt_type;
    typedef sc_uint<16> ad_type;

    virtual void updateMem(ad_type *, dt_type *) = 0;
    virtual void getAddress(ad_type *) = 0;
    virtual void sendData(dt_type) = 0;
};

#endif