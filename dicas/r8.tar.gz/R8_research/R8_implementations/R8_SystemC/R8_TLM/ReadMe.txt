o apontamento para o arquivo SystemC.h tem de ser atualizado.

* Project >> Settings >> C/C++ 
  em Category selecione Preprocessor
  atualize o campo "Additional include directories" para o caminho "systemc-2.0.1/src" da sua m�quina

* exclua o arquivo SystemC.lib do projeto e inclua-o novamente.



