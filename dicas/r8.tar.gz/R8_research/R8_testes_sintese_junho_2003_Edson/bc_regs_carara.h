#include "reg16.h"

SC_MODULE(bc_regs) {

	sc_in< bool > clock, reset, wreg, ms2;
	sc_in< sc_uint<16> > inREG, ir;

	sc_out< sc_uint<16> > source1, source2;

	sc_signal< sc_uint<16> > r[16];	// Sa�da dos registradores
	sc_signal< bool > wen[16];		// Enable dos regitradores
	reg16 *reg[16];					// Registradores do banco

	void out_source1();
	void out_source2();
	void select_reg();

	SC_CTOR(bc_regs) {
		SC_METHOD(out_source1);
			sensitive << ir;
			sensitive << r[0] << r[1] << r[2] << r[3] << r[4] << r[5] << r[6] << r[7];
			sensitive << r[8] << r[9] << r[10] << r[11] << r[12] << r[13] << r[14] << r[15];

		SC_METHOD(out_source2);
			sensitive << ms2 << ir;
			sensitive << r[0] << r[1] << r[2] << r[3] << r[4] << r[5] << r[6] << r[7];
			sensitive << r[8] << r[9] << r[10] << r[11] << r[12] << r[13] << r[14] << r[15];

		SC_METHOD(select_reg);
		sensitive << ir << wreg;

		// Inst�ncia��o dos registradores
		reg[0] = new reg16("reg0");
		reg[0]->clock(clock);
		reg[0]->reset(reset);
		reg[0]->ce(wen[0]);
		reg[0]->D(inREG);
		reg[0]->Q(r[0]);

		reg[1] = new reg16("reg1");
		reg[1]->clock(clock);
		reg[1]->reset(reset);
		reg[1]->ce(wen[1]);
		reg[1]->D(inREG);
		reg[1]->Q(r[1]);

		reg[2] = new reg16("reg2");
		reg[2]->clock(clock);
		reg[2]->reset(reset);
		reg[2]->ce(wen[2]);
		reg[2]->D(inREG);
		reg[2]->Q(r[2]);

		reg[3] = new reg16("reg3");
		reg[3]->clock(clock);
		reg[3]->reset(reset);
		reg[3]->ce(wen[3]);
		reg[3]->D(inREG);
		reg[3]->Q(r[3]);

		reg[4] = new reg16("reg4");
		reg[4]->clock(clock);
		reg[4]->reset(reset);
		reg[4]->ce(wen[4]);
		reg[4]->D(inREG);
		reg[4]->Q(r[4]);

		reg[5] = new reg16("reg5");
		reg[5]->clock(clock);
		reg[5]->reset(reset);
		reg[5]->ce(wen[5]);
		reg[5]->D(inREG);
		reg[5]->Q(r[5]);

		reg[6] = new reg16("reg6");
		reg[6]->clock(clock);
		reg[6]->reset(reset);
		reg[6]->ce(wen[6]);
		reg[6]->D(inREG);
		reg[6]->Q(r[6]);

		reg[7] = new reg16("reg7");
		reg[7]->clock(clock);
		reg[7]->reset(reset);
		reg[7]->ce(wen[7]);
		reg[7]->D(inREG);
		reg[7]->Q(r[7]);

		reg[8] = new reg16("reg8");
		reg[8]->clock(clock);
		reg[8]->reset(reset);
		reg[8]->ce(wen[8]);
		reg[8]->D(inREG);
		reg[8]->Q(r[8]);

		reg[9] = new reg16("reg9");
		reg[9]->clock(clock);
		reg[9]->reset(reset);
		reg[9]->ce(wen[9]);
		reg[9]->D(inREG);
		reg[9]->Q(r[9]);

		reg[10] = new reg16("reg10");
		reg[10]->clock(clock);
		reg[10]->reset(reset);
		reg[10]->ce(wen[10]);
		reg[10]->D(inREG);
		reg[10]->Q(r[10]);

		reg[11] = new reg16("reg11");
		reg[11]->clock(clock);
		reg[11]->reset(reset);
		reg[11]->ce(wen[11]);
		reg[11]->D(inREG);
		reg[11]->Q(r[11]);

		reg[12] = new reg16("reg12");
		reg[12]->clock(clock);
		reg[12]->reset(reset);
		reg[12]->ce(wen[12]);
		reg[12]->D(inREG);
		reg[12]->Q(r[12]);

		reg[13] = new reg16("reg13");
		reg[13]->clock(clock);
		reg[13]->reset(reset);
		reg[13]->ce(wen[13]);
		reg[13]->D(inREG);
		reg[13]->Q(r[13]);

		reg[14] = new reg16("reg14");
		reg[14]->clock(clock);
		reg[14]->reset(reset);
		reg[14]->ce(wen[14]);
		reg[14]->D(inREG);
		reg[14]->Q(r[14]);

		reg[15] = new reg16("reg15");
		reg[15]->clock(clock);
		reg[15]->reset(reset);
		reg[15]->ce(wen[15]);
		reg[15]->D(inREG);
		reg[15]->Q(r[15]);
	}
};

void bc_regs::out_source1() {

	source1 = r[ir.read().range(7,4)];
}

void bc_regs::out_source2() {

	if ( ms2 )
		source2 = r[ir.read().range(11,8)];
	else
		source2 = r[ir.read().range(3,0)];

}

// Habilita��o dos registradores
void bc_regs::select_reg() {

	for ( int i=0; i<16; i++ )
		wen[i] = false;

	if ( wreg )
		wen[ir.read().range(11,8)] = true;

}

