// bcregs.cpp: source file
#include "r8.h"
#include "registrador.h"
#include "bcregs.h"

void bcregs::chipenable(){
  sc_lv< 4 >  subv;
  sc_uint< 4 > i;
  int t;
  int d;

  subv=ir.read().range(11,8);
  t=1;
  for(d=3;d>=0;d--){
    if((subv[d]!=0)&&(subv[d]!=1)) t=0;
  };

  if(t==1){
 	  i=subv.to_uint();
	  if(wreg.read()==1) wen[i]=1;
	  else wen[i]=0;
  };
}

void bcregs::outsource1(){
  sc_uint<4> conv;
  int t=1;
  sc_lv<WIDTHR8> iraux;
  sc_lv<4> sublv;
  iraux = ir.read();
  sublv=iraux.range(7,4);

  for(int d=3;d>=0;d--)
    if((sublv[d]!=0)&&(sublv[d]!=1)) t=0;
  if(t==1){
    conv=sublv.to_uint();
    source1.write(reg[conv].read());
  };
}

void bcregs::outsource2(){
  sc_uint<4> conv;
  int t=1;
  sc_lv<WIDTHR8> iraux;
  sc_lv<4> sublv;
  iraux=ir.read();

  if(rs2.read()==0)
	  sublv=iraux.range(3,0);
  else
	  sublv=iraux.range(11,8);

  for(int d=3;d>=0;d--) if((sublv[d]!='0')&&(sublv[d]!='1')) t=0;
    if(t==1){
	    conv=sublv.to_uint();
	    source2.write(reg[conv].read());
    };
}
