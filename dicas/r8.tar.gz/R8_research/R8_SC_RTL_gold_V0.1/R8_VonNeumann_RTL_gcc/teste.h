
#ifdef CCSS_USE_SC_CTOR
#define CCSS_INIT_MEMBERS_PREFIX :
#undef CCSS_USE_SC_CTOR
#else
#define CCSS_INIT_MEMBERS_PREFIX ,
#endif

#define CCSS_INIT_MEMBERS  CCSS_INIT_MEMBERS_PREFIX \
    rst("rst") \
    , ck("ck")

struct teste
: public sc_module
{

    // ports

    // Module port declarations
    sc_in<sc_logic> rst;
    sc_in<sc_logic> ck;

    // initialize parameters
    virtual void InitParameters() {
    }

	//Module constructor
	SC_CTOR(bcregs){

    SC_METHOD(mainAction);
    sensitive << rst << ck;

	}

}; // end module bcregs
#undef CCSS_INIT_MEMBERS_PREFIX
#undef CCSS_INIT_MEMBERS

