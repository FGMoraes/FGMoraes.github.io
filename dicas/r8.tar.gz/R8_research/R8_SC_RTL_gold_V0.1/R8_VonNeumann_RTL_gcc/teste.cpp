// bcregs.cpp: source file
#include "r8.h"
#include "registrador.h"
#include "teste.h"

void teste::mainAction(){

  sc_logic subv;

  if(rst.read()==1)
    subv = rst.read();
  else
    subv = ck.read();

}
