//datapath.cpp: source file
#include "r8.h"
#include "registrador.h"
#include "bcregs.h"
#include "datapath.h"

void datapath::setAdderAB(){
  reg16 A=opA.read();
  reg16 B=opB.read();
  instruction u=ula.read();

  if(u==addi) addA=("00000000",A.range(7,0));
  else if(u==subi) addA=~("00000000",A.range(7,0));
  else if(u==jsrd) addA=(A[11], A[11], A[11], A[11], A.range(11,0));
  else if(u==saltoD) addA=(A[9], A[9], A[9], A[9], A[9], A[9], A.range(9,0));
  else addA=A;

  if(u==sub) addB=~B;
  else addB=B;
  if((u==sub)||(u==subi)) cin.write(sc_logic(0));
  else cin.write(sc_logic(0));
}

void datapath::adderAB(){
  reg16 A=addA.read();
  reg16 B=addB.read();
  sc_logic cant;
  sc_logic acarry;
  reg16 aS;
  for(int w=0;w<WIDTHR8;w++){
    if(w==0) acarry=cin.read();
    aS[w]=A[w]^B[w]^acarry;
    cant=acarry;
    acarry=(A[w] & B[w])|(A[w] & acarry)|(B[w] & acarry);
  }
  coutf=acarry;
  overflow=cant^acarry;
  add=aS;
}

void datapath::pula(){
  reg16 A=opA.read();
  reg16 B=opB.read();
  instruction u=ula.read();

  if(u==e) outula=A&B;
  else if(u==ou) outula=A|B;//or
  else if(u==oux) outula=A^B;//xor
  else if(u==ldl) outula=(B.range(15,8),A.range(7,0));
  else if(u==ldh) outula=(A.range(7,0),B.range(7,0));
  else if(u==sl0) outula=(A.range(14,0),0);
  else if(u==sl1) outula=(A.range(14,0),1);
  else if(u==sr0) outula=(0, A.range(15,1));
  else if(u==sr1) outula=(1, A.range(15,1));
  else if(u==notA) outula=~A;
  else if((u==rts)||(u==pop)) outula=fullAdder(B, "0000000000000001", 0);
  else if((u==salto)||(u==jsr)||(u==ldsp)) outula=rA.read();
  else outula=add.read();
}

void datapath::setFlags(){
  sc_lv< 4 > f;
  sc_logic n, z;

  if(rst.read()==1){
    f = 0;
  }
  else{
    if(wnz.read()==1){
      if(outula.read()==reg16(0)) n=1;
      else n=0;
      z=outula.read()[15];
      f[FLAG_N]=n;
      f[FLAG_Z]=z;
    }
    if(wcv.read()==1){
      f[FLAG_C]=coutf.read();
      f[FLAG_V]=overflow.read();
    }
  }

  flags.write(f);

}

void datapath::muxPC(){
  reg2 tmpc=mpc.read();
  if(tmpc=="01") dtpc=rula.read();
  else if(tmpc=="00") dtpc=data.read();
  else dtpc=fullAdder(pc.read(), "0000000000000001", 0);
}

void datapath::muxSP(){
  if(msp.read()==1) dtsp=fullAdder(sp.read(), "1111111111111110", 1);
  else dtsp=rula.read();
}

void datapath::muxROM(){
  if(mad.read()=="00") address.write(rula.read());
  else if(mad.read()=="01") address.write(pc.read());
  else address.write(sp.read());
}

void datapath::muxULAA(){
  if(ma.read()==1) opA=ir.read();
  else opA=rA.read();
}

void datapath::muxULAB(){
  if(mb.read()=="01") opB=sp.read();
  else if(mb.read()=="10") opB=pc.read();
  else opB=rB.read();
}

void datapath::muxREGS(){
  if(mreg.read()==1) dtreg=data.read();
  else dtreg=rula.read();
}

void datapath::muxDATAOUT(){
  if(ir.read().range(15, 12)=="1010") dataout=s2.read();
  else dataout=opB.read();
}

void datapath::muxRAM(){
  if((ce.read()==1)&&(rw.read()==0)) data.write(dataout);
  else data.write(reg16(0));
}

void datapath::setI(){
  instructor.write(ir.read());
}

reg16 datapath::fullAdder(reg16 A, reg16 B, sc_logic paramCin){

  sc_logic carry;
  reg16 aS;

  for(int w=0;w<WIDTHR8;w++){
    if(w==0) carry=paramCin;
    aS[w]=A[w]^B[w]^carry;
    carry=(A[w] & B[w])|(A[w] & carry)|(B[w] & carry);
  };

  return(aS);

}
