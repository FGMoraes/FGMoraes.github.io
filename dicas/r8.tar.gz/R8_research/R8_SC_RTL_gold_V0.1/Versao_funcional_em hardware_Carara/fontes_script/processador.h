#include "controle.h"

SC_MODULE(processador) {

	sc_in< sc_uint<16> > datain;
	sc_in< bool > clock, reset, wait_r8;

	sc_out< sc_uint<16> > endereco, dataout;
	sc_out< bool > ce, rw, halt;


	sc_signal< bool >
		msp, mreg, ms2, ma, wpc, wsp, wir,
		wab, wula, wreg, wnz, wcv;

	sc_signal< sc_uint<2> > mpc, mad, mb;


	sc_signal< operacao > ula;

	sc_signal< sc_uint<16> > instrucao;

	sc_signal < sc_bv<4> > flag;

	datapath *dp;
	controle *c;

	SC_CTOR(processador) {

		dp = new datapath("datapath");
		c = new controle("controle");

		dp->clock(clock);
		c->clock(clock);


		dp->reset(reset);
		c->reset(reset);


		dp->msp(msp);
		c->msp(msp);

		dp->mreg(mreg);
		c->mreg(mreg);

		dp->ms2(ms2);
		c->ms2(ms2);

		dp->ma(ma);
		c->ma(ma);

		dp->wpc(wpc);
		c->wpc(wpc);

		dp->wsp(wsp);
		c->wsp(wsp);

		dp->wir(wir);
		c->wir(wir);

		dp->wab(wab);
		c->wab(wab);

		dp->wula(wula);
		c->wula(wula);

		dp->wreg(wreg);
		c->wreg(wreg);

		dp->wnz(wnz);
		c->wnz(wnz);

		dp->wcv(wcv);
		c->wcv(wcv);

		c->ce(ce);
		c->rw(rw);
		c->halt(halt);
		c->wait_r8(wait_r8);

		dp->mpc(mpc);
		c->mpc(mpc);

		dp->mad(mad);
		c->mad(mad);

		dp->mb(mb);
		c->mb(mb);

		dp->ula(ula);
		c->ula(ula);

		dp->flag(flag);
		c->flag(flag);

		dp->instrucao(instrucao);
		c->ir(instrucao);

		dp->endereco(endereco);

		dp->dataout(dataout);

		dp->datain(datain);
	}
};
