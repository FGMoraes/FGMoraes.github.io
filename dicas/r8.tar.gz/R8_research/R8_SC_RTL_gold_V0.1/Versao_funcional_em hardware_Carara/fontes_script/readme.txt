Para transformar o c�digo SystemC para VHDL tendo como alvo a plataforma Virtex XCV800 utilizando o dc_shell:

	dc_shell < virtex.txt