// Test Bench
#include "processador.h"
#include "sinais.h"

int sc_main(int argc, char* argv[]) {

	sc_clock clk("clock", 20, 0.5, 0, false);

	sc_signal< sc_uint<16> > datain, dataout, endereco;
	sc_signal < bool > reset, rw, ce, halt;

	sinais s1("sinais");
	processador p("r8");


	p.clock(clk);
	s1.clock(clk);

	p.reset(reset);
	s1.reset(reset);

	p.datain(datain);
	s1.dataout(datain);

	p.dataout(dataout);
	s1.datain(dataout);

	p.endereco(endereco);
	s1.addr(endereco);

	p.ce(ce);
	s1.ce(ce);

	p.rw(rw);
	s1.rw(rw);

	p.halt(halt);

	sc_trace_file *tf = sc_create_vcd_trace_file("//home3//gaph//carara//gtkwave//sinais");
	//sc_trace_file *tf = sc_create_vcd_trace_file("h:\\gtkwave\\sinais");
	sc_trace(tf, clk.signal(), "CLOCK");
	sc_trace(tf, reset, "RESET");
	sc_trace(tf, p.dp->ir, "IR");
	sc_trace(tf, p.dp->datain, "DATAIN");
	sc_trace(tf, p.dp->pc, "PC");
	sc_trace(tf, p.dp->sp, "SP");
	sc_trace(tf, p.dp->br->r[0], "REG(0)");
	sc_trace(tf, p.dp->br->r[1], "REG(1)");
	sc_trace(tf, p.dp->br->r[2], "REG(2)");
	sc_trace(tf, p.dp->br->r[3], "REG(3)");
	sc_trace(tf, p.dp->br->r[4], "REG(4)");
	sc_trace(tf, p.dp->br->r[5], "REG(5)");
	sc_trace(tf, p.dp->br->r[6], "REG(6)");
	//sc_trace(tf, p.dp->br->source1, "S1");
	//sc_trace(tf, p.dp->br->source2, "S2");
	//sc_trace(tf, p.dp->rA, "RA");
	//sc_trace(tf, p.dp->rB, "RB");
	//sc_trace(tf, p.dp->opA, "opA");
	//sc_trace(tf, p.dp->opB, "opB");
	//sc_trace(tf, p.dp->br->ms2, "MS2");
	sc_trace(tf, dataout, "DATAOUT");
	sc_trace(tf, endereco, "ADDR");
	sc_trace(tf, rw, "RW");
	sc_trace(tf, ce, "CE");
	sc_trace(tf, p.flag, "FLAGS");
	sc_trace(tf, halt,"HALT");
	sc_trace(tf, p.dp->wnz, "WNZ");
	sc_trace(tf, p.dp->wcv, "WCV");
	sc_trace(tf, p.dp->mad, "MAD");
	//sc_trace(tf, p.dp->wsp, "WSP");



	//sc_trace(tf, dp.outula, "outula");
	sc_trace(tf, p.dp->rula, "rula");
	sc_trace(tf, p.c->atual, "ATUAL");
	//sc_trace(tf, dp.wir, "WIR");
	/*sc_trace(tf, S2, "S2");
	for ( int i=0; i<16; i++ ) {
		sprintf(stbuf, "REG(%d)", i);
		sc_trace(tf, br.reg[i]->Q, stbuf);
	}*/

	sc_start(10000, SC_NS);
	sc_close_vcd_trace_file(tf);

	return 0;
}
