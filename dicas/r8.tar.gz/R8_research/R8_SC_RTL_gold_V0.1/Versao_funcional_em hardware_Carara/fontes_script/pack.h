// Estados
#define IDLE	0
#define FETCH	1
#define REG		2
#define ULA		3
#define WBACK	4
#define FIM		5

// Instu��es
#define ADD		0
#define SUB		1
#define	AND		2
#define	OR		3
#define XOR		4
#define ADDI	5
#define SUBI	6
#define LDL		7
#define LDH		8
#define LD		9
#define ST		0x0A

#define OUTRAS	0x0B
#define SL0		0
#define SL1		1
#define SR0		2
#define SR1		3
#define NOT		4
#define NOP		5
#define HALT	6
#define LDSP	7
#define RTS		8
#define POP		9
#define PUSH	0x0A

#define SALTOR	0xC
#define JMPR	0
#define JMPNR	1
#define JMPZR	2
#define JMPCR	3
#define JMPVR	4
#define JMP		5
#define JMPN	6
#define JMPZ	7
#define JMPC	8
#define JMPV	9
#define JSRR	0xA
#define JSR		0xB

#define SALTOD	0xE
#define JMPND	0
#define JMPZD	1
#define JMPCD	2
#define JMPVD	3

#define JMPD	0x0D
#define JSRD	0x0F


// Flags
#define N		0
#define Z		1
#define C		2
#define V		3


#define WRITE	false
#define READ	true

typedef enum {add=0, sub=1, e=2, ou=3, oux=4, subi=5, ldl=6, ldh=7, sl0=8, sl1=9, sr0=10, sr1=11, not_opA=12, passa_opA=13, passa_opB=14, inc_opB=15}operacao;
