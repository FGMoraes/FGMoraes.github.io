// Registrador de uso geral - SENSIVEL A BORDA DE DESCIDA

#include <systemc.h>

SC_MODULE(reg16) {

	sc_in< bool > clock, reset, ce;
	sc_in< sc_uint<16> > D;

	sc_out< sc_uint<16> > Q;

	void reg();

	SC_CTOR(reg16) {
		SC_METHOD(reg);
		sensitive_pos << reset;
		sensitive_neg << clock;
	}
};

void reg16::reg() {

	if (reset)
		Q = 0;

	else if (ce)
		Q = D;
}
