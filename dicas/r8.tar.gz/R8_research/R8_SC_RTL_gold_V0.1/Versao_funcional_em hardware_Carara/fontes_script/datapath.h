// Gera vhdl
// Nao da pra usar + nem - para sintetizar pra virtex

#include "bc_regs.h"
#include "pack.h"

SC_MODULE(datapath) {

	sc_in< bool > clock, reset,
		msp, mreg, ms2, ma, wpc, wsp, wir, wab, wula, wreg, wnz, wcv;	//
	sc_in< sc_uint<2> > mpc, mad, mb;									// microinstrucao
	sc_in< operacao > ula;												//
	sc_in< sc_uint<16> > datain;


	sc_out< sc_uint<16> > endereco, dataout, instrucao;
	sc_out< sc_bv<4> > flag;


	sc_signal< sc_uint<16> > dtreg, dtpc, dtsp, s1, s2, outula, pc, sp,
			ir, rA, rB, rula, opA, opB, somaA, somaB, soma;


	sc_uint<16> s_opA, s_opB, s_outula;	// variaveis
	sc_bv<4> s_flag;					// auxiliares

	bc_regs *br;
	reg16 *rpc, *rsp, *rir, *reg_a, *reg_b, *reg_ula;

	void flags();
	void muxPC();
	void muxSP();
	void mux_end();
	void muxOPA();
	void muxOPB();
	void mux_dtreg();
	void mux_dataout();
	void out_ula();
	void out_ir();

	sc_uint<16> full_adder(sc_uint<16> a, sc_uint<16> b, sc_uint<1> cin);
	bool fcarry(sc_uint<16> a, sc_uint<16> b, sc_uint<1> cin);


	SC_CTOR(datapath) {
		SC_METHOD(flags);
		sensitive_pos << reset;
		sensitive_neg << clock;

		SC_METHOD(muxPC);
		sensitive << datain << rula << pc << mpc;

		SC_METHOD(muxSP);
		sensitive << rula << sp << msp;

		SC_METHOD(mux_end);
		sensitive << rula << pc << sp << mad;

		SC_METHOD(muxOPA);
		sensitive << ir << rA << ma;

		SC_METHOD(muxOPB);
		sensitive << rB << pc << sp << mb;

		SC_METHOD(mux_dtreg);
		sensitive << rula << datain << mreg;

		SC_METHOD(mux_dataout);
		sensitive << opB << s2 << ir;

		SC_METHOD(out_ula);
		sensitive << opA << opB << ula;

		SC_METHOD(out_ir);
		sensitive << ir;

		// registradores do bloco de dados: banco, pc, sp, ir, rA, rB, rula

		br = new bc_regs("banco");
		rpc = new reg16("PC");
		rsp = new reg16("SP");
		rir = new reg16("IR");
		reg_a = new reg16("A");
		reg_b = new reg16("B");
		reg_ula = new reg16("RULA");

		br->clock(clock);
		br->reset(reset);
		br->wreg(wreg);
		br->ms2(ms2);
		br->ir(ir);
		br->inREG(dtreg);
		br->source1(s1);
		br->source2(s2);

		rpc->clock(clock);
		rpc->reset(reset);
		rpc->ce(wpc);
		rpc->D(dtpc);
		rpc->Q(pc);

		rsp->clock(clock);
		rsp->reset(reset);
		rsp->ce(wsp);
		rsp->D(dtsp);
		rsp->Q(sp);

		rir->clock(clock);
		rir->reset(reset);
		rir->ce(wir);
		rir->D(datain);
		rir->Q(ir);

		reg_a->clock(clock);
		reg_a->reset(reset);
		reg_a->ce(wab);
		reg_a->D(s1);
		reg_a->Q(rA);

		reg_b->clock(clock);
		reg_b->reset(reset);
		reg_b->ce(wab);
		reg_b->D(s2);
		reg_b->Q(rB);

		reg_ula->clock(clock);
		reg_ula->reset(reset);
		reg_ula->ce(wula);
		reg_ula->D(outula);
		reg_ula->Q(rula);
	}

};


//  flags de estado
void datapath::flags() {

	s_outula = outula.read();

	if ( reset )
		s_flag = 0;	// zera todos os 4 flags

	else {

		if ( wnz ) {
			s_flag[N] = s_outula[15];

			if ( s_outula & 0xFFFF )
				s_flag[Z] = false;
			else
				s_flag[Z] = true;
		}

		if ( wcv ) {

			s_flag[C] = fcarry(s_opA, s_opB,(s_opA[15] ^ s_opB[15])); // tavez seja or ao inves de xor

			if ( s_opA[15] == s_opB[15] )
				s_flag[V] = s_opA[15] ^ s_outula[15];
			else
		       	s_flag[V] = false;
		}
	}

	flag = s_flag;
}

void datapath::muxPC() {

	switch(mpc.read()) {
		case 0:
			dtpc = datain;
		break;

		case 1:
			dtpc = rula;
		break;

		case 2:
			//dtpc = pc.read() + 1;
			dtpc = full_adder(pc.read(),1,0);
		break;
	}
}

void datapath::muxSP() {

	sc_uint<16> um = 1;

	if ( msp )
		//dtsp = sp.read() - 1;
		dtsp = full_adder(sp.read(),~um,1);
	else
		dtsp = rula;
}

void datapath::mux_end() {

	switch(mad.read()) {
		case 0:
			endereco = rula;
		break;

		case 1:
			endereco = pc;
		break;

		case 2:
			endereco = sp;
		break;
	}
}

void datapath::muxOPA() {

	sc_uint<12> desloc;
	sc_uint<6> ext1 = 0x3F;
	sc_uint<4> ext2 = 0xF;
	sc_uint<8> zero = 0;

	if ( ma ) {
		desloc = ir.read().range(11,0);
		switch(ir.read().range(15,12)) {

			case JMPD:
			case SALTOD:
				if ( desloc[9] == 1 )
					opA = (ext1,desloc.range(9,0));
				else
					opA = (zero.range(5,0),desloc.range(9,0));
			break;

			case JSRD:
				if ( desloc[11] == 1 ) {
					opA = (ext2,desloc);
				}
				else
					opA = (zero.range(3,0),desloc);
			break;

			default:
				opA = (zero.range(7,0),ir.read().range(7,0));
			break;
		}
	}
	else
		opA = rA;
}

void datapath::muxOPB() {

	switch(mb.read()) {
		case 0:
			opB = rB;
		break;

		case 1:
			opB = pc;
		break;

		case 2:
			opB = sp;
		break;
	}
}

void datapath::mux_dtreg() {

	if ( mreg )
		dtreg = datain;
	else
		dtreg = rula;
}

void datapath::mux_dataout() {

	if ( ir.read().range(15,12) == 0x0A ||	// ST
		(ir.read().range(15,12) == 0x0B && ir.read().range(3,0) == 0x0A) ) // PUSH
		dataout = s2;
	else
		dataout = opB;
}

void datapath::out_ula() {

	sc_uint<16> A, B;
	sc_uint<1> um, zero;

	A = opA.read();
	B = opB.read();

	switch(ula) {

		case add:
			//outula = A + B;
			outula = full_adder(A,B,0);
			s_opA = A;
			s_opB = B;
		break;

		case sub:
			//outula = A - B;
			outula = full_adder(A,~B,1);
			s_opA = A;
			s_opB = ~B;
		break;

		case subi:
			//outula = B - A;
			outula = full_adder(B,~A,1);
			s_opA = B;
			s_opB = ~A;
		break;

		case e:
			outula = A & B;
		break;

		case ou:
			outula = A | B;
		break;

		case oux:
			outula = A ^ B;
		break;

		case ldl:
			outula = (B.range(15,8), A.range(7,0));
		break;

		case ldh:
			outula = (A.range(7,0), B.range(7,0));
		break;

		case sl0:
            outula = (A.range(14,0),zero);
		break;

		case sl1:
			outula = (A.range(14,0),um);
		break;

		case sr0:
			outula = (zero,A.range(15,1));
		break;

		case sr1:
			outula = (um,A.range(15,1));
		break;

		case not_opA:
			outula = ~A;
		break;

		case passa_opA:
			outula = A;
		break;

		case passa_opB:
			outula = B;
		break;

		case inc_opB:
			//outula = B + 1;
			outula = full_adder(B,1,0);
		break;

		default:
			//outula = A + B;
			outula = full_adder(A,B,0);
		break;
	}
}

void datapath::out_ir() {

	instrucao = ir;

}

sc_uint<16> datapath::full_adder(sc_uint<16> a, sc_uint<16> b, sc_uint<1> cin) {

	sc_uint<1> carry, carry_ant;
	sc_uint<16> s;

	for( int w=0; w<16; w++ ) {
		if ( w == 0 )
			carry = cin;
		s[w] = a[w] ^ b[w] ^ carry;
		carry_ant = carry;
		carry = (a[w] & b[w]) | (a[w] & carry)| (b[w] & carry);
	}

	return s;
}

// Verifica se deu carry
bool datapath::fcarry(sc_uint<16> a, sc_uint<16> b, sc_uint<1> cin) {

	sc_uint<1> carry, carry_ant;
	sc_uint<16> s;

	for( int w=0; w<16; w++ ) {
		if ( w == 0 )
			carry = cin;
		carry = (a[w] & b[w]) | (a[w] & carry)| (b[w] & carry);
	}

	return (bool)carry;
}
