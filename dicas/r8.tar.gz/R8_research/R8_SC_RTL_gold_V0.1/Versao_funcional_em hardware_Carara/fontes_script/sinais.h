#include <systemc.h>
#include <stdio.h>
#include <stdlib.h>

#define TAM	60000

void wait_ciclos( int ciclos ) {	// tranca a execu��o
	for ( int i=0; i<ciclos; i++)
		wait();
}

void load_ram(sc_uint<16> *ram, char *obj) {

	FILE *arq;
	char str[4];
	sc_uint<16> addr_data[2];
	sc_uint<4> caracter[4];


	if ( (arq = fopen(obj,"rt")) == NULL ) {
		printf("Erro na abertura do arquivo '%s'.\n",obj);
		exit(0);
	}

	while ( !feof(arq) ) {
		for (int b=0; b<2; b++) {
			fscanf (arq,"%s",str);
			if ( feof(arq) ) break;
			for(int a=0; a<4; a++) {
				switch(str[a]) {
					case '0':
					case '1':
					case '2':
					case '3':
					case '4':
					case '5':
					case '6':
					case '7':
					case '8':
					case '9':
						caracter[a] = str[a]-48;
					break;

					case 'A':
					case 'B':
					case 'C':
					case 'D':
					case 'E':
					case 'F':
						caracter[a] = str[a]-('A'-10);
					break;

					case 'a':
					case 'b':
					case 'c':
					case 'd':
					case 'e':
					case 'f':
							caracter[a] = str[a]-('a'-10);
					break;
				}
			}
			addr_data[b].range(15,12) = caracter[0];
			addr_data[b].range(11,8) = caracter[1];
			addr_data[b].range(7,4) = caracter[2];
			addr_data[b].range(3,0) = caracter[3];
		}
		ram[addr_data[0]] = addr_data[1];
	}

	fclose(arq);

}

SC_MODULE(sinais) {

	sc_in< bool > clock, ce, rw;
	sc_in< sc_uint<16> > addr;
	sc_in< sc_uint<16> > datain;

	sc_out < bool > reset;
	sc_out< sc_uint<16> > dataout;



	int bordas;

	sc_uint<16> ram[TAM];

	void mem();
	void rst();

	SC_CTOR(sinais) {
		SC_THREAD(rst);
		sensitive_pos << clock;

		SC_METHOD(mem);
		sensitive << addr << ce << rw;

		load_ram(ram,"somavetr8.txt");
	}
};

void sinais::mem() {	// rw = 0: write
						// rw = 1: read

	unsigned int ad = addr.read().to_int();

	if ( ce.read() && rw.read() && ad<TAM && ad>=0 )
		dataout.write(ram[ad]);

	else if ( ce.read() && !rw.read() && ad<TAM && ad>=0 )
		ram[ad] = datain.read();

}


void sinais::rst() {

	reset = true;
	wait(5, SC_NS);
	reset = false;
}
