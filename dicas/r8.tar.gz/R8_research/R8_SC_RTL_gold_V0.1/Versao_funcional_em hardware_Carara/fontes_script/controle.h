
#include "datapath.h"

SC_MODULE(controle) {

	sc_in< bool > clock, reset, wait_r8;
	sc_in< sc_uint<16> > ir;
	sc_in< sc_bv<4> > flag;


	sc_out< bool > ce, rw, halt,
		msp, mreg, ms2, ma, wpc, wsp, wir, wab, wula, wreg, wnz, wcv;	//
	sc_out< sc_uint<2> > mpc, mad, mb;									// microinstrucao
	sc_out< operacao > ula;												//

	sc_bv<4> s_flag;
	sc_uint<4> atual;	// estado atual da FSM

	void FSM();

	SC_CTOR(controle) {
		SC_METHOD(FSM);
		sensitive_pos << reset << clock;
	}
};

void controle::FSM() {

	if ( reset ) {
		atual = IDLE;
		halt = false;
	}

	else {

		switch(atual) {

			case IDLE:
				if ( wait_r8 ) {
					atual = IDLE;
					break;
				}
				else {
					atual = FETCH;

					ce = false;
					rw = WRITE;
				}

			break;

			case FETCH:
				if ( wait_r8 )
					atual = FETCH;

				else {
					atual = REG;

					wreg = false;
					wsp = false;
					wpc = false;
					wir = true;
					mad = 1;
					ce = true;
					rw = READ;
					ms2 = false;
				}
			break;

			case REG:

				if ( wait_r8 ) {
					wpc = false;
					atual = REG;
				}
				else {
					mpc = 2;
					wpc = true;


					wir = false;
					ce = false;
					rw = WRITE;

					wab = true;

					if ( ir.read().range(15,12) == OUTRAS && ir.read().range(3,0) == HALT ) {
						atual = FIM;
						break;
					}
					else
						atual = ULA;

					switch(ir.read().range(15,12)) {

						case ADD:
						case SUB:
						case AND:
						case OR:
						case XOR:
						case LD:
						case ST:
							ms2 = false;
						break;

						default:	// Resto das instrucoes
							ms2 = true;
						break;
					}
				}

			break;

			case ULA:
				if ( wait_r8 )
					atual = ULA;
				else {
					atual = WBACK;

					wpc = false;
					wab = false;

					wula = true;



					switch( ir.read().range(15,12) ) {

						case ADD:
							ula = add;
							ma = false;
							mb = 0;
							wnz = true;
							wcv = true;
						break;

						case SUB:
							ula = sub;
							ma = false;
							mb = 0;
							wnz = true;
							wcv = true;
						break;

						case AND:
							ula = e;
							ma = false;
							mb = 0;
							wnz = true;
						break;

						case OR:
							ula = ou;
							ma = false;
							mb = 0;
							wnz = true;
						break;

						case XOR:
							ula = oux;
							ma = false;
							mb = 0;
							wnz = true;
						break;

						case ADDI:
							ula = add;
							ma = true;
							mb = 0;
							wnz = true;
							wcv = true;
						break;

						case SUBI:
							ula = subi;
							ma = true;
							mb = 0;
							wnz = true;
							wcv = true;
						break;

						case LDL:
							ula = ldl;
							ma = true;
							mb = 0;
						break;

						case LDH:
							ula = ldh;
							ma = true;
							mb = 0;
						break;

						case LD:
							ula = add;
							ma = false;
							mb = 0;
						break;

						case ST:
							ula = add;
							ma = false;
							mb = 0;
							mad = 0;	// para o endereco estar estavel na subida do 4 ciclo
							ms2 = true;
						break;

						case SALTOD:
						case JMPD:
						case JSRD:
							ula = add;
							ma = true;
							mb = 1;
							mad = 2;	// JSRD, para o endereco estar estavel na subida do 4 ciclo
						break;

						case SALTOR:

							switch(ir.read().range(3,0)) {	// Seleciona o SALTOR

								case JMP:
								case JMPN:
								case JMPZ:
								case JMPC:
								case JMPV:
									ula = passa_opA;
									ma = false;
								break;

								case JSRR:
									ula = add;
									mb = 1;		// PC vai para a pilha
									ma = false;
									mad = 2;	// para o endereco estar estavel na subida do 4 ciclo
								break;

								case JSR:
									ula = passa_opA;
									mb = 1;		// PC vai para a pilha
									mad = 2;	// para o endereco estar estavel na subida do 4 ciclo
								break;

								default:		// JMPR, JMPNR, JMPZR, JMPCR, JMPVR
									ula = add;
									ma = false;
									mb = 1;
								break;
							}

						break;

						case OUTRAS:

							switch(ir.read().range(3,0)) {

								case SL0:
									ula = sl0;
									ma = false;
									wnz = true;
								break;

								case SL1:
									ula = sl1;
									ma = false;
									wnz = true;
								break;

								case SR0:
									ula = sr0;
									ma = false;
									wnz = true;
								break;

								case SR1:
									ula = sr1;
									ma = false;
									wnz = true;
								break;

								case NOT:
									ula = not_opA;
									ma = false;
									wnz = true;
								break;

								case LDSP:
									ula = passa_opA;
									ma = false;
								break;

								case RTS:
									ula = inc_opB;
									mb = 2;
								break;

								case POP:
									ula = inc_opB;
									mb = 2;
								break;

								case PUSH:
									ula = passa_opB;
									mb = 2;
									mad = 0;	// para o endereco estar estavel na subida do 4 ciclo
								break;

								default:
									ula = add;
									wnz = false;
									wcv = false;
								break;
							}
						break;

						default:
							ula = add;
							wnz = false;
							wcv = false;
						break;
					}
				}
			break;

			case WBACK:											// 4
				if ( wait_r8 )
					atual = WBACK;
				else {
					atual = FETCH;

					wula = false;
					wnz = false;
					wcv = false;



					switch( ir.read().range(15,12) ) {
						case ADD:
						case SUB:
						case AND:
						case OR:
						case XOR:
						case ADDI:
						case SUBI:
						case LDL:
						case LDH:
							wreg = true;
							mreg = false;
							ce = false;
						break;

						case LD:
							wreg = true;
							mreg = true;
							mad = 0;
							ce = true;
							rw = READ;
						break;

						case ST:
							wreg = false;
							rw = WRITE;
							ce = true;
						break;

						case JMPD:	// ok
							wpc = true;
							mpc = 1;
						break;

						case JSRD:
							wpc = true;
							mpc = 1;
							wsp = true;
							msp = true;
							ce = true;
							rw = WRITE;
						break;

						case SALTOR:
							mpc = 1;
							mad = 0;
							switch( ir.read().range(3,0) ) {
								case JMPR://ok
								case JMP: //ok
									wpc = true;
								break;

								case JMPNR://ok
								case JMPN:// ok
									if ( flag.read()[N] == 1 )
										wpc = true;
									else
										wpc = false;
								break;

								case JMPZR://ok
								case JMPZ:// ok
									if ( flag.read()[Z] == 1 )
										wpc = true;
									else
										wpc = false;
								break;

								case JMPCR:
								case JMPC:
									if ( flag.read()[C] == 1 )
										wpc = true;
									else
										wpc = false;
								break;

								case JMPVR:
								case JMPV:
									if ( flag.read()[V] == 1 )
										wpc = true;
									else
										wpc = false;
								break;

								case JSRR: // ok
								case JSR: // ok
									wpc = true;
									mpc = 1;
									wsp = true;
									msp = true;
									ce = true;
									rw = WRITE;
								break;

								default:
									wpc = false;
									ce = false;
								break;
							}
						break;

						case SALTOD:
							mpc = 1;
							switch( ir.read().range(11,10) ) {
								case JMPND:	// ok
									if ( flag.read()[N] == 1 )
										wpc = true;
									else
										wpc = false;
								break;

								case JMPZD:	// ok
									if ( flag.read()[Z] == 1 )
										wpc = true;
									else
										wpc = false;
								break;

								case JMPCD:
									if ( flag.read()[C] == 1 )
										wpc = true;
									else
										wpc = false;
								break;

								case JMPVD:
									if ( flag.read()[V] == 1 )
										wpc = true;
									else
										wpc = false;
								break;

								default:
									wpc = false;
								break;
							}
						break;

						case OUTRAS:
							switch( ir.read().range(3,0) ) {
								case SL0:
								case SL1:
								case SR0:
								case SR1:
								case NOT:
									wreg = true;
									mreg = false;
									ce = false;
								break;

								case LDSP:
									wsp = true;
									msp = false;
									wreg = false;
									ce = false;
								break;

								case POP:
									wreg = true;
									mreg = true;
									wsp = true;
									msp = false;
									mad = 0;
									ce = true;
									rw = READ;
								break;

								case PUSH:
									wreg = false;
									wsp = true;
									msp = true;
									ce = true;
									rw = WRITE;
								break;

								case RTS:
									wsp = true;
									msp = false;
									wpc = true;
									mpc = 0;
									mad = 0;
									ce = true;
									rw = READ;
								break;

								default:	// NOP
									wreg = false;
									ce = false;
								break;
							}
						break;

						default:
							wreg = false;
							ce = false;
						break;
					}
				}
			break;

			case FIM:
				atual = FIM;
				wpc = false;
				wreg = false;
				wsp = false;
				wir = false;
				halt = true;
				ce = false;
				rw = WRITE;
			break;
		}
	}
}

