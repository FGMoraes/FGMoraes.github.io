// registrador.cpp: source file
#include "r8.h"
#include "registrador.h"
void registrador::asynchRstSynchCE(){
	if(rst.read()=="1"){
		Q.write(sc_lv<WIDTHR8> ("0"));
	}else if(ce.read()=="1")
		Q.write(D.read());
}
