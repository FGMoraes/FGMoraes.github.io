// oner8onem.h: header file

#ifndef __oner8onem_h
#define __oner8onem_h

#ifndef SYNTHESIS
#include <ccss_systemc.h>
#endif

#define CCSS_USE_SC_CTOR

// forward declarations
struct mem;
struct processor;
struct test_bench;
class display;

#ifdef CCSS_USE_SC_CTOR
#define CCSS_INIT_CHANNELS_PREFIX : 
#undef CCSS_USE_SC_CTOR
#else
#define CCSS_INIT_CHANNELS_PREFIX , 
#endif

#define CCSS_INIT_CHANNELS  CCSS_INIT_CHANNELS_PREFIX \
    address("address") \
    , ce("ce") \
    , ck("ck") \
    , data("data") \
    , rst("rst") \
    , rw("rw")

class oner8onem
: public sc_module
{

public:
    // channels
    sc_signal<sc_lv<16> > address;
    sc_signal<sc_logic> ce;
    sc_signal<sc_logic> ck;
    sc_signal<sc_lv<16> > data;
    sc_signal<sc_logic> rst;
    sc_signal<sc_logic> rw;

    // module instances
    mem *M1;
    processor *R8;
    test_bench *TB1;
    display *V1;
    sc_clock *clk;

    // initialize parameters
    virtual void InitParameters() {
    }
    // create the schematic
    virtual void InitInstances();

    // delete the schematic
    virtual void DeleteInstances();

	// default constructor
	SC_CTOR(oner8onem)
	  CCSS_INIT_CHANNELS
	{
		oner8onem::InitParameters();

		// process declarations

		oner8onem::InitInstances();
	}

#ifndef SYNTHESIS
	// destructor
	virtual ~oner8onem()
	{
		oner8onem::DeleteInstances();
	}
#endif

}; // end module oner8onem
#undef CCSS_INIT_CHANNELS_PREFIX
#undef CCSS_INIT_CHANNELS

#endif
