#include <systemc.h>

#define WIDTHR8 16
/*
#define SIMULATION_TIME 5000
#define NFLAGS 4
#define MEM_SIZE 512 
#define LOAD_FILE "load.obj"

typedef sc_lv<2> reg2;

typedef sc_lv<NFLAGS> reg4;

typedef sc_lv<WIDTHR8> reg16;

typedef enum {add=0, sub=1, e=2, ou=3, oux=4, addi=5, subi=6, ldl=7, ldh=8, ld=9, st=10, sl0=11, sl1=12, sr0=13, sr1=14, notA=15, nop=16, hlt=17, ldsp=18, rts=19, pop=20, push=21, saltoR=22, salto=23, saltoD=24, jsrr=25, jsr=26, jsrd=27}instruction;
*/
//--------------------------------------------------------------------------
//	Tracing enumerated types
//--------------------------------------------------------------------------
/*
const char* status_as_string[]={"add", "sub", "e", "ou", "oux", "addi", "subi", "ldl", "ldh", "ld", "st", "sl0", "sl1", "sr0", "sr1", "notA", "nop","hlt","ldsp","rts","pop","push","saltoR","salto","saltoD","jsrr","jsr","jsrd", NULL};
*/
/*
struct flag{
	reg2 lnz;
	reg2 lcv;
	/* Built-in comparison operators
	Are used to determine whether or not a value changed, which generate an event. The method below defines the fields that are to be compared and how the comparison is made. An event occurs if the comparison result indicates that the previous flag and new flag are different.

	inline bool operator == ( const flag& flags) const
	{
		return(flags.lnz == lnz &&
			flags.lcv == lcv);
	} 
}; 

inline
ostream&
operator << (ostream& os, const flag& flags)
{
	return os << flags.lnz << '/' << flags.lcv;
}

//--------------------------------------------------------------------
// Suport for tracing user-defined aggregate data-types
//--------------------------------------------------------------------
inline
void
sc_trace(sc_trace_file* tf, const flag& flags, const sc_string& name)
{
	sc_trace(tf, flags.lnz, name + ".lnz");
	sc_trace(tf, flags.lcv, name + ".lcv");
}
//------------------------------------------------------------
// Support for tracing vectors
//------------------------------------------------------------
template <class T>
inline
void sc_trace_vector(sc_trace_file* tf, const T x[], const sc_string& name, int length)
{
	for(int i=0; i<length; i++)
		sc_trace(tf, x[i], name + "." + sc_string::to_string("%d", i));
}
*/
