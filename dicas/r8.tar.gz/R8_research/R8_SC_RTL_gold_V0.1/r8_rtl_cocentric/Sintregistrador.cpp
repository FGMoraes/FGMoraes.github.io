//#include "systemc.h"
#include "r8.h"
#include "registrador.h"

void registrador::asynchRstSynchCE(){
  
  if(rst.read()){
    Q.write(0);
  }
  else if(ce.read())
    Q.write(D.read());
}
