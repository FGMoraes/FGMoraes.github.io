
#ifdef CCSS_USE_SC_CTOR
#define CCSS_INIT_MEMBERS_PREFIX : 
#undef CCSS_USE_SC_CTOR
#else
#define CCSS_INIT_MEMBERS_PREFIX , 
#endif

#define CCSS_INIT_MEMBERS  CCSS_INIT_MEMBERS_PREFIX \
    rst("rst") \
    , ck("ck") \
    , ce("ce") \
    , D("D") \
    , Q("Q")

struct registrador
: public sc_module
{

    // ports

    // Module port declarations 
    sc_in<sc_logic> rst;
    sc_in<sc_logic> ck;
    sc_in<sc_logic> ce;
    sc_in<sc_lv<WIDTHR8> > D;
    sc_out<sc_lv<WIDTHR8> > Q;

    // initialize parameters
    virtual void InitParameters() {
    }

	//Method process declarations
	void asynchRstSynchCE();

	//Module constructor
	SC_CTOR(registrador){
		//register process
		SC_METHOD(asynchRstSynchCE);
		//Declare sensitivity list
		sensitive_pos << rst;
                sensitive_neg << ck;
	}
}; // end module registrador
#undef CCSS_INIT_MEMBERS_PREFIX
#undef CCSS_INIT_MEMBERS

