SC_MODULE(registrador){

    // ports

    // Module port declarations 
    sc_in< bool > rst;
    sc_in< bool > ck;
    sc_in< bool > ce;
    sc_in<sc_lv< WIDTHR8 > > D;
    sc_out<sc_lv< WIDTHR8 > > Q;

	//Method process declarations
	void asynchRstSynchCE();

	//Module constructor
	SC_CTOR(registrador){
		//register process
		SC_METHOD(asynchRstSynchCE);
		//Declare sensitivity list
		sensitive_pos << rst;
                sensitive_neg << ck;
	}
}; // end module registrador
