#include "r8.h"
#include "oner8onem.h"
int sc_main(int argc, char **argv)
{
    sc_string sim_name;
    char *sim_name_env_var;
    sim_name_env_var = getenv("SIM_NAME");
    sim_name = (sim_name_env_var && strlen(sim_name_env_var)) ? sim_name_env_var : "top_instance_name";
    sc_set_default_time_unit(p, SC_SEC);
    oner8onem top_instance_name(sim_name.c_str());
    sc_start(10000);
    return 0;
}
