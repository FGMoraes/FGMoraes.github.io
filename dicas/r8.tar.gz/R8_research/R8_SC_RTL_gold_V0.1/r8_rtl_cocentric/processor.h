
#ifdef CCSS_USE_SC_CTOR
#define CCSS_INIT_MEMBERS_PREFIX : 
#undef CCSS_USE_SC_CTOR
#else
#define CCSS_INIT_MEMBERS_PREFIX , 
#endif

#define CCSS_INIT_MEMBERS  CCSS_INIT_MEMBERS_PREFIX \
    rst("rst") \
    , ck("ck") \
    , data("data") \
    , address("address") \
    , ce("ce") \
    , rw("rw")

struct processor
: public sc_module
{

    // ports

    // Module port declarations 
    sc_in<sc_logic> rst;
    sc_in<sc_logic> ck;

    // Data port
    sc_inout<reg16> data;
    sc_out<reg16> address;
    sc_out<sc_logic> ce;
    sc_out<sc_logic> rw;

    // initialize parameters
    virtual void InitParameters() {
    }

	sc_signal<flag> flags;
	sc_signal<reg16> ir;
	sc_signal<reg2> mpc;
	sc_signal<sc_logic> msp;
	sc_signal<reg2> mad;
	sc_signal<sc_logic> mreg;
	sc_signal<sc_logic> ms2;
	sc_signal<sc_logic> ma;
	sc_signal<reg2> mb;
	sc_signal<sc_logic> wpc;
	sc_signal<sc_logic> wsp;
	sc_signal<sc_logic> wir;
	sc_signal<sc_logic> wab;
	sc_signal<sc_logic> wula;
	sc_signal<sc_logic> wreg;
	sc_signal<sc_logic> wnz;
	sc_signal<sc_logic> wcv;
	sc_signal<sc_logic> sce;
	sc_signal<sc_logic> srw;
	sc_signal<instruction> ula;

	datapath DT;
	controle CT;

	void setrw();

	SC_CTOR(processor):DT("datapath"), CT("control"){
		DT.rst(rst);
		DT.ck(ck);
		DT.mpc(mpc);
		DT.msp(msp);
		DT.mad(mad);
		DT.mreg(mreg);
		DT.ms2(ms2);
		DT.ma(ma);
		DT.mb(mb);
		DT.wpc(wpc);
		DT.wsp(wsp);
		DT.wir(wir);
		DT.wab(wab);
		DT.wula(wula);
		DT.wreg(wreg);
		DT.wnz(wnz);
		DT.wcv(wcv);
		DT.ce(sce);
		DT.rw(srw);
		DT.ula(ula);
		DT.instructor(ir);
		DT.address(address);
		DT.flags(flags);
		DT.data(data);

		CT.rst(rst);
		CT.ck(ck);
		CT.flags(flags);
		CT.ir(ir);
		CT.mpc(mpc);
		CT.msp(msp);
		CT.mad(mad);
		CT.mreg(mreg);
		CT.ms2(ms2);
		CT.ma(ma);
		CT.mb(mb);
		CT.wpc(wpc);
		CT.wsp(wsp);
		CT.wir(wir);
		CT.wab(wab);
		CT.wula(wula);
		CT.wreg(wreg);
		CT.wnz(wnz);
		CT.wcv(wcv);
		CT.ce(sce);
		CT.rw(srw);
		CT.ula(ula);

		SC_METHOD(setrw);
		sensitive << sce << srw;
	}
}; // end module processor
#undef CCSS_INIT_MEMBERS_PREFIX
#undef CCSS_INIT_MEMBERS

