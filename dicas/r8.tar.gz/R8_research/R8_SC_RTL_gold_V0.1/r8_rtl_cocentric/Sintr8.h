#include <systemc.h>

#define WIDTHR8 16

