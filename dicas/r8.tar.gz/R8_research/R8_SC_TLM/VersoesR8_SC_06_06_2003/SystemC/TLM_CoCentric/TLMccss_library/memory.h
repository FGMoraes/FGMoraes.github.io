#ifndef __memory_h
#define __memory_h

#include <systemc.h>
#include "additional/estAsm.h"
#include "additional/listAsm.h"
#include "additional/common_defs.h"
#include "interfaces/memR8If.h"

#ifdef CCSS_USE_SC_CTOR
#define CCSS_INIT_MEMBERS_PREFIX : 
#undef CCSS_USE_SC_CTOR
#else
#define CCSS_INIT_MEMBERS_PREFIX , 
#endif

#ifndef SYNTHESIS
#define CCSS_INIT_MEMBERS  CCSS_INIT_MEMBERS_PREFIX \
    porta("porta")
#else
#define CCSS_INIT_MEMBERS 
#endif

struct memory
: public sc_module, public listAsm
{
 public:


  typedef sc_uint<16> ad_type;
  typedef sc_lv<16> word_type;
    // ports
    sc_port<memR8If, 1> porta;

    // initialize parameters
    virtual void InitParameters() {
    }

  word_type *memoria;
  ad_type address;

  SC_HAS_PROCESS(memory);

  memory(sc_module_name name) : sc_module(name), listAsm(){

    carregaSym();

    memoria = new word_type [mem_size];

    fillMem();

    SC_THREAD(sendWord);
    SC_THREAD(receiveWord);
  }

  ~memory(){
		int i;

        for(i=0; i<=getNroLinhas(); i++){
			cout << "memoria[" << i << "] : " << memoria[i].to_uint() << endl;
		};

	}

  void sendWord();
  void receiveWord();
  void fillMem();

}; // end module memory
#undef CCSS_INIT_MEMBERS_PREFIX
#undef CCSS_INIT_MEMBERS


#endif
