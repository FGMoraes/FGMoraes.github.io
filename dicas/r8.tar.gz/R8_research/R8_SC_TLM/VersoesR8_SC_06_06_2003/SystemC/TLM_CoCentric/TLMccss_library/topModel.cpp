// topModel.cpp: source file

#include "processorR8.h"
#include "memory.h"
#include "memChl.h"
#include "topModel.h"

void topModel::InitInstances() {
    M1 = new processorR8("M1");
    M2 = new memory("M2");
    M3 = new memoryChl("M3");

    M1->portaMem(*M3);
    M2->porta(*M3);
}

void topModel::DeleteInstances() {
    if (M1) {delete M1; M1 = 0;}
    if (M2) {delete M2; M2 = 0;}
    if (M3) {delete M3; M3 = 0;}
}

