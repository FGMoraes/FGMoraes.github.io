// newTopModel.cpp: source file

#include "memory.h"
#include "memChl.h"
#include "processorR8.h"
#include "newTopModel.h"

void newTopModel::InitInstances() {
    M3 = new memory("M3");
    canalMemoria = new memoryChl("canalMemoria");
    processadorR8 = new processorR8("processadorR8");

    processadorR8->portaMem(*canalMemoria);
    M3->porta(*canalMemoria);
}

void newTopModel::DeleteInstances() {
    if (M3) {delete M3; M3 = 0;}
    if (canalMemoria) {delete canalMemoria; canalMemoria = 0;}
    if (processadorR8) {delete processadorR8; processadorR8 = 0;}
}

