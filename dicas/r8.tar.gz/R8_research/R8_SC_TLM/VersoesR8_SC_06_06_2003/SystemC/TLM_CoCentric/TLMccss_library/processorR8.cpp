// processorR8.cpp: source file

#include "processor.h"
#include "bcregs.h"
#include "flagNZCVChl.h"
#include "bcregsChl.h"
#include "processorR8.h"

void processorR8::InitInstances() {
    M1 = new processor("M1");
    M2 = new bcregs("M2");
    M3 = new flagNZCVChl("M3");
    M4 = new bcregsChl("M4");

    M2->porta(*M4);
    M1->portaRegs(*M4);
    M1->portaFlag(*M3);
    M1->portaMem(portaMem);
}

void processorR8::DeleteInstances() {
    if (M1) {delete M1; M1 = 0;}
    if (M2) {delete M2; M2 = 0;}
    if (M3) {delete M3; M3 = 0;}
    if (M4) {delete M4; M4 = 0;}
}

