#ifndef __estAsm_h
#define __estAsm_h

#include <string.h>

class estAsm{
  private:
    estAsm *prox;
    char localAddress[17];
    char localWord[17];
    int linha;
    void convert_hex2bin(char * source, char * target);

  public:
    estAsm(char * word, char * address){
      convert_hex2bin(address, localAddress);
      convert_hex2bin(word, localWord);
      prox = NULL;
      linha = 0;
    };
    ~estAsm(){ };
    char * getAddress();
    char * getWord();
    estAsm *getProx(){ return prox; };
    void setProx(estAsm *next) { prox=next; };
};

#endif
