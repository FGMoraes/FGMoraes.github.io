// memoryChl.cpp: source file

#include "memChl.h"

