#ifndef __R8MemIf_h
#define __R8MemIf_h
 
#include <systemc.h>
#include "../additional/common_defs.h" 

class R8MemIf : virtual public sc_interface{ 
  public: 
    typedef sc_lv<word_size>  word_type; 
    typedef sc_uint<address_size> ad_type; 
 
    // instructions 
    virtual void getNxtWord(word_type *) = 0; 
    virtual void updatePC(ad_type) = 0; 
    virtual void getPC(ad_type *) = 0; 
 
    // data 
    virtual void readMemory(ad_type, word_type *) = 0; 
    virtual void writeMemory(ad_type, word_type) = 0; 
    virtual void startupSP(ad_type) = 0; 
    virtual void execPOP(word_type *) = 0; 
    virtual void execPUSH(word_type) = 0; 
 
}; 
 
#endif 
