#include "estAsm.h"

char * estAsm::getAddress(){
  return localAddress;
}

char * estAsm::getWord(){
  return localWord;
}

void estAsm::convert_hex2bin(char * source, char * target){
  int i;
  target[0]='\0';
  for(i=0; i<4; i++){
    switch(source[i]){
    case '0':
      strcat(target,"0000");
      break;
    case '1':
      strcat(target,"0001");
      break;
    case '2':
      strcat(target,"0010");
      break;
    case '3':
      strcat(target,"0011");
      break;
    case '4':
      strcat(target,"0100");
      break;
    case '5':
      strcat(target,"0101");
      break;
    case '6':
      strcat(target,"0110");
      break;
    case '7':
      strcat(target,"0111");
      break;
    case '8':
      strcat(target,"1000");
      break;
    case '9':
      strcat(target,"1001");
      break;
    case 'A':
      strcat(target,"1010");
      break;
    case 'B':
      strcat(target,"1011");
      break;
    case 'C':
      strcat(target,"1100");
      break;
    case 'D':
      strcat(target,"1101");
      break;
    case 'E':
      strcat(target,"1110");
      break;
    case 'F':
      strcat(target,"1111");
      break;
    };
  };
  target[16]='\0';
}
