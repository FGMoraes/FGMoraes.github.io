#ifndef _bcregs_h
#define _bcregs_h

#include <systemc.h>
#include "interfaces/regR8If.h"

#ifdef CCSS_USE_SC_CTOR
#define CCSS_INIT_MEMBERS_PREFIX : 
#undef CCSS_USE_SC_CTOR
#else
#define CCSS_INIT_MEMBERS_PREFIX , 
#endif

#ifndef SYNTHESIS
#define CCSS_INIT_MEMBERS  CCSS_INIT_MEMBERS_PREFIX \
    porta("porta")
#else
#define CCSS_INIT_MEMBERS 
#endif

struct bcregs
: public sc_module
{
 public:


  typedef sc_uint<4> reg_type;
  typedef sc_lv<16>  value_type;
    // ports
    sc_port<regR8If, 1> porta;

    // initialize parameters
    virtual void InitParameters() {
    }


  value_type registers[16];
  reg_type reg1,reg2;
  value_type val1,val2;
  int i;

  SC_HAS_PROCESS(bcregs);

  bcregs (sc_module_name name): sc_module(name){

    for(i=0;i<16;i++){
      registers[i] = "0000000000000000";
    };

    SC_THREAD(updateRegs);
    SC_THREAD(sendRegValue);
    SC_THREAD(sendRegsValue);
  }

  void updateRegs();
  void sendRegValue();
  void sendRegsValue();

}; // end module bcregs
#undef CCSS_INIT_MEMBERS_PREFIX
#undef CCSS_INIT_MEMBERS


#endif
