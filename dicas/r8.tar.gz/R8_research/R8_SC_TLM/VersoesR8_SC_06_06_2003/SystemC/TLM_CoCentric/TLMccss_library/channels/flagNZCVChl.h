#ifndef __flagNZCVChl_h
#define __flagNZCVChl_h

#include <systemc.h>
#include "../interfaces/R8FlagsIf.h"
#include "../additional/common_defs.h"

#ifdef CCSS_USE_SC_CTOR
#undef CCSS_USE_SC_CTOR
#endif

#define CCSS_INIT_MEMBERS 

class flagNZCVChl
: public sc_module, public R8FlagsIf
{

public:
    // ports

    // initialize parameters
    virtual void InitParameters() {
    }


  public:

    typedef sc_uint<2> flag_type;
    typedef sc_logic   flag_value;
    typedef sc_lv<16>  source_type;
    typedef sc_lv<17>  result_type;

    flagNZCVChl(sc_module_name name) : sc_channel(name) {
      Flags[negative]=0;
      Flags[zero]=0;
      Flags[carry]=0;
      Flags[overflow]=0;
    }

    ~flagNZCVChl(){
      cout << "fim do processo" << endl;
    }

    void testlnz(result_type result){
      sc_lv<16>  vtmp;
      sc_int<16> itmp;

      vtmp = result.range(15,0);
      itmp=vtmp;

      Flags[negative]=(itmp<0)?1:0;
      Flags[zero]=(itmp==0)?1:0;
    };

    void testlcv(result_type result, source_type source1, source_type source2){

      Flags[carry]=result[16];
      Flags[overflow]=((source1[15] == source2[15]) &&(result[15] != source2[15]))?1:0;

    };

    void testlnz_lcv(result_type result, source_type source1, source_type source2){
      testlnz(result);
      testlcv(result, source1, source2);
    }

    flag_value getFlag(flag_type ft){
      return Flags[ft];
    };

  private:
    flag_value Flags[4];
}; // end module flagNZCVChl
#undef CCSS_INIT_MEMBERS


#endif
