// processorR8.h: header file

#ifndef __processorR8_h
#define __processorR8_h

#include <systemc.h>
#include "interfaces/R8MemIf.h"
#include "interfaces/R8FlagsIf.h"
#include "interfaces/R8RegsIf.h"

#ifndef SYNTHESIS
#include <ccss_systemc.h>
#endif

#define CCSS_USE_SC_CTOR

// forward declarations
struct processor;
struct bcregs;
class flagNZCVChl;
class bcregsChl;

#ifdef CCSS_USE_SC_CTOR
#define CCSS_INIT_CHANNELS_PREFIX : 
#undef CCSS_USE_SC_CTOR
#else
#define CCSS_INIT_CHANNELS_PREFIX , 
#endif

#ifndef SYNTHESIS
#define CCSS_INIT_CHANNELS  CCSS_INIT_CHANNELS_PREFIX \
    portaMem("portaMem")
#else
#define CCSS_INIT_CHANNELS 
#endif

class processorR8
: public sc_module
{

public:
    // ports
    sc_port<R8MemIf, 1> portaMem;

    // module instances
    processor *M1;
    bcregs *M2;
    flagNZCVChl *M3;
    bcregsChl *M4;

    // initialize parameters
    virtual void InitParameters() {
    }
    // create the schematic
    virtual void InitInstances();

    // delete the schematic
    virtual void DeleteInstances();

	// default constructor
	SC_CTOR(processorR8)
	  CCSS_INIT_CHANNELS
	{
		processorR8::InitParameters();

		// process declarations

		processorR8::InitInstances();
	}

#ifndef SYNTHESIS
	// destructor
	virtual ~processorR8()
	{
		processorR8::DeleteInstances();
	}
#endif

}; // end module processorR8
#undef CCSS_INIT_CHANNELS_PREFIX
#undef CCSS_INIT_CHANNELS

#endif
