
#include <stdio.h>
#include <stdlib.h>
#include "memory.h"

void memory::sendWord(){

    //******************************************
    //*  Passos para o envio de uma palavra    *
    //*                                        *
    //*  1 - pega o endereco                   *
    //*  2 - busca a palavra na memoria de     *
    //*        acordo com o endereco fornecido *
    //*  3 - envia a palavra                   *
    //******************************************

  word_type localWord;
  while(true){
    porta->getAddress(&address);
    if(address>mem_size){break;};
    localWord=memoria[address];
    porta->sendWord(localWord);
  }
}

void memory::receiveWord(){

  //******************************************
  //*  Passos para receber uma palavra       *
  //*                                        *
  //*  1 - pega o endereco e a palavra       *
  //*  2 - atualiza o endereco da memoria    *
  //*        com a palavra fornecida         *
  //******************************************

  word_type localWord;
  while(true){
    porta->updateMem(&address, &localWord);
    if(address>mem_size){break;};
    memoria[address] = localWord;
  }
};

void memory::fillMem(){

  char address[17];
  char word[17];
  int iadd;
  int i=0;

  cout << "O nro de linhas eh: " << getNroLinhas() << endl;

  reset();

  while(getNext(address,word)){
    iadd = convert_2dec(address,2);
    memoria[iadd].range(15,0) = word;
    cout << iadd << " - "<< memoria[iadd].to_uint() << endl;
    i++;
  };

}
