// topModel.h: header file

#ifndef __topModel_h
#define __topModel_h

#include <systemc.h>
#include "processorR8.h"
#include "memory.h"
#include "memChl.h"

#ifndef SYNTHESIS
#include <ccss_systemc.h>
#endif

#define CCSS_USE_SC_CTOR

// forward declarations
class processorR8;
struct memory;
class memoryChl;

#ifdef CCSS_USE_SC_CTOR
#undef CCSS_USE_SC_CTOR
#endif

#define CCSS_INIT_CHANNELS 

class topModel
: public sc_module
{

public:
    // module instances
    processorR8 *M1;
    memory *M2;
    memoryChl *M3;

    // initialize parameters
    virtual void InitParameters() {
    }
    // create the schematic
    virtual void InitInstances();

    // delete the schematic
    virtual void DeleteInstances();

	// default constructor
	SC_CTOR(topModel)
	  CCSS_INIT_CHANNELS
	{
		topModel::InitParameters();

		// process declarations

		topModel::InitInstances();
	}

#ifndef SYNTHESIS
	// destructor
	virtual ~topModel()
	{
		topModel::DeleteInstances();
	}
#endif

}; // end module topModel
#undef CCSS_INIT_CHANNELS

#endif
