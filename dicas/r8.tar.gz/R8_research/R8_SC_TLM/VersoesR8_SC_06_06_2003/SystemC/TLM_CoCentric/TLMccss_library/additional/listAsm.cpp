#include "listAsm.h"

void listAsm::carregaSym(){ 
 
  char armazenaLinha[100]; 
  char nomeArquivo[50]; 
 
  cout << "O arquivo solicitado eh o .txt de sa�da do simulador r8" << endl; 
  cout << "Informe o nome do arquivo com a extensao .txt: "; 
  cin >> nomeArquivo; 
 
  ifstream fp(nomeArquivo); 
 
  if (! fp){ cerr << "Arquivo inexistente!!!" << endl; } 
  else{ 
    while(fp.getline(armazenaLinha,100)){ 
      criaLista(armazenaLinha); 
    }; 
 
    fp.close(); 
 
    aux = inicio; 
 
  }; 
 
} 
 
void listAsm::criaLista(char *linha){ 
  char *add, *wrd; 
 
  add = new char[5]; 
  wrd = new char[5]; 
 
  memcpy(add, linha, sizeof(char)*4); 
  memcpy(wrd, &linha[5], sizeof(char)*4); 
 
  add[4] = '\0'; 
  wrd[4] = '\0'; 
 
  if(nroLinha<=convert_2dec(add,16)){ 
 
    nroLinha = convert_2dec(add,16); 
 
    aux = new estAsm(wrd, add); 
 
    if(!inicio){ 
      inicio = aux; 
      fim = aux; 
    } 
    else{ 
      fim->setProx(aux); 
      fim = fim->getProx(); 
    }; 
 
  }; 
 
} 
 
int listAsm::convert_2dec(char *valor, int base){ 
 
  int value = 0; 
  int casa = 0; 
  char chr; 
  int i; 
  int vlr; 
 
  for (i = strlen(valor)-1; i>=0; i--){ 
    chr = valor[i]; 
    vlr = chr2int(chr); 
    value += vlr*((int)(pow(base,casa))); 
    casa++; 
  }; 
 
  return value; 
} 
 
int listAsm::chr2int(char chr){ 
 
 
  if(chr=='0'){ 
    return 0; 
  } 
  else if(chr=='1'){ 
    return 1; 
  } 
  else if(chr=='2'){ 
    return 2; 
  } 
  else if(chr=='3'){ 
    return 3; 
  } 
  else if(chr=='4'){ 
    return 4; 
  } 
  else if(chr=='5'){ 
    return 5; 
  } 
  else if(chr=='6'){ 
    return 6; 
  } 
  else if(chr=='7'){ 
    return 7; 
  } 
  else if(chr=='8'){ 
    return 8; 
  } 
  else if(chr=='9'){ 
    return 9; 
  } 
  else if(chr=='A'){ 
    return 10; 
  } 
  else if(chr=='B'){ 
    return 11; 
  } 
  else if(chr=='C'){ 
    return 12; 
  } 
  else if(chr=='D'){ 
    return 13; 
  } 
  else if(chr=='E'){ 
    return 14; 
  } 
  else if(chr=='F'){ 
    return 15; 
  }; 
  return -1; 
} 
 
void listAsm::reset(){ 
  aux = inicio; 
} 
 
int listAsm::getNext(char * address, char * word){ 
  if(!aux){return 0;} 
  else{ 
 
    strcpy(word, aux->getWord()); 
    strcpy(address, aux->getAddress()); 
    word[16]='\0'; 
 
    aux = aux->getProx(); 
  }; 
  return 1; 
} 
 
int listAsm::getNroLinhas(){ 
	return nroLinha; 
}
