#ifndef __processor_h
#define __processor_h

#include <systemc.h>
#include "additional/common_defs.h"
#include "additional/processor_op.h"
#include "interfaces/R8RegsIf.h"
#include "interfaces/R8MemIf.h"
#include "interfaces/R8FlagsIf.h"


typedef enum {ADD=0,SUB,AND,OR,XOR,
              ADDI,SUBI,LDL,LDH,
              LD,ST,SL0,SL1,
              SR0,SR1,NOT,NOP,
              HALT,LDSP,RTS,POP,
              PUSH,JMPR,JMPNR,JMPZR,
              JMPCR,JMPVR,JMP,JMPN,
              JMPZ,JMPC,JMPV,JSRR,
              JSR,JMPD,JMPND,JMPZD,
              JMPCD,JMPVD,JSRD} instructionSet;
#ifdef CCSS_USE_SC_CTOR
#define CCSS_INIT_MEMBERS_PREFIX : 
#undef CCSS_USE_SC_CTOR
#else
#define CCSS_INIT_MEMBERS_PREFIX , 
#endif

#ifndef SYNTHESIS
#define CCSS_INIT_MEMBERS  CCSS_INIT_MEMBERS_PREFIX \
    portaMem("portaMem") \
    , portaRegs("portaRegs") \
    , portaFlag("portaFlag")
#else
#define CCSS_INIT_MEMBERS 
#endif

struct processor
: public sc_module
{
 public:

  typedef sc_lv<word_size>        dt_type;
  typedef sc_uint<word_size>      uint_type;
  typedef sc_int<word_size>       int_type;
  typedef sc_uint<address_size>   ad_type;
  typedef sc_uint<register_size>  reg_type;
  typedef sc_lv<word_size>        inst_type;
  typedef sc_lv<result_size>      vresults;
  typedef sc_uint<result_size>    uresults;
  typedef sc_int<result_size>     iresults;

  instructionSet currentInstruction;
  reg_type rTarget, rSource1, rSource2;
  dt_type  vTarget, vSource1, vSource2, vCarry;
  int_type iTarget, iSource1, iSource2, iCarry;
  uint_type uTarget, uSource1, uSource2, uCarry;
  int_type iConst16;
  dt_type  vConst16;
  sc_lv<8> vConst8;
  vresults vResult;
  uresults uResult;
  iresults iResult;
    // ports
    sc_port<R8MemIf, 1> portaMem;
    sc_port<R8RegsIf, 1> portaRegs;
    sc_port<R8FlagsIf, 1> portaFlag;

    // initialize parameters
    virtual void InitParameters() {
    }

  SC_HAS_PROCESS(processor);

  processor(sc_module_name name):sc_module(name){
    SC_THREAD(mainAction);
  }

  void mainAction();

  private:
    void decodeInstruction(inst_type);
}; // end module processor
#undef CCSS_INIT_MEMBERS_PREFIX
#undef CCSS_INIT_MEMBERS

#endif
