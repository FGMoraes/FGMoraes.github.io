// newTopModel.h: header file

#ifndef __newTopModel_h
#define __newTopModel_h

#include <systemc.h>
#include "interfaces/R8MemIf.h"
#include "interfaces/memR8If.h"
#include "memory.h"

#ifndef SYNTHESIS
#include <ccss_systemc.h>
#endif

#define CCSS_USE_SC_CTOR

// forward declarations
struct memory;
class memoryChl;
class processorR8;

#ifdef CCSS_USE_SC_CTOR
#undef CCSS_USE_SC_CTOR
#endif

#define CCSS_INIT_CHANNELS

class newTopModel
: public sc_module
{

public:
    // module instances
    memory *M3;
    memoryChl *canalMemoria;
    processorR8 *processadorR8;

    // initialize parameters
    virtual void InitParameters() {
    }
    // create the schematic
    virtual void InitInstances();

    // delete the schematic
    virtual void DeleteInstances();

	// default constructor
	SC_CTOR(newTopModel)
	  CCSS_INIT_CHANNELS
	{
		newTopModel::InitParameters();

		// process declarations

		newTopModel::InitInstances();
	}

#ifndef SYNTHESIS
	// destructor
	virtual ~newTopModel()
	{
		newTopModel::DeleteInstances();
	}
#endif

}; // end module newTopModel
#undef CCSS_INIT_CHANNELS

#endif
