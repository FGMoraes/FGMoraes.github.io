#ifndef __R8Regs_h 
#define __R8Regs_h 

#include <systemc.h>
 
class R8RegsIf : virtual public sc_interface{ 
  public: 
    typedef sc_uint<4> reg_type; 
    typedef sc_lv<16> value_type; 
 
    virtual void writeReg(reg_type, value_type) = 0; 
    virtual void readReg(reg_type, value_type *) = 0; 
    virtual void readReg(reg_type, value_type *, reg_type, value_type *) = 0; 
}; 
 
#endif