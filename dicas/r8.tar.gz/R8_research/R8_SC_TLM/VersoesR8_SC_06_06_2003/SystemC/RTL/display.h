#ifndef __display_h
#define __display_h

class display
: public sc_module
{

public:
    // ports
    sc_in<sc_logic> ck;
    sc_in<sc_logic> rst;
    sc_in<sc_logic> ce;
    sc_in<sc_logic> rw;
    sc_in<reg16> data;
    sc_in<reg16> address;


	// default constructor
	SC_CTOR(display){
		// process declarations
		SC_METHOD(print_result);
		sensitive_neg << ck;
		sensitive << rst;
		sensitive << ce;
		sensitive << data;
		sensitive << address;
	}

	void print_result();

}; // end module display

#endif
