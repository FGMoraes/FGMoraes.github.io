// testbench.cpp: source file
#include "r8.h"
#include "test_bench.h"

void test_bench::converte(){
ck.write(sc_logic(clk.read()));
}

void test_bench::entry(){
	rst.write(SC_LOGIC_1);
	wait(5, SC_NS);
	rst.write(SC_LOGIC_0);
 //++cycle;
}
