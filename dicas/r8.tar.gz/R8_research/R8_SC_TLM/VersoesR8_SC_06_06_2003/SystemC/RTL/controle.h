#ifndef __controle_h
#define __controle_h

struct controle
: public sc_module
{

    // ports

    // Module port declarations
    sc_in<sc_logic> ck;
    sc_in<sc_logic> rst;
    sc_in< sc_lv< 4 > > flags;
    sc_in<reg16> ir;
    sc_out<reg2> mpc;
    sc_out<sc_logic> msp;
    sc_out<reg2> mad;
    sc_out<sc_logic> mreg;
    sc_out<sc_logic> ms2;
    sc_out<sc_logic> ma;
    sc_out<reg2> mb;
    sc_out<sc_logic> wpc;
    sc_out<sc_logic> wsp;
    sc_out<sc_logic> wir;
    sc_out<sc_logic> wab;
    sc_out<sc_logic> wula;
    sc_out<sc_logic> wreg;
    sc_out<sc_logic> wnz;
    sc_out<sc_logic> wcv;
    sc_out<sc_logic> ce;
    sc_out<sc_logic> rw;
    sc_out<instruction> ula;

    // initialize parameters

	typedef enum type_state {Sfetch=0, Srreg=1, Shalt=2, Sula=3, Srts=4, Spop=5, Sldsp=6, Sld=7, Sst=8, Swbk=9, Sjmp=10, Ssbrt=11, Spush=12};

 	//Signal declarations
	sc_signal<type_state> EA;
	sc_signal<type_state> PE;
	sc_signal<sc_logic> fn;
	sc_signal<sc_logic> fz;
	sc_signal<sc_logic> fc;
	sc_signal<sc_logic> fv;
	sc_signal<sc_logic> inst_la1;
	sc_signal<sc_logic> inst_la2;
	sc_signal<instruction> i;

	//Method process declarations
	void set_flags();
	void set_instruction();
	void set_uins_instruction();
	void set_inst_la();
	void set_c_i();
	void set_change_EA();
	void set_WREG();
	void set_c_EA_i();
	void set_inst_la2_i_EA();
	void set_inst_la1_i();
	void process_EA();
	void process_PE();
	//Module constructor
	SC_CTOR(controle){
		//register process
		SC_METHOD(set_flags);
		sensitive << flags;

		SC_METHOD(set_instruction);
		sensitive << ir << fn << fz << fc << fv;

		SC_METHOD(set_uins_instruction);
		sensitive << i;

		SC_METHOD(set_inst_la);
		sensitive << i;

		SC_METHOD(set_c_i);
		sensitive << i;

		SC_METHOD(set_change_EA);
		sensitive << EA;

		SC_METHOD(set_WREG);
		sensitive << EA;

		SC_METHOD(set_c_EA_i);
		sensitive << EA << i;

		SC_METHOD(set_inst_la2_i_EA);
		sensitive << inst_la2 << i << EA;

		SC_METHOD(set_inst_la1_i);
		sensitive << EA << inst_la1 << i;

		SC_METHOD(process_EA);
		sensitive << rst << ck;

		SC_METHOD(process_PE);
		sensitive << EA << i;

	}
}; // end module controle

#endif

