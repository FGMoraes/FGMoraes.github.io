// display.cpp: source file
#include "r8.h"
#include "display.h"

void display::print_result()
{
	// TODO:
		cout << "CLOCK =" <<ck.read()<<"\n"
		<<  "RESET =" << rst.read()<<"\n"
		<<  "CHIP ENABLE ="<< ce.read()<<"\n"
		<<  "READ/WRITE =" << rw.read()<<"\n"
		<<  "DATA ="<< data.read()<<"\n"
		<<  "ADDRESS =" << address.read()<<"\n"
		<<  "Time Simulation:" << sc_time_stamp()<<"\n"
		<<  "Time Simulation:" << sc_simulation_time()<<"\n"
		<<  "###############################################" << endl;
		sc_time_stamp().print(cout);
}

