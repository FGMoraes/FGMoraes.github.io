#ifndef __registrador_h
#define __registrador_h

#include "r8.h"

struct registrador
: public sc_module
{
  public:

    sc_in<sc_logic> rst;
    sc_in<sc_logic> ck;
    sc_in<sc_logic> ce;
    sc_in<sc_lv<WIDTHR8> > D;
    sc_out<sc_lv<WIDTHR8> > Q;

    void asynchRstSynchCE();

    //Module constructor
    SC_CTOR(registrador){
      //register process
      SC_METHOD(asynchRstSynchCE);
      //Declare sensitivity list
      sensitive << rst << ck;
    }
}; // end module registrador

#endif
