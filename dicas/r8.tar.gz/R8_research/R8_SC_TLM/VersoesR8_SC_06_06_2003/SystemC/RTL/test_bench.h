#ifndef __test_bench_h
#define __test_bench_h

struct test_bench
: public sc_module
{

    // ports

    // Module port declarations
    sc_in_clk clk;
    sc_out<sc_logic> ck;
    sc_out<sc_logic> rst;

    // initialize parameters
	unsigned cycle;

	void converte();
	void entry();

	//Module constructor
	SC_CTOR(test_bench){
		SC_METHOD(converte);
		sensitive << clk;
		//register process
		SC_THREAD(entry);
		sensitive << clk.pos();
		cycle=0;
	}
}; // end module test_bench

#endif
