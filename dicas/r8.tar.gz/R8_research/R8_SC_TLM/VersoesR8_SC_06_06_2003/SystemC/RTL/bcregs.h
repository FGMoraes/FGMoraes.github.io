#ifndef __bcregs_h
#define __bcregs_h

#include "r8.h"
#include "registrador.h"

struct bcregs
: public sc_module
{

    // ports

    // Module port declarations
    sc_in<sc_logic> rst;
    sc_in<sc_logic> ck;
    sc_in<sc_logic> wreg;
    sc_in<sc_logic> rs2;
    sc_in<sc_lv<WIDTHR8> > ir;
    sc_in<sc_lv<WIDTHR8> > inREG;
    sc_out<sc_lv<WIDTHR8> > source1;
    sc_out<sc_lv<WIDTHR8> > source2;

    // initialize parameters
	registrador *vregs0, *vregs1, *vregs2, *vregs3, *vregs4, *vregs5, *vregs6, *vregs7, *vregs8, *vregs9, *vregs10, *vregs11, *vregs12, *vregs13, *vregs14, *vregs15;
	sc_signal<sc_lv<WIDTHR8> > reg[WIDTHR8];
	sc_signal<sc_logic> wen[WIDTHR8];

	//Method process declarations
  void chipenable();
	void outsource1();
	void outsource2();
	//Module constructor
	SC_CTOR(bcregs){

  //Instances of Modules
    vregs0= new registrador("registrador0");
    vregs0->rst(rst);
    vregs0->ck(ck);
    vregs0->ce(wen[0]);
    vregs0->D(inREG);
    vregs0->Q(reg[0]);

    vregs1= new registrador("registrador1");
    vregs1->rst(rst);
    vregs1->ck(ck);
    vregs1->ce(wen[1]);
    vregs1->D(inREG);
    vregs1->Q(reg[1]);

    vregs2= new registrador("registrador2");
    vregs2->rst(rst);
    vregs2->ck(ck);
    vregs2->ce(wen[2]);
    vregs2->D(inREG);
    vregs2->Q(reg[2]);

    vregs3= new registrador("registrador3");
    vregs3->rst(rst);
    vregs3->ck(ck);
    vregs3->ce(wen[3]);
    vregs3->D(inREG);
    vregs3->Q(reg[3]);

    vregs4= new registrador("registrador4");
    vregs4->rst(rst);
    vregs4->ck(ck);
    vregs4->ce(wen[4]);
    vregs4->D(inREG);
    vregs4->Q(reg[4]);

    vregs5= new registrador("registrador5");
    vregs5->rst(rst);
    vregs5->ck(ck);
    vregs5->ce(wen[5]);
    vregs5->D(inREG);
    vregs5->Q(reg[5]);

    vregs6= new registrador("registrador6");
    vregs6->rst(rst);
    vregs6->ck(ck);
    vregs6->ce(wen[6]);
    vregs6->D(inREG);
    vregs6->Q(reg[6]);

    vregs7= new registrador("registrador7");
    vregs7->rst(rst);
    vregs7->ck(ck);
    vregs7->ce(wen[7]);
    vregs7->D(inREG);
    vregs7->Q(reg[7]);

    vregs8= new registrador("registrador8");
    vregs8->rst(rst);
    vregs8->ck(ck);
    vregs8->ce(wen[8]);
    vregs8->D(inREG);
    vregs8->Q(reg[8]);

    vregs9= new registrador("registrador9");
    vregs9->rst(rst);
    vregs9->ck(ck);
    vregs9->ce(wen[9]);
    vregs9->D(inREG);
    vregs9->Q(reg[9]);

    vregs10= new registrador("registrador10");
    vregs10->rst(rst);
    vregs10->ck(ck);
    vregs10->ce(wen[10]);
    vregs10->D(inREG);
    vregs10->Q(reg[10]);

    vregs11= new registrador("registrador11");
    vregs11->rst(rst);
    vregs11->ck(ck);
    vregs11->ce(wen[11]);
    vregs11->D(inREG);
    vregs11->Q(reg[11]);

    vregs12= new registrador("registrador12");
    vregs12->rst(rst);
    vregs12->ck(ck);
    vregs12->ce(wen[12]);
    vregs12->D(inREG);
    vregs12->Q(reg[12]);

    vregs13= new registrador("registrador13");
    vregs13->rst(rst);
    vregs13->ck(ck);
    vregs13->ce(wen[13]);
    vregs13->D(inREG);
    vregs13->Q(reg[13]);

    vregs14= new registrador("registrador14");
    vregs14->rst(rst);
    vregs14->ck(ck);
    vregs14->ce(wen[14]);
    vregs14->D(inREG);
    vregs14->Q(reg[14]);

    vregs15= new registrador("registrador15");
    vregs15->rst(rst);
    vregs15->ck(ck);
    vregs15->ce(wen[15]);
    vregs15->D(inREG);
    vregs15->Q(reg[15]);

    //register process
    SC_METHOD(chipenable);
    sensitive << ir << wreg;

    SC_METHOD(outsource1);
//    for(int v=0;v<WIDTHR8;v++)
    sensitive << reg[0] << reg[1] << reg[2] << reg[3];
    sensitive << reg[4] << reg[5] << reg[6] << reg[7];
    sensitive << reg[8] << reg[9] << reg[10] << reg[11];
    sensitive << reg[12] << reg[13] << reg[14] << reg[15];
    sensitive << ir;

    SC_METHOD(outsource2);
    sensitive << reg[0] << reg[1] << reg[2] << reg[3];
    sensitive << reg[4] << reg[5] << reg[6] << reg[7];
    sensitive << reg[8] << reg[9] << reg[10] << reg[11];
    sensitive << reg[12] << reg[13] << reg[14] << reg[15];
    sensitive << ir << rs2;

	}
}; // end module bcregs

#endif