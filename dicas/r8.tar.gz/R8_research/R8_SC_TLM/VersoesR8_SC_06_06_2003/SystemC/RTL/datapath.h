#ifndef __datapath_h
#define __datapath_h

struct datapath
: public sc_module
{

    // ports

    // Module port declarations
    sc_in<sc_logic> ck;

    // Module port declarations
    sc_in<sc_logic> rst;
    sc_in<reg2> mpc;
    sc_in<sc_logic> msp;
    sc_in<reg2> mad;
    sc_in<sc_logic> mreg;
    sc_in<sc_logic> ms2;
    sc_in<sc_logic> ma;
    sc_in<reg2> mb;
    sc_in<sc_logic> wpc;
    sc_in<sc_logic> wsp;
    sc_in<sc_logic> wir;
    sc_in<sc_logic> wab;
    sc_in<sc_logic> wula;
    sc_in<sc_logic> wreg;
    sc_in<sc_logic> wnz;
    sc_in<sc_logic> wcv;
    sc_in<sc_logic> ce;
    sc_in<sc_logic> rw;
    sc_in<instruction> ula;
    sc_out<sc_lv<16> > instructor;
    sc_out<sc_lv<16> > address;
    sc_out< sc_lv< 4 > > flags;
    sc_inout<sc_lv<16> > data;

    // initialize parameters

	sc_signal<reg16> dtreg, dtpc, dtsp, s1, s2, outula, pc, sp, ir, rA, rB, rula, opA, opB, addA, addB, add, dataout;
	sc_signal<sc_logic> cin, coutf, overflow;

	bcregs *MBRS;
	registrador *RPC, *RSP, *RIR, *REG_A, *REG_B, *REG_ULA;

	void setAdderAB();
	void adderAB();
	void setFlags();
 	void muxPC();
	void muxSP();
	void muxROM();
	void muxULAA();
	void muxULAB();
	void muxREGS();
	void muxDATAOUT();
	void muxRAM();
	void setI();
	void pula();

	reg16 fullAdder(reg16, reg16, sc_logic);

	SC_CTOR(datapath){
		MBRS=new bcregs("BancoRegistradores");
		MBRS->rst(rst);
		MBRS->ck(ck);
		MBRS->wreg(wreg);
		MBRS->rs2(ms2);
		MBRS->ir(ir);
		MBRS->inREG(dtreg);
		MBRS->source1(s1);
		MBRS->source2(s2);

		RPC=new registrador("programCounter");
		RPC->rst(rst);
		RPC->ck(ck);
		RPC->ce(wpc);
		RPC->D(dtpc);
		RPC->Q(pc);

		RSP=new registrador("stackPointer");
		RSP->rst(rst);
		RSP->ck(ck);
		RSP->ce(wsp);
		RSP->D(dtsp);
		RSP->Q(sp);

		RIR=new registrador("instructionRegister");
		RIR->rst(rst);
		RIR->ck(ck);
		RIR->ce(wir);
		RIR->D(data);
		RIR->Q(ir);

		REG_A=new registrador("sourceA");
		REG_A->rst(rst);
		REG_A->ck(ck);
		REG_A->ce(wab);
		REG_A->D(s1);
		REG_A->Q(rA);

		REG_B=new registrador("sourceB");
		REG_B->rst(rst);
		REG_B->ck(ck);
		REG_B->ce(wab);
		REG_B->D(s2);
		REG_B->Q(rB);

		REG_ULA=new registrador("rula");
		REG_ULA->rst(rst);
		REG_ULA->ck(ck);
		REG_ULA->ce(wula);
		REG_ULA->D(outula);
		REG_ULA->Q(rula);

		SC_METHOD(muxPC);
		sensitive << pc << rula << data << mpc;

		SC_METHOD(muxSP);
		sensitive << sp << rula << msp;

		SC_METHOD(muxROM);
		sensitive << rula << pc << sp << mad;

		SC_METHOD(muxULAA);
		sensitive << ir << rA << ma;

		SC_METHOD(muxULAB);
		sensitive << sp << pc << rB << mb;

		SC_METHOD(muxREGS);
		sensitive << data << rula << mreg;

		SC_METHOD(muxRAM);
		sensitive << ce << rw << dataout;

		SC_METHOD(muxDATAOUT);
		sensitive << ir << s2 << opB;

		SC_METHOD(setAdderAB);
		sensitive << opA << opB << ula;

		SC_METHOD(adderAB);
		sensitive << addA << addB << cin << add << coutf << overflow;

		SC_METHOD(setFlags);
		sensitive << ck << rst;

		SC_METHOD(setI);
		sensitive << ir;

		SC_METHOD(pula);
		sensitive << opA << opB << ula;
	}
}; // end module datapath

#endif

