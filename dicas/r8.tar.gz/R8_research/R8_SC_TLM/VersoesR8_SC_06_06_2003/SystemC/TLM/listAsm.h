class listAsm{
  private:
    estAsm *inicio, *fim, *aux;
    void criaLista(char *armazenaLinha);
    int nroLinha;
    int chr2int(char chr);

  public:
    listAsm(){ inicio = NULL; fim = NULL; nroLinha=0;};
    int convert_2dec(char *valor, int base);
    void carregaSym();
    void reset();
    int getNext(char *address, char * word);
    int getNroLinhas();
};

