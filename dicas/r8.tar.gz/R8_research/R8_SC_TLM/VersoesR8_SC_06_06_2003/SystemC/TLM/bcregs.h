#ifndef _bcregs_h
#define _bcregs_h

SC_MODULE(bcregs){

  typedef sc_uint<4> reg_type;
  typedef sc_lv<16>  value_type;

  sc_port<regR8If> porta;

  value_type registers[16];  
  reg_type reg1,reg2;
  value_type val1,val2;
  int i;

  SC_HAS_PROCESS(bcregs);

  bcregs (sc_module_name name): sc_module(name){

    for(i=0;i<16;i++){
      registers[i] = "0000000000000000";
    };

    SC_THREAD(updateRegs);
    SC_THREAD(sendRegValue);
    SC_THREAD(sendRegsValue);
  }

  void updateRegs();
  void sendRegValue();
  void sendRegsValue();

};

#endif