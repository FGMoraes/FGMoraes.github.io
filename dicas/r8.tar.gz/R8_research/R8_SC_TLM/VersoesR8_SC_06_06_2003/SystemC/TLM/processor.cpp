#include "systemc.h"
#include "R8RegsIf.h"
#include "R8MemIf.h"
#include "R8FlagsIf.h"
#include "common_defs.h"
#include "processor.h"
#include "processor_op.h"

void processor::mainAction(){
  int i = 1;
  inst_type instruction;
    
  while(true){
    // BUSCA
    #ifdef debugR8

      cout << endl << "*****************************" << endl;
      
    #endif
    portaMem->getNxtWord(&instruction);
    
    // LEITURA DE REGISTRADORES
    decodeInstruction(instruction);
    
    // OPERACAO COM A ULA
    switch(currentInstruction){
      case ADD:
        R8_ADD(rTarget,rSource1,rSource2);
        break;
      case SUB:
        R8_SUB(rTarget,rSource1,rSource2);
/*
        portaRegs->readReg(rSource1,&vSource1,rSource2,&vSource2); 
        uResult=vSource1.to_uint()-uSource2.to_uint();
        vResult=uResult; 
        portaFlag->lnz_lcv(vResult, vSource1, vSource2);
        vTarget=vResult.range(15,0); 
        portaRegs->writeReg(rTarget,vTarget);
*/        
          break;
      case AND:
        R8_AND(rTarget,rSource1,rSource2);
        break;
      case OR:
        R8_OR(rTarget,rSource1,rSource2);
        break;
      case XOR:
        R8_XOR(rTarget,rSource1,rSource2);
        break;
      case ADDI:
        R8_ADDI(rTarget,vConst8);
        break;
      case SUBI:
        R8_SUBI(rTarget,vConst8);
        break;
      case LDL:
        R8_LDL(rTarget,vConst8);
        break;
      case LDH:
        R8_LDH(rTarget,vConst8);
        break;
      case LD:
        R8_LD(rTarget, rSource1, rSource2);
        break;
      case ST:
        R8_ST(rTarget, rSource1, rSource2);
        break;
      case SL0:
        R8_SL0(rTarget, rSource1);
        break;
      case SL1:
        R8_SL1(rTarget, rSource1);
        break;
      case SR0:
        R8_SR0(rTarget, rSource1);
        break;
      case SR1:
        R8_SR1(rTarget, rSource1);
        break;
      case NOT:
        R8_NOT(rTarget, rSource1);
        break;
      case NOP:
        R8_NOP();
        break;
      case HALT:
        R8_HALT();
        break;
      case LDSP:
        R8_LDSP(rSource1);
        break;
      case RTS:
        R8_RTS();
        break;
      case POP:
        R8_POP(rTarget);
        break;
      case PUSH:
        R8_PUSH(rTarget);
        break;
      case JMPR:
        R8_JMPR(rSource1);
        break;
      case JMPNR:
        R8_JMPNR(rSource1);
        break;
      case JMPZR:
        R8_JMPZR(rSource1);
        break;
      case JMPCR:
        R8_JMPCR(rSource1);
        break;
      case JMPVR:
        R8_JMPVR(rSource1);
        break;
      case JMP:
        R8_JMP(rSource1);
        break;
      case JMPN:
        R8_JMPN(rSource1);
        break;
      case JMPZ:
        R8_JMPZ(rSource1);
        break;
      case JMPC:
        R8_JMPC(rSource1);
        break;
      case JMPV:
        R8_JMPV(rSource1);
        break;
      case JSRR:
        R8_JSRR(rSource1);
        break;
      case JSR:
        R8_JSR(rSource1);
        break;
      case JMPD:
        R8_JMPD(vConst16);
        break;
      case JMPND:
        R8_JMPND(vConst16);
        break;
      case JMPZD:
        R8_JMPZD(vConst16);
        break;
      case JMPCD:
        R8_JMPCD(vConst16);
        break;
      case JMPVD:
        R8_JMPVD(vConst16);
        break;
      case JSRD:
        R8_JSRD(vConst16);
        break;
    }

    // EXECUCAO
    if(currentInstruction==HALT){break;}

    #ifdef debugR8
      cout << "*************************" << endl;
    #endif
  }


};

void processor::decodeInstruction(inst_type inst){

  sc_uint<4> operation;
  sc_lv<16> temp16;
  sc_lv<12> temp12;
  sc_lv<10> temp10;
  sc_lv<8>  temp8;
  sc_lv<4>  temp4;

  operation = inst.range(15,12).to_uint();

  switch(operation){
    case 0: 
      currentInstruction=ADD;
      rTarget  = inst.range(11,8).to_uint();
      rSource1 = inst.range( 7,4).to_uint();
      rSource2 = inst.range( 3,0).to_uint();
      #ifdef debugR8
        cout << "current Instruction : ADD" << endl;
        cout << "registrador alvo R" << rTarget.to_uint() << endl;
        cout << "registrador src1 R" << rSource1.to_uint() << endl;
        cout << "registrador src2 R" << rSource2.to_uint() << endl;
      #endif
      break;
    case 1: 
      currentInstruction=SUB;
      rTarget  = inst.range(11,8).to_uint();
      rSource1 = inst.range( 7,4).to_uint();
      rSource2 = inst.range( 3,0).to_uint();
      #ifdef debugR8
        cout << "current Instruction : SUB" << endl;
        cout << "registrador alvo R" << rTarget.to_uint() << endl;
        cout << "registrador src1 R" << rSource1.to_uint() << endl;
        cout << "registrador src2 R" << rSource2.to_uint() << endl;
      #endif
      break;
    case 2: 
      currentInstruction=AND;
      rTarget  = inst.range(11,8).to_uint();
      rSource1 = inst.range( 7,4).to_uint();      
      rSource2 = inst.range( 3,0).to_uint();
      #ifdef debugR8
        cout << "current Instruction : AND" << endl;
        cout << "registrador alvo R" << rTarget.to_uint() << endl;
        cout << "registrador src1 R" << rSource1.to_uint() << endl;
        cout << "registrador src2 R" << rSource2.to_uint() << endl;
      #endif
      break;
    case 3: 
      currentInstruction=OR;
      rTarget  = inst.range(11,8).to_uint();
      rSource1 = inst.range( 7,4).to_uint();
      rSource2 = inst.range( 3,0).to_uint();
      #ifdef debugR8
        cout << "current Instruction : OR" << endl;
        cout << "registrador alvo R" << rTarget.to_uint() << endl;
        cout << "registrador src1 R" << rSource1.to_uint() << endl;
        cout << "registrador src2 R" << rSource2.to_uint() << endl;
      #endif
      break;
    case 4: 
      currentInstruction=XOR;
      rTarget  = inst.range(11,8).to_uint();
      rSource1 = inst.range( 7,4).to_uint();
      rSource2 = inst.range( 3,0).to_uint();
      #ifdef debugR8
        cout << "current Instruction : XOR" << endl;
        cout << "registrador alvo R" << rTarget.to_uint() << endl;
        cout << "registrador src1 R" << rSource1.to_uint() << endl;
        cout << "registrador src2 R" << rSource2.to_uint() << endl;
      #endif
      break;
    case 5: 
      currentInstruction=ADDI;
      rTarget  = inst.range(11,8).to_uint();
      vConst8  = inst.range(7,0);
      #ifdef debugR8
        cout << "current Instruction : ADDI" << endl;
        cout << "registrador alvo R" << rTarget.to_uint() << endl;
        cout << "constante : " << vConst8.to_uint() << endl;
      #endif
      break;
    case 6: 
      currentInstruction=SUBI;
      rTarget  = inst.range(11,8).to_uint();
      vConst8  = inst.range(7,0);
      #ifdef debugR8
        cout << "current Instruction : SUBI" << endl;
        cout << "registrador alvo R" << rTarget.to_uint() << endl;
        cout << "constante : " << vConst8.to_uint() << endl;
      #endif
      break;
    case 7: 
      currentInstruction=LDL;
      rTarget  = inst.range(11,8).to_uint();
      vConst8  = inst.range(7,0);
      #ifdef debugR8
        cout << "current Instruction : LDL" << endl;
        cout << "registrador alvo R" << rTarget.to_uint() << endl;
        cout << "constante : " << vConst8.to_uint() << endl;
      #endif
      break;
    case 8: 
      currentInstruction=LDH;
      rTarget  = inst.range(11,8).to_uint();
      vConst8  = inst.range(7,0);
      #ifdef debugR8
        cout << "current Instruction : LDH" << endl;
        cout << "registrador alvo R" << rTarget.to_uint() << endl;
        cout << "constante : " << vConst8.to_uint() << endl;
      #endif
      break;
    case 9: 
      currentInstruction=LD;
      rTarget  = inst.range(11,8).to_uint();
      rSource1 = inst.range( 7,4).to_uint();
      rSource2 = inst.range( 3,0).to_uint();      
      #ifdef debugR8
        cout << "current Instruction : LD" << endl;
        cout << "registrador alvo R" << rTarget.to_uint() << endl;
        cout << "registrador src1 R" << rSource1.to_uint() << endl;
        cout << "registrador src2 R" << rSource2.to_uint() << endl;
      #endif
      break;
    case 10: 
      currentInstruction=ST;
      rTarget  = inst.range(11,8).to_uint();
      rSource1 = inst.range( 7,4).to_uint();
      rSource2 = inst.range( 3,0).to_uint();
      #ifdef debugR8
        cout << "current Instruction : ST" << endl;
        cout << "registrador alvo R" << rTarget.to_uint() << endl;
        cout << "registrador src1 R" << rSource1.to_uint() << endl;
        cout << "registrador src2 R" << rSource2.to_uint() << endl;
      #endif
      break;
    case 11: 
      operation = inst.range(3,0).to_uint();      
      switch(operation){
        case 0:
          currentInstruction=SL0;
          rTarget  = inst.range(11,8).to_uint();          
          rSource1 = inst.range( 7,4).to_uint();
          #ifdef debugR8
            cout << "current Instruction : SL0" << endl;
            cout << "registrador alvo R" << rTarget.to_uint() << endl;
            cout << "registrador src1 R" << rSource1.to_uint() << endl;
          #endif
          break;
        case 1:
          currentInstruction=SL1;          
          rTarget = inst.range(11,8).to_uint();
          rSource1 = inst.range(7,4).to_uint();
          #ifdef debugR8
            cout << "current Instruction : SL1" << endl;
            cout << "registrador alvo R" << rTarget.to_uint() << endl;
            cout << "registrador src1 R" << rSource1.to_uint() << endl;
          #endif
          break;
        case 2:
          currentInstruction=SR0;          
          rTarget = inst.range(11,8).to_uint();
          rSource1 = inst.range(7,4).to_uint();
          #ifdef debugR8
            cout << "current Instruction : SR0" << endl;
            cout << "registrador alvo R" << rTarget.to_uint() << endl;
            cout << "registrador src1 R" << rSource1.to_uint() << endl;
          #endif
          break;
        case 3:
          currentInstruction=SR1;
          rTarget = inst.range(11,8).to_uint();
          rSource1 = inst.range(7,4).to_uint();
          #ifdef debugR8
            cout << "current Instruction : SR1" << endl;
            cout << "registrador alvo R" << rTarget.to_uint() << endl;
            cout << "registrador src1 R" << rSource1.to_uint() << endl;
          #endif
          break;
        case 4:
          currentInstruction=NOT;
          rTarget = inst.range(11,8).to_uint();
          rSource1 = inst.range(7,4).to_uint();
          #ifdef debugR8
            cout << "current Instruction : NOT" << endl;
            cout << "registrador alvo R" << rTarget.to_uint() << endl;
            cout << "registrador src1 R" << rSource1.to_uint() << endl;
          #endif
          break;
        case 5:
          currentInstruction=NOP;
          #ifdef debugR8
            cout << "current Instruction : NOP" << endl;
          #endif
          break;
        case 6:
          currentInstruction=HALT;
          #ifdef debugR8
            cout << "current Instruction : HALT" << endl;
          #endif
          break;
        case 7:
          currentInstruction=LDSP;
          rSource1 = inst.range(7,4).to_uint();
          #ifdef debugR8
            cout << "current Instruction : LDSP" << endl;
            cout << "registrador src1 R" << rSource1.to_uint() << endl;
          #endif
          break;
        case 8:
          currentInstruction=RTS;
          #ifdef debugR8
            cout << "current Instruction : RTS" << endl;
          #endif
          break;
        case 9:
          currentInstruction=POP;          
          rTarget = inst.range(11,8).to_uint();
          #ifdef debugR8
            cout << "current Instruction : POP" << endl;
            cout << "registrador alvo R" << rTarget.to_uint() << endl;
          #endif
          break;
        case 10:
          currentInstruction=PUSH;
          rTarget = inst.range(11,8).to_uint();
          #ifdef debugR8
            cout << "current Instruction : XOR" << endl;
            cout << "registrador alvo R" << rTarget.to_uint() << endl;
          #endif
          break;
      }
      break;
    case 12: 
      operation = inst.range(3,0).to_uint();
      rSource1  = inst.range(7,4).to_uint();
      switch(operation){
        case 0:
          currentInstruction=JMPR;
          #ifdef debugR8
            cout << "current Instruction : JMPR" << endl;
            cout << "registrador src1 R" << rSource1.to_uint() << endl;
          #endif
          break;
        case 1:
          currentInstruction=JMPNR;
          #ifdef debugR8
            cout << "current Instruction : JMPNR" << endl;
            cout << "registrador src1 R" << rSource1.to_uint() << endl;
          #endif
          break;
        case 2:
          currentInstruction=JMPZR;
          #ifdef debugR8
            cout << "current Instruction : JMPZR" << endl;
            cout << "registrador src1 R" << rSource1.to_uint() << endl;
          #endif
          break;
        case 3:
          currentInstruction=JMPCR;
          #ifdef debugR8
            cout << "current Instruction : JMPCR" << endl;
            cout << "registrador src1 R" << rSource1.to_uint() << endl;
          #endif
          break;
        case 4:
          currentInstruction=JMPVR;
          #ifdef debugR8
            cout << "current Instruction : JMPVR" << endl;
            cout << "registrador src1 R" << rSource1.to_uint() << endl;
          #endif
          break;
        case 5:
          currentInstruction=JMP;
          #ifdef debugR8
            cout << "current Instruction : JMP" << endl;
            cout << "registrador src1 R" << rSource1.to_uint() << endl;
          #endif
          break;
        case 6:
          currentInstruction=JMPN;
          #ifdef debugR8
            cout << "current Instruction : JMPN" << endl;
            cout << "registrador src1 R" << rSource1.to_uint() << endl;
          #endif
          break;
        case 7:
          currentInstruction=JMPZ;
          #ifdef debugR8
            cout << "current Instruction : JMPZ" << endl;
            cout << "registrador src1 R" << rSource1.to_uint() << endl;
          #endif
          break;
        case 8:
          currentInstruction=JMPC;
          #ifdef debugR8
            cout << "current Instruction : JMPC" << endl;
            cout << "registrador src1 R" << rSource1.to_uint() << endl;
          #endif
          break;
        case 9:
          currentInstruction=JMPV;
          #ifdef debugR8
            cout << "current Instruction : JMPV" << endl;
            cout << "registrador src1 R" << rSource1.to_uint() << endl;
          #endif
          break;
        case 10:
          currentInstruction=JSRR;
          #ifdef debugR8
            cout << "current Instruction : JSRR" << endl;
            cout << "registrador src1 R" << rSource1.to_uint() << endl;
          #endif
          break;
        case 11:
          currentInstruction=JSR;
          #ifdef debugR8
            cout << "current Instruction : JSR" << endl;
            cout << "registrador src1 R" << rSource1.to_uint() << endl;
          #endif
          break;
      }
      break;
    case 13: 
      currentInstruction=JMPD;
      if(inst[7] == '1'){
        vConst16 = ("11111111",inst.range(7,0));
      }
      else{
        vConst16 = ("00000000",inst.range(7,0));
      }
      #ifdef debugR8
        cout << "current Instruction : JMPD" << endl;
        cout << "constante : " << vConst16.to_uint() << endl;
      #endif
      break;
    case 14: 
      operation = ("00",inst.range(11,10)).to_uint();
      if(inst[7] == '1'){
        vConst16 = ("11111111",inst.range(7,0));
      }
      else{
        vConst16 = ("00000000",inst.range(7,0));
      }
      switch(operation){
        case 0:
          currentInstruction=JMPND;
          #ifdef debugR8
            cout << "current Instruction : JMPD" << endl;
            cout << "constante : " << vConst16.to_uint() << endl;
          #endif
          break;
        case 1:
          currentInstruction=JMPZD;
          #ifdef debugR8
            cout << "current Instruction : JMPZD" << endl;
            cout << "constante : " << vConst16.to_uint() << endl;
          #endif
          break;
        case 2:
          currentInstruction=JMPCD;
          #ifdef debugR8
            cout << "current Instruction : JMPCD" << endl;
            cout << "constante : " << vConst16.to_uint() << endl;
          #endif
          break;
        case 3:
          currentInstruction=JMPVD;
          #ifdef debugR8
            cout << "current Instruction : JMPVD" << endl;
            cout << "constante : " << vConst16.to_uint() << endl;
          #endif
          break;
      }
      break;
    case 15:
      currentInstruction=JSRD;
      if(inst[7] == '1'){
        vConst16 = ("1111",inst.range(11,0));
      }
      else{
        vConst16 = ("0000",inst.range(11,0));
      }
      #ifdef debugR8
        cout << "current Instruction : JSRD" << endl;
        cout << "constante : " << vConst16.to_uint() << endl;
      #endif
      break;
  }

}
