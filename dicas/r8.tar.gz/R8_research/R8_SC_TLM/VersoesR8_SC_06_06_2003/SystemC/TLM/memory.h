#include "estAsm.h"
#include "listAsm.h"
#include "common_defs.h"

#ifndef __memory_h
#define __memory_h

struct memory: public sc_module, public listAsm{

  typedef sc_uint<16> ad_type;
  typedef sc_lv<16> word_type;

  sc_port<memR8If> porta;
  word_type *memoria;
  ad_type address;

  SC_HAS_PROCESS(memory);

  memory(sc_module_name name) : sc_module(name), listAsm(){

    carregaSym();

    memoria = new word_type [$mem_size];

    fillMem();

    SC_THREAD(sendWord);
    SC_THREAD(receiveWord);
  }

  ~memory(){
		int i;

        for(i=0; i<=getNroLinhas(); i++){
			cout << "memoria[" << i << "] : " << memoria[i].to_uint() << endl;
		};

	}

  void sendWord();
  void receiveWord();
  void fillMem();

};

#endif