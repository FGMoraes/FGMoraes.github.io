#include "systemc.h"
#include "regR8If.h"
#include "bcregs.h"

void bcregs::updateRegs(){
  while(true){
    porta->updateReg(&reg1,&val1);
    registers[reg1]=val1;
  }
}

void bcregs::sendRegValue(){
  while(true){
    porta->regNum(&reg1);
    val1=registers[reg1];
    porta->sendRegValue(val1);
  }
};

void bcregs::sendRegsValue(){
  while(true){
    porta->regNum(&reg1,&reg2);
    val1=registers[reg1];
    val2=registers[reg2];
    porta->sendRegValue(val1,val2);
  }
};



