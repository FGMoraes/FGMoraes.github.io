// debug
#ifndef debugR8
//  #define debugR8
#endif

// flags
#ifndef $zero
  #define $zero     0
#endif
#ifndef $negative
  #define $negative 1
#endif
#ifndef $carry
  #define $carry    2
#endif
#ifndef $overflow
  #define $overflow 3
#endif
#ifndef $flags_representation
  #define $flags_representation 2
#endif

// flags nz e cv
#ifndef $lnz
  #define $lnz      0
#endif
#ifndef $lnz
  #define $lcv      1
#endif
#ifndef $lnz_$lcv
  #define $lnz_$lcv 2
#endif

// memory
#ifndef $mem_size
  #define $mem_size 65535
#endif
#ifndef $word_size
  #define $word_size 16
#endif
#ifndef $address_size
  #define $address_size 16
#endif

// bcregs
#ifndef $register_size
  #define $register_size 16
#endif

// processor
#ifndef $result_size
  #define $result_size 17
#endif
