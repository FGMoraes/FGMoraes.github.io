#include "common_defs.h"

#ifndef _R8Flags_h
#define _R8Flags_h

class R8FlagsIf : virtual public sc_interface{
  public:
    typedef sc_uint<$flags_representation> flag_type;
    typedef sc_logic flag_value;
    typedef sc_lv<$word_size> source_type;
    typedef sc_lv<$result_size> result_type;

    virtual void lnz(result_type) = 0;
    virtual void lcv(result_type, source_type, source_type) = 0;
    virtual void lnz_lcv(result_type, source_type, source_type) = 0;
    virtual flag_value getFlag(flag_type) = 0;
};

#endif