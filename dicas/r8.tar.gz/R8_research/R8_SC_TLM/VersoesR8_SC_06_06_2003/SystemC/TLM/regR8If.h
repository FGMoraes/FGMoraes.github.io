#ifndef _regR8_h
#define _regR8_h

class regR8If : virtual public sc_interface{
  public:
    typedef sc_uint<4> reg_type;
    typedef sc_lv<16> value_type;

    virtual void updateReg(reg_type *, value_type *) = 0;
    virtual void regNum(reg_type *) = 0;
    virtual void regNum(reg_type *, reg_type *) = 0;
    virtual void sendRegValue(value_type) = 0;
    virtual void sendRegValue(value_type, value_type) = 0;
};

#endif