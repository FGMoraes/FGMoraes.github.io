#include "common_defs.h"

#ifndef _memR8If
#define _memR8If

class memR8If : virtual public sc_interface{
  public:
    typedef sc_lv<$word_size> word_type;
    typedef sc_uint<$address_size> ad_type;

    
    // instructions
    virtual void getAddress(ad_type *) = 0;
    virtual void updateMem(ad_type *, word_type *) = 0;
    virtual void sendWord(word_type) = 0;

};

#endif
