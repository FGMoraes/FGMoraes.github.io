#ifndef __processor_h
#define __processor_h

typedef enum {ADD,SUB,AND,OR,XOR,
              ADDI,SUBI,LDL,LDH,
              LD,ST,SL0,SL1,
              SR0,SR1,NOT,NOP,
              HALT,LDSP,RTS,POP,
              PUSH,JMPR,JMPNR,JMPZR,
              JMPCR,JMPVR,JMP,JMPN,
              JMPZ,JMPC,JMPV,JSRR,
              JSR,JMPD,JMPND,JMPZD,
              JMPCD,JMPVD,JSRD} instructionSet;

SC_MODULE(processor){

  typedef sc_lv<$word_size>        dt_type;
  typedef sc_uint<$word_size>      uint_type;
  typedef sc_int<$word_size>       int_type;
  typedef sc_uint<$address_size>   ad_type;
  typedef sc_uint<$register_size>  reg_type;
  typedef sc_lv<$word_size>        inst_type;
  typedef sc_lv<$result_size>      vresults;
  typedef sc_uint<$result_size>    uresults;
  typedef sc_int<$result_size>     iresults;

  instructionSet currentInstruction;
  reg_type rTarget, rSource1, rSource2;
  dt_type  vTarget, vSource1, vSource2, vCarry;
  int_type iTarget, iSource1, iSource2, iCarry;
  uint_type uTarget, uSource1, uSource2, uCarry;
  int_type iConst16;
  dt_type  vConst16;
  sc_lv<8> vConst8;  
  vresults vResult;
  uresults uResult;
  iresults iResult;

  sc_port< R8MemIf  >  portaMem;
  sc_port< R8RegsIf >  portaRegs;
  sc_port< R8FlagsIf > portaFlag;

  SC_HAS_PROCESS(processor);

  processor(sc_module_name name, sc_port< R8MemIf > * _portaMem):sc_module(name){
    SC_THREAD(mainAction);
  }

  void mainAction();

  private:
    void decodeInstruction(inst_type);    
};

#endif
