#include "systemc.h"
// canais
#include "common_defs.h"
#include "memChl.h"
#include "bcregsChl.h"
#include "flagNZCVChl.h"
// componentes
#include "processor.h"
#include "bcregs.h"
#include "memory.h"

SC_MODULE(top){

  sc_port < R8MemIf > portaMem;
  bcregsChl   canalRegs;
  flagNZCVChl canalFlags;

  bcregs      bancoRegs;
  processor   processador;

  top(sc_module_name name): sc_module(name),
                            canalRegs("cnlRegs"),
                            canalFlags("cnlFlags"),
                            bancoRegs("bancoDeRegistradores"),
                            processador("processador", & portaMem){


    bancoRegs.porta(canalRegs);
    processador.portaRegs(canalRegs);
    processador.portaFlag(canalFlags);
    processador.portaMem(portaMem);

  };


};

int sc_main(int argc, char *argv[]){

  memoryChl   canalMemoria("cnlMemoria");

  memory memoria("memoria");
  memoria.porta(canalMemoria);

  top topo("topo");
  topo.portaMem(canalMemoria);

  sc_trace_file *tf;
  tf=sc_create_vcd_trace_file("myTrace");

  sc_trace(tf,topo.processador.currentInstruction,"instrucao");
  sc_trace(tf,memoria.address,"endereco");
  sc_trace(tf,topo.bancoRegs.registers[0] ,"R0");
  sc_trace(tf,topo.bancoRegs.registers[1] ,"R1");
  sc_trace(tf,topo.bancoRegs.registers[2] ,"R2");
  sc_trace(tf,topo.bancoRegs.registers[3] ,"R3");
  sc_trace(tf,topo.bancoRegs.registers[4] ,"R4");
  sc_trace(tf,topo.bancoRegs.registers[5] ,"R5");
  sc_trace(tf,topo.bancoRegs.registers[6] ,"R6");
  sc_trace(tf,topo.bancoRegs.registers[7] ,"R7");
  sc_trace(tf,topo.bancoRegs.registers[8] ,"R8");
  sc_trace(tf,topo.bancoRegs.registers[9] ,"R9");
  sc_trace(tf,topo.bancoRegs.registers[10] ,"R10");
  sc_trace(tf,topo.bancoRegs.registers[11] ,"R11");
  sc_trace(tf,topo.bancoRegs.registers[12] ,"R12");
  sc_trace(tf,topo.bancoRegs.registers[13] ,"R13");
  sc_trace(tf,topo.bancoRegs.registers[14] ,"R14");
  sc_trace(tf,topo.bancoRegs.registers[15] ,"R15");

  sc_start(-1);

  sc_close_vcd_trace_file(tf);

  return 0;

}
