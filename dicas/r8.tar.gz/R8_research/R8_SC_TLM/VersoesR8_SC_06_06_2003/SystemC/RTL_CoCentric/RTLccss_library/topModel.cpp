// topModel.cpp: source file

#include "modelR8.h"
#include "test_bench.h"
#include "display.h"
#include "mem.h"
#include "topModel.h"

void topModel::InitInstances() {
    M1 = new modelR8("M1");
    M2 = new test_bench("M2");
    M3 = new sc_clock("M3");
    M4 = new display("M4");
    M5 = new mem("M5");

    M2->clk(*M3);
    M1->address(address_sgn);
    M5->address(address_sgn);
    M4->address(address_sgn);
    M1->ce(ce_sgn);
    M5->ce(ce_sgn);
    M4->ce(ce_sgn);
    M1->ck(ck_sgn);
    M2->ck(ck_sgn);
    M5->ck(ck_sgn);
    M4->ck(ck_sgn);
    M1->data(data_sgn);
    M5->data(data_sgn);
    M4->data(data_sgn);
    M1->rst(rst_sgn);
    M2->rst(rst_sgn);
    M5->rst(rst_sgn);
    M4->rst(rst_sgn);
    M1->rw(rw_sgn);
    M5->rw(rw_sgn);
    M4->rw(rw_sgn);
}

void topModel::DeleteInstances() {
    if (M1) {delete M1; M1 = 0;}
    if (M2) {delete M2; M2 = 0;}
    if (M3) {delete M3; M3 = 0;}
    if (M4) {delete M4; M4 = 0;}
    if (M5) {delete M5; M5 = 0;}
}

