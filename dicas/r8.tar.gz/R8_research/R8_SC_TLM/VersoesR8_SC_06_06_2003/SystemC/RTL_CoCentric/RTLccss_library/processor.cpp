// processor.cpp: source file
#include "r8.h"
#include "registrador.h"
#include "bcregs.h"
#include "datapath.h"
#include "controle.h"
#include "processor.h"

void processor::setrw(){
  ce.write(sce.read());
  rw.write(srw.read());
}
