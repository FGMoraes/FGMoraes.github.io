// topModel.h: header file

#ifndef __topModel_h
#define __topModel_h

#include <systemc.h>
#include "r8.h"

#ifndef SYNTHESIS
#include <ccss_systemc.h>
#endif

#define CCSS_USE_SC_CTOR

// forward declarations
class modelR8;
struct test_bench;
class display;
struct mem;

#ifdef CCSS_USE_SC_CTOR
#define CCSS_INIT_CHANNELS_PREFIX : 
#undef CCSS_USE_SC_CTOR
#else
#define CCSS_INIT_CHANNELS_PREFIX , 
#endif

#ifndef SYNTHESIS
#define CCSS_INIT_CHANNELS  CCSS_INIT_CHANNELS_PREFIX \
    address_sgn("address_sgn") \
    , ce_sgn("ce_sgn") \
    , ck_sgn("ck_sgn") \
    , data_sgn("data_sgn") \
    , rst_sgn("rst_sgn") \
    , rw_sgn("rw_sgn")
#else
#define CCSS_INIT_CHANNELS 
#endif

class topModel
: public sc_module
{

public:
    // channels
    sc_signal< reg16 > address_sgn;
    sc_signal< sc_logic > ce_sgn;
    sc_signal< sc_logic > ck_sgn;
    sc_signal< reg16 > data_sgn;
    sc_signal< sc_logic > rst_sgn;
    sc_signal< sc_logic > rw_sgn;

    // module instances
    modelR8 *M1;
    test_bench *M2;
    sc_clock *M3;
    display *M4;
    mem *M5;

    // initialize parameters
    virtual void InitParameters() {
    }
    // create the schematic
    virtual void InitInstances();

    // delete the schematic
    virtual void DeleteInstances();

	// default constructor
	SC_CTOR(topModel)
	  CCSS_INIT_CHANNELS
	{
		topModel::InitParameters();

		// process declarations

		topModel::InitInstances();
	}

#ifndef SYNTHESIS
	// destructor
	virtual ~topModel()
	{
		topModel::DeleteInstances();
	}
#endif

}; // end module topModel
#undef CCSS_INIT_CHANNELS_PREFIX
#undef CCSS_INIT_CHANNELS

#endif
