// modelR8.h: header file

#ifndef __modelR8_h
#define __modelR8_h

#include <systemc.h>
#include "r8.h"

#ifndef SYNTHESIS
#include <ccss_systemc.h>
#endif

#define CCSS_USE_SC_CTOR

// forward declarations
struct controle;
struct datapath;

#ifdef CCSS_USE_SC_CTOR
#define CCSS_INIT_CHANNELS_PREFIX : 
#undef CCSS_USE_SC_CTOR
#else
#define CCSS_INIT_CHANNELS_PREFIX , 
#endif

#ifndef SYNTHESIS
#define CCSS_INIT_CHANNELS  CCSS_INIT_CHANNELS_PREFIX \
    ck("ck") \
    , rst("rst") \
    , data("data") \
    , address("address") \
    , ce("ce") \
    , rw("rw") \
    , flag_sgn("flag_sgn") \
    , ir_sgn("ir_sgn") \
    , ma_sgn("ma_sgn") \
    , mad_sgn("mad_sgn") \
    , mb_sgn("mb_sgn") \
    , mpc_sgn("mpc_sgn") \
    , mreg_sgn("mreg_sgn") \
    , ms2_sgn("ms2_sgn") \
    , msp_sgn("msp_sgn") \
    , ula_sgn("ula_sgn") \
    , wab_sgn("wab_sgn") \
    , wcu_sgn("wcu_sgn") \
    , wir_sgn("wir_sgn") \
    , wnz_sgn("wnz_sgn") \
    , wpc_sgn("wpc_sgn") \
    , wreg_sgn("wreg_sgn") \
    , wsp_sgn("wsp_sgn") \
    , wula_sgn("wula_sgn")
#else
#define CCSS_INIT_CHANNELS 
#endif

class modelR8
: public sc_module
{

public:
    // ports

    // sinal de clock
    sc_in< sc_logic > ck;

    // sinal de reset
    sc_in< sc_logic > rst;

    // barramento de dados
    sc_inout< reg16 > data;

    // barramento de endereco
    sc_out< reg16 > address;

    // sinal de habilitacao da memoria
    sc_out< sc_logic > ce;

    // sinal de escrita/leitura
    sc_out< sc_logic > rw;

    // channels
    sc_signal<sc_lv<4> > flag_sgn;
    sc_signal< reg16 > ir_sgn;
    sc_signal<sc_logic> ma_sgn;
    sc_signal<reg2> mad_sgn;
    sc_signal<reg2> mb_sgn;
    sc_signal<reg2> mpc_sgn;
    sc_signal<sc_logic> mreg_sgn;
    sc_signal<sc_logic> ms2_sgn;
    sc_signal<sc_logic> msp_sgn;
    sc_signal<instruction> ula_sgn;
    sc_signal<sc_logic> wab_sgn;
    sc_signal<sc_logic> wcu_sgn;
    sc_signal<sc_logic> wir_sgn;
    sc_signal<sc_logic> wnz_sgn;
    sc_signal<sc_logic> wpc_sgn;
    sc_signal<sc_logic> wreg_sgn;
    sc_signal<sc_logic> wsp_sgn;
    sc_signal<sc_logic> wula_sgn;

    // module instances
    controle *ControllBlock;
    datapath *dataBlock;

    // initialize parameters
    virtual void InitParameters() {
    }
    // create the schematic
    virtual void InitInstances();

    // delete the schematic
    virtual void DeleteInstances();

	// default constructor
	SC_CTOR(modelR8)
	  CCSS_INIT_CHANNELS
	{
		modelR8::InitParameters();

		// process declarations

		modelR8::InitInstances();
	}

#ifndef SYNTHESIS
	// destructor
	virtual ~modelR8()
	{
		modelR8::DeleteInstances();
	}
#endif

}; // end module modelR8
#undef CCSS_INIT_CHANNELS_PREFIX
#undef CCSS_INIT_CHANNELS

#endif
