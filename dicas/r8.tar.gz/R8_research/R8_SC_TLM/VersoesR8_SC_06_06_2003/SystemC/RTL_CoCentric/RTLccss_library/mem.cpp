// mem.cpp: source file
#include "mem.h"
#include "iostream.h"
#include "stdio.h"
#include "fstream.h"

/*Read RAM Process, this proces is a combinational logic that read the data
recorded inside of the RAM
*/
void mem::readRAM(){
	static reg16 old_data=pMEM[0];
 	reg16 adt;
	sc_uint<WIDTHR8> ad;
	adt=address.read();
	if((adt!=reg16(SC_LOGIC_Z))&&(adt!=reg16(SC_LOGIC_X))){
		ad=adt.to_uint();
		if((ad>=0)&&(ad<MEM_SIZE)&&(ce.read()==SC_LOGIC_1)&&(rw.read()==SC_LOGIC_1))
			old_data=pMEM[ad];
		else
			old_data=reg16(SC_LOGIC_Z);
	}
	data.write(old_data);
}

/*
Write RAM Process, this process is a synchronized logic sensed to clock, that write the data of processor inside of the RAM
*/
void mem::writeRAM(){
	reg16 ad=address.read();
	int t=1;
	for(int c=0;c<WIDTHR8;c++)
		if((ad[c]==SC_LOGIC_X)||(ad[c]==SC_LOGIC_Z)){
			t=0;
			break;
		}
	if(t==1){
		sc_uint<WIDTHR8> adt=ad.to_uint();
		if((adt>=0)&&(adt<MEM_SIZE))
			if((ce.read()==SC_LOGIC_1)&&(rw.read()==SC_LOGIC_0))
				pMEM[adt] = data.read();
	}
}

/*
Memory Load Data Procedure, This procedure load the instruction(.obj) inside
ROM
*/
void mem::loadROM(){
	char lineStore[15];
	char fileName[50];
	//char buffer[15];
	cout << "Enter the name of file:";
	cin >> fileName;

	ifstream fp(fileName);

	if(!fp){
		cerr<< __FILE__ <<":"<<__LINE__<<" "<<"ERROR:open file"<<endl;
	}
	//FILE *fp = fopen(LOAD_FILE, "r");
	//if(!fp){
	//	cerr<< __FILE__ <<":"<<__LINE__<<" "<<"ERROR:open file"<<endl;
	//}
	//while(fgets(buffer, sizeof(buffer), fp))
	while(fp.getline(lineStore,15))
	{
		//if((!strlen(buffer))||(buffer[0]=='\n'))
		if((!strlen(lineStore))||(lineStore[0]=='\n'))
		{
			cout<<"\nERROR(1):Read file"<<endl;
			//fclose(fp);
			fp.close();
			break;
		}
		//if(buffer[0]!=';')//Comment start with ";"
		if(lineStore[0]!=';')//Comment start with ";"
		{
			//if(!getAddress(buffer)){
			if(!getAddress(lineStore)){
				cout<<"\nERROR(2):Address:"<<addressMEM<<endl;
				return;
			}
			if((addressMEM<0)||(addressMEM>=MEM_SIZE))
			{
				cout <<"\nERROR(3):Address out of range"<<addressMEM<< endl;
				//fclose(fp);
				fp.close();
				return;
			}
			//if(!getInstruction(buffer)){
			if(!getInstruction(lineStore)){
				cout<<"\nERROR(4):Instruction"<<instruction<<endl;
				//fclose(fp);
				fp.close();
				return;
			}
			//Write into ROM
			if((addressMEM>=0)&&(addressMEM<=MEM_SIZE))
			pMEM[addressMEM]=instruction;
			else{
				cout<<"ERROR(5): Address out of range:"<<addressMEM<<endl;
				//fclose(fp);
				fp.close();
				return;
			}
		}
	}
	cout<<"SUCCESS(1):Load of ROM"<<endl;
	//fclose(fp);
	fp.close();
}

/*
Get Address Procedure, return address in which the instruction
will be loading
*/
int mem::getAddress(const char *buff)
{
	int nStr=strlen(buff);
	long int base, n;
	if(nStr==0) return -1;
	addressMEM=0;
	base=1;
	for(int w=3;w>=0;w--)
	{
		if(w!=3){
			base=base*16;
		}
		switch(buff[w])
		{
			case '0':n=0;
				break;
			case '1':n=1;
				break;
			case '2':n=2;
				break;
			case '3':n=3;
				break;
			case '4':n=4;
				break;
			case '5':n=5;
				break;
			case '6':n=6;
				break;
			case '7':n=7;
				break;
			case '8':n=8;
				break;
			case '9':n=9;
				break;
			case 'A':n=10;
				break;
			case 'B':n=11;
				break;
			case 'C':n=12;
				break;
			case 'D':n=13;
				break;
			case 'E':n=14;
				break;
			case 'F':n=15;
				break;
			default:
				return 0;
		}
		addressMEM=addressMEM+(n*base);
	}
	return(1);
}

/*
Get Instruction Procedure, return the instruction that
will be recording
*/
int mem::getInstruction(const char *buff)
{
	int nStr=strlen(buff);
	reg16 i;
	reg4 bin, bin5, bin6, bin7, bin8;
	if(nStr<=0) return -1;
	for(int w=5;w<9;w++)
	{
		switch(buff[w])
		{

			case '0':bin="0000";
				break;
			case '1':bin="0001";
				break;
			case '2':bin="0010";
				break;
			case '3':bin="0011";
				break;
			case '4':bin="0100";
				break;
			case '5':bin="0101";
				break;
			case '6':bin="0110";
				break;
			case '7':bin="0111";
				break;
			case '8':bin="1000";
				break;
			case '9':bin="1001";
				break;
			case 'A':bin="1010";
				break;
			case 'B':bin="1011";
				break;
			case 'C':bin="1100";
				break;
			case 'D':bin="1101";
				break;
			case 'E':bin="1110";
				break;
			case 'F':bin="1111";
				break;
			default:return(0);
		}
		switch(w)
		{
			case 5:bin5=bin;
				break;
			case 6:bin6=bin;
				break;
			case 7:bin7=bin;
				break;
			case 8:bin8=bin;
				break;
			default:return(0);
		}
	}
	i=(bin5, bin6, bin7, bin8);
	instruction=reg16(i);
	return(1);
}
