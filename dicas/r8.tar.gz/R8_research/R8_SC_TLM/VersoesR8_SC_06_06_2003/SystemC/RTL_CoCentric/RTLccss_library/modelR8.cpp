// modelR8.cpp: source file

#include "controle.h"
#include "datapath.h"
#include "modelR8.h"

void modelR8::InitInstances() {
    ControllBlock = new controle("ControllBlock");
    dataBlock = new datapath("dataBlock");

    dataBlock->address(address);
    ControllBlock->ce(ce);
    dataBlock->ce(ce);
    dataBlock->ck(ck);
    ControllBlock->ck(ck);
    dataBlock->data(data);
    dataBlock->flags(flag_sgn);
    ControllBlock->flags(flag_sgn);
    dataBlock->instructor(ir_sgn);
    ControllBlock->ir(ir_sgn);
    dataBlock->ma(ma_sgn);
    ControllBlock->ma(ma_sgn);
    dataBlock->mad(mad_sgn);
    ControllBlock->mad(mad_sgn);
    dataBlock->mb(mb_sgn);
    ControllBlock->mb(mb_sgn);
    dataBlock->mpc(mpc_sgn);
    ControllBlock->mpc(mpc_sgn);
    dataBlock->mreg(mreg_sgn);
    ControllBlock->mreg(mreg_sgn);
    dataBlock->ms2(ms2_sgn);
    ControllBlock->ms2(ms2_sgn);
    dataBlock->msp(msp_sgn);
    ControllBlock->msp(msp_sgn);
    ControllBlock->rst(rst);
    dataBlock->rst(rst);
    ControllBlock->rw(rw);
    dataBlock->rw(rw);
    ControllBlock->ula(ula_sgn);
    dataBlock->ula(ula_sgn);
    ControllBlock->wab(wab_sgn);
    dataBlock->wab(wab_sgn);
    ControllBlock->wcv(wcu_sgn);
    dataBlock->wcv(wcu_sgn);
    dataBlock->wir(wir_sgn);
    ControllBlock->wir(wir_sgn);
    ControllBlock->wnz(wnz_sgn);
    dataBlock->wnz(wnz_sgn);
    dataBlock->wpc(wpc_sgn);
    ControllBlock->wpc(wpc_sgn);
    ControllBlock->wreg(wreg_sgn);
    dataBlock->wreg(wreg_sgn);
    ControllBlock->wsp(wsp_sgn);
    dataBlock->wsp(wsp_sgn);
    ControllBlock->wula(wula_sgn);
    dataBlock->wula(wula_sgn);
}

void modelR8::DeleteInstances() {
    if (ControllBlock) {delete ControllBlock; ControllBlock = 0;}
    if (dataBlock) {delete dataBlock; dataBlock = 0;}
}

