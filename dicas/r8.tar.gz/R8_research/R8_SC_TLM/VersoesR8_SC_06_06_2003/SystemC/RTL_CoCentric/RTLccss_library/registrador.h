#ifndef __registrador_h
#define __registrador_h

#include "r8.h"

#ifdef CCSS_USE_SC_CTOR
#define CCSS_INIT_MEMBERS_PREFIX : 
#undef CCSS_USE_SC_CTOR
#else
#define CCSS_INIT_MEMBERS_PREFIX , 
#endif

#ifndef SYNTHESIS
#define CCSS_INIT_MEMBERS  CCSS_INIT_MEMBERS_PREFIX \
    rst("rst") \
    , ck("ck") \
    , ce("ce") \
    , D("D") \
    , Q("Q")
#else
#define CCSS_INIT_MEMBERS 
#endif

struct registrador
: public sc_module
{

    // ports
    sc_in<sc_logic> rst;
    sc_in<sc_logic> ck;
    sc_in<sc_logic> ce;
    sc_in<sc_lv<16> > D;
    sc_out<sc_lv<16> > Q;

    // initialize parameters
    virtual void InitParameters() {
    }

    void asynchRstSynchCE();

    //Module constructor
    SC_CTOR(registrador){
      //register process
      SC_METHOD(asynchRstSynchCE);
      //Declare sensitivity list
      sensitive << rst << ck;
    }
}; // end module registrador
#undef CCSS_INIT_MEMBERS_PREFIX
#undef CCSS_INIT_MEMBERS

#endif
