// oner8onem.h: header file

#ifndef __oner8onem_h
#define __oner8onem_h

class oner8onem
: public sc_module
{

public:
    // channels
    sc_signal<sc_lv<16> > address;
    sc_signal<sc_logic> ce;
    sc_signal<sc_logic> ck;
    sc_signal<sc_lv<16> > data;
    sc_signal<sc_logic> rst;
    sc_signal<sc_logic> rw;

    // module instances
    mem *M1;
    processor *R8;
    test_bench *TB1;
    display *V1;
    sc_clock *clk;

    // initialize parameters
    virtual void InitParameters() {
    }
    // create the schematic
    virtual void InitInstances();

    // delete the schematic
    virtual void DeleteInstances();

	// default constructor
	SC_CTOR(oner8onem){
		oner8onem::InitParameters();

		// process declarations

		oner8onem::InitInstances();
	}

}; // end module oner8onem

#endif
