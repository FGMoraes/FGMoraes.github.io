
#include "r8.h"
#include "registrador.h"
#include "bcregs.h"
#include "datapath.h"
#include "controle.h"
#include "mem.h"
#include "processor.h"
#include "test_bench.h"
#include "display.h"
#include "oner8onem.h"

void oner8onem::InitInstances() {
    M1 = new mem("M1");
    R8 = new processor("R8");
    TB1 = new test_bench("TB1");
    V1 = new display("V1");
    clk = new sc_clock("clk");

    TB1->clk(*clk);
    V1->address(address);
    R8->address(address);
    M1->address(address);
    V1->ce(ce);
    R8->ce(ce);
    M1->ce(ce);
    V1->ck(ck);
    M1->ck(ck);
    R8->ck(ck);
    TB1->ck(ck);
    V1->data(data);
    R8->data(data);
    M1->data(data);
    V1->rst(rst);
    M1->rst(rst);
    R8->rst(rst);
    TB1->rst(rst);
    V1->rw(rw);
    R8->rw(rw);
    M1->rw(rw);
}

void oner8onem::DeleteInstances() {
    if (M1) {delete M1; M1 = 0;}
    if (R8) {delete R8; R8 = 0;}
    if (TB1) {delete TB1; TB1 = 0;}
    if (V1) {delete V1; V1 = 0;}
    if (clk) {delete clk; clk = 0;}
}

