#ifndef __display_h
#define __display_h

#include "r8.h"

#ifdef CCSS_USE_SC_CTOR
#define CCSS_INIT_MEMBERS_PREFIX : 
#undef CCSS_USE_SC_CTOR
#else
#define CCSS_INIT_MEMBERS_PREFIX , 
#endif

#ifndef SYNTHESIS
#define CCSS_INIT_MEMBERS  CCSS_INIT_MEMBERS_PREFIX \
    ck("ck") \
    , rst("rst") \
    , ce("ce") \
    , rw("rw") \
    , data("data") \
    , address("address")
#else
#define CCSS_INIT_MEMBERS 
#endif

class display
: public sc_module
{

public:
    // ports
    sc_in<sc_logic> ck;
    sc_in<sc_logic> rst;
    sc_in<sc_logic> ce;
    sc_in<sc_logic> rw;
    sc_in<reg16> data;
    sc_in<reg16> address;

    // initialize parameters
    virtual void InitParameters() {
    }


	// default constructor
	SC_CTOR(display){
		// process declarations
		SC_METHOD(print_result);
		sensitive_neg << ck;
		sensitive << rst;
		sensitive << ce;
		sensitive << data;
		sensitive << address;
	}

	void print_result();

}; // end module display
#undef CCSS_INIT_MEMBERS_PREFIX
#undef CCSS_INIT_MEMBERS

#endif
