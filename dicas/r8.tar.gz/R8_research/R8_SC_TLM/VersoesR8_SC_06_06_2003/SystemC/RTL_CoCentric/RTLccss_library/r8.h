#ifndef __r8_h
#define __r8_h

#include <systemc.h>

#define WIDTHR8 16
#define SIMULATION_TIME 5000
#define NFLAGS 4
#define MEM_SIZE 65536
#define LOAD_FILE "load.obj"
#define FLAG_N 0
#define FLAG_Z 1
#define FLAG_C 2
#define FLAG_V 3

typedef sc_lv<2> reg2;

typedef sc_lv<NFLAGS> reg4;

typedef sc_lv<WIDTHR8> reg16;

typedef enum {add=0, sub=1, e=2, ou=3, oux=4, addi=5, subi=6, ldl=7, ldh=8, ld=9, st=10, sl0=11, sl1=12, sr0=13, sr1=14, notA=15, nop=16, hlt=17, ldsp=18, rts=19, pop=20, push=21, saltoR=22, salto=23, saltoD=24, jsrr=25, jsr=26, jsrd=27}instruction;

struct flag{
  reg2 lnz;
  reg2 lcv;

/*  inline bool operator == ( const flag& flags) const
  {
    return(flags.lnz == lnz &&
      flags.lcv == lcv);
  } */
};
/* inline ostream&
operator << (ostream& os, const flag& flags)
{
  return os << flags.lnz << '/' << flags.lcv;
}*/

#endif