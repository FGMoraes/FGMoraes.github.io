#ifndef __test_bench_h
#define __test_bench_h

#include "r8.h"

#ifdef CCSS_USE_SC_CTOR
#define CCSS_INIT_MEMBERS_PREFIX : 
#undef CCSS_USE_SC_CTOR
#else
#define CCSS_INIT_MEMBERS_PREFIX , 
#endif

#ifndef SYNTHESIS
#define CCSS_INIT_MEMBERS  CCSS_INIT_MEMBERS_PREFIX \
    clk("clk") \
    , ck("ck") \
    , rst("rst")
#else
#define CCSS_INIT_MEMBERS 
#endif

struct test_bench
: public sc_module
{

    // ports

    // Module port declarations 
    sc_in_clk clk;
    sc_out<sc_logic> ck;
    sc_out<sc_logic> rst;

    // initialize parameters
    virtual void InitParameters() {
    }

    // initialize parameters
	unsigned cycle;

	void converte();
	void entry();

	//Module constructor
	SC_CTOR(test_bench){
		SC_METHOD(converte);
		sensitive << clk;
		//register process
		SC_THREAD(entry);
		sensitive << clk.pos();
		cycle=0;
	}
}; // end module test_bench
#undef CCSS_INIT_MEMBERS_PREFIX
#undef CCSS_INIT_MEMBERS

#endif
