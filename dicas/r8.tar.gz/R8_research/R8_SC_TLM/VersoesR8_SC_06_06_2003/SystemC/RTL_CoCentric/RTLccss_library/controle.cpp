// controle.cpp: source file

#include "controle.h"

void controle::set_flags(){

  fn.write(flags.read()[FLAG_N]);
  fz.write(flags.read()[FLAG_Z]);
  fc.write(flags.read()[FLAG_C]);
  fv.write(flags.read()[FLAG_V]);
}
void controle::set_instruction(){
  reg16 air=ir.read();
  int f=1;
// Tenho q verificar se nao for X ou Z antes da atribui�ao
  for(int ind=0;ind<WIDTHR8;ind++)
  	if((air[ind]!=1)&&(air[ind]!=0))f=0;
  if(f==1){
  	sc_uint<4> ir15_12=air.range(15,12).to_uint();
  	sc_uint<4> ir3_0=air.range(3,0).to_uint();
  	sc_uint<2> ir11_10=air.range(11,10).to_uint();

	if(ir15_12==0)i=add;
 	else if(ir15_12==1)i=sub;
	else if(ir15_12==2)i=e;
	else if(ir15_12==3)i=ou;
	else if(ir15_12==4)i=oux;
	else if(ir15_12==5)i=addi;
	else if(ir15_12==6)i=subi;
	else if(ir15_12==7)i=ldl;
	else if(ir15_12==8)i=ldh;
	else if(ir15_12==9)i=ld;
	else if(ir15_12==10)i=st;
	else if((ir15_12==11)&&(ir3_0==0))i=sl0;
	else if((ir15_12==11)&&(ir3_0==1))i=sl1;
	else if((ir15_12==11)&&(ir3_0==2))i=sr0;
	else if((ir15_12==11)&&(ir3_0==3))i=sr1;
	else if((ir15_12==11)&&(ir3_0==4))i=notA;
	else if((ir15_12==11)&&(ir3_0==5))i=nop;
	else if((ir15_12==11)&&(ir3_0==6))i=hlt;
	else if((ir15_12==11)&&(ir3_0==7))i=ldsp;
	else if((ir15_12==11)&&(ir3_0==8))i=rts;
	else if((ir15_12==11)&&(ir3_0==9))i=pop;
	else if((ir15_12==11)&&(ir3_0==10))i=push;

	else if( (ir15_12==12) && (
		(ir3_0==0) ||
		((ir3_0==1)&&(fn.read()==1)) ||
		((ir3_0==2)&&(fz.read()==1)) ||
		((ir3_0==3)&&(fc.read()==1)) ||
		((ir3_0==4)&&(fv.read()==1)) ) )i=saltoR;
	else if( (ir15_12==12) && (
		(ir3_0==5) ||
		((ir3_0==6)&&(fn.read()==1)) ||
		((ir3_0==7)&&(fz.read()==1)) ||
		((ir3_0==8)&&(fc.read()==1)) ||
		((ir3_0==9)&&(fv.read()==1)) ) )i=salto;
	else if( (ir15_12==13) || (
		 (ir15_12==14)&& (
		((ir11_10==0)&&(fn.read()==1)) ||
		((ir11_10==1)&&(fz.read()==1)) ||
		((ir11_10==2)&&(fc.read()==1)) ||
		((ir11_10==3)&&(fv.read()==1)) ) ) )i=saltoD;
	else if((ir15_12==12)&&(ir3_0==10))i=jsrr;
	else if((ir15_12==12)&&(ir3_0==11))i=jsr;
	else if(ir15_12==15)i=jsrd;
	else i=nop;
}
}

void controle:: set_uins_instruction(){
ula.write(i.read());
}

void controle::set_inst_la(){
instruction ai=i.read();
	if((ai==add)||(ai==sub)||(ai==e)||(ai==ou)||(ai==oux)||(ai==notA)||(ai==sl0)||(ai==sr0)||(ai==sl1)||(ai==sr1)) inst_la1=sc_logic('1');
	else inst_la1=sc_logic('0');

	if((ai==addi)||(ai==subi)||(ai==ldl)||(ai==ldh)) inst_la2=sc_logic('1');
	else inst_la2=sc_logic('0');
}

void controle::set_c_i(){
instruction ai=i.read();

	if((ai==jsrr)||(ai==jsr)||(ai==jsrd)||(ai==push)) msp.write(sc_logic('1'));
  else msp.write(sc_logic('0'));

  if((ai==ld)||(ai==pop)) mreg.write(sc_logic('1'));
  else mreg.write(sc_logic('0'));

	if((ai==rts)||(ai==pop)) mb.write("01");
	else if((ai==saltoR)||(ai==salto)||(ai==saltoD)||(ai==jsrr)||(ai==jsr)||(ai==jsrd)) mb.write("10");
	else mb.write("00");
}
void controle::set_change_EA(){
type_state aEA=EA.read();
	if(aEA==Sfetch) mpc.write("10");
	else if(aEA==Srts) mpc.write("00");
	else mpc.write("01");
	if((aEA==Spush)||(aEA==Ssbrt)) mad.write("10");
	else if(aEA==Sfetch) mad.write("01");
	else mad.write("00");

  if((aEA==Sfetch)||(aEA==Sjmp)||(aEA==Ssbrt)||(aEA==Srts)) wpc.write(sc_logic('1')); else wpc.write(sc_logic('0'));

  if((aEA==Sldsp)||(aEA==Srts)||(aEA==Ssbrt)||(aEA==Spush)||(aEA==Spop)) wsp.write(sc_logic('1'));
  else wsp.write(sc_logic('0'));

  if(aEA==Sfetch) wir.write(sc_logic('1'));
  else wir.write(sc_logic('0'));

  if(aEA==Srreg) wab.write(sc_logic('1'));
  else wab.write(sc_logic('0'));

  if(aEA==Sula) wula.write(sc_logic('1'));
  else wula.write(sc_logic('0'));

  if((aEA==Sfetch)||(aEA==Srts)||(aEA==Spop)||(aEA==Sld)||(aEA==Ssbrt)||(aEA==Spush)||(aEA==Sst)) ce.write(sc_logic('1'));
  else ce.write(sc_logic('0'));

  if((aEA==Sfetch)||(aEA==Srts)||(aEA==Spop)||(aEA==Sld)) rw.write(sc_logic('1'));
  else rw.write(sc_logic('0'));
}

void controle::set_WREG(){
type_state aEA=EA.read();
  if((aEA==Swbk)||(aEA==Sld)||(aEA==Spop)) wreg.write(sc_logic('1'));
  else wreg.write(sc_logic('0'));
}

void controle::set_c_EA_i(){
instruction ai=i.read();
type_state aEA=EA.read();
  if((aEA==Sula)&&((ai==add)||(ai==addi)||(ai==sub)||(ai==subi))) wcv.write(sc_logic('1'));
  else wcv.write(sc_logic('0'));
}
void controle::set_inst_la2_i_EA(){
sc_logic ai_la2=inst_la2.read();
type_state aEA=EA.read();
instruction ai=i.read();
  if((ai_la2==1)||(ai==push)||(aEA==Sst)) ms2.write(sc_logic('1'));
  else ms2.write(sc_logic('0'));

  if((ai_la2==1)||(i==saltoD)||(i==jsrd)) ma.write(sc_logic('1'));
  else ma.write(sc_logic('0'));
}
void controle::set_inst_la1_i(){
sc_logic ai_la1=inst_la1.read();
type_state aEA=EA.read();
instruction ai=i.read();
  if((aEA==Sula)&&((ai_la1==1)||(ai==addi)||(ai==subi))) wnz.write(sc_logic('1'));
  else wnz.write(sc_logic('0'));
}

void controle::process_EA(){
	if(rst.read()==1) EA=Sfetch;
	else EA=PE.read();
}

void controle::process_PE(){
instruction iaux=i.read();
	switch(EA.read()){
	case Sfetch:
		if(iaux==hlt) PE=Shalt;
		else PE=Srreg;
		break;
	case Shalt:
		PE=Shalt;
		break;
	case Srreg:
		PE=Sula;
		break;
	case Sula:
		if(iaux==pop) PE=Spop;
		else if(iaux==rts) PE=Srts;
		else if(iaux==ldsp) PE=Sldsp;
		else if(iaux==ld) PE=Sld;
		else if(iaux==st) PE=Sst;
		else if((inst_la1==1)||(inst_la2==1))PE=Swbk;
		else if((iaux==saltoR)||(iaux==salto)||(iaux==saltoD)) PE=Sjmp;
		else if((iaux==jsrr)||(iaux==jsr)||(iaux==jsrd)) PE=Ssbrt;
		else if(iaux==push) PE=Spush;
		else PE=Sfetch;
		break;
	case Spop:
	case Srts:
	case Sldsp:
	case Sld:
	case Sst:
	case Swbk:
	case Sjmp:
	case Ssbrt:
	case Spush:
	default:
		PE=Sfetch;
	}
}
