#ifndef __mem_h
#define __mem_h

#include "r8.h"

#ifdef CCSS_USE_SC_CTOR
#define CCSS_INIT_MEMBERS_PREFIX : 
#undef CCSS_USE_SC_CTOR
#else
#define CCSS_INIT_MEMBERS_PREFIX , 
#endif

#ifndef SYNTHESIS
#define CCSS_INIT_MEMBERS  CCSS_INIT_MEMBERS_PREFIX \
    rst("rst") \
    , ck("ck") \
    , ce("ce") \
    , rw("rw") \
    , address("address") \
    , data("data")
#else
#define CCSS_INIT_MEMBERS 
#endif

struct mem
: public sc_module
{

    // ports
    sc_in<sc_logic> rst;
    sc_in<sc_logic> ck;
    sc_in<sc_logic> ce;
    sc_in<sc_logic> rw;
    sc_in<reg16> address;
    sc_inout<reg16> data;

    // initialize parameters
    virtual void InitParameters() {
    }

	reg16 instruction;
	int addressMEM;

	void readRAM();
	void writeRAM();
	void loadROM();
	int getAddress(const char *);
	int getInstruction(const char *);

	sc_signal<reg16> pMEM[MEM_SIZE];

	SC_CTOR(mem){
		SC_METHOD(readRAM);
		sensitive << address << ce << rw <<rst;

		SC_METHOD(writeRAM);
		sensitive << ck.neg();

		SC_METHOD(loadROM);
		sensitive << rst.pos();
	}
}; // end module mem
#undef CCSS_INIT_MEMBERS_PREFIX
#undef CCSS_INIT_MEMBERS

#endif
