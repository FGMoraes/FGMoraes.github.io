#ifndef _memoryChl_h
#define _memoryChl_h

#include "systemc.h"
#include "R8MemIf.h"
#include "memR8If.h"

class memoryChl: public sc_channel, public R8MemIf, public memR8If{
  public:

    typedef sc_lv<word_size>   word_type;
    typedef sc_uint<word_size> ad_type;

    memoryChl(sc_module_name name) : sc_channel(name) {
      // carregar as instrucoes
      // inicializar variaveis
      PC=0;
      SP=mem_size-1;
    }

    ~memoryChl(){
      cout << "mem�ria desalocada" << endl;
    }

    void getAddress(ad_type *address){
      // passos para pegar um endereco
      // 1 - aguarda solicitacao
      // 2 - pega o endereco armazenado localmente

      wait(addressAvailable);
      *address=memPosition;
    }

    void getNxtWord(word_type *word){
      // passos para pegar a proxima palavra
      // 1 - atualiza a variavel local com o PC
      // 2 - notifica a memoria que um dado tem de ser enviado
      // 3 - aguarda a memoria liberar o dado em uma variavel local
      // 4 - incrementa PC

      memPosition = PC;
      addressAvailable.notify();
      wait(dataOk);
      *word=localWord;
      PC++;
    }

    void updatePC(ad_type newPC){
      PC=newPC;
    };

    void getPC(ad_type *PCValue){
      *PCValue=PC;
    };

  //===========================================================================

    void updateMem(ad_type *address, word_type *word){

      // passos para a atualizacao de uma posicao da memoria
      // 1 - aguarda solicitacao de atualizacao da memoria
      // 2 - envia os valores enviados pelo processador
      // 3 - notifica que os dados jah pode ser carregados

      wait(writeMem);

      *address=memPosition;
      *word=localWord;

      memWrote.notify();
    };


    void sendWord(word_type word){

      // passos para enviar uma palavra a partir da memoria
      // 1 - armazena localmente
      // 2 - notifica acao

      localWord=word;
      dataOk.notify();
    };


    void writeMemory(ad_type address, word_type word){
      // passos para escrever na memoria
      // 1 - armazena localmente endereco e dado a ser escrito
      // 2 - notifica a acao
      // 3 - aguarda notificacao de final do processo

      memPosition = address;
      localWord = word;

      writeMem.notify();

      wait(memWrote);

    };

    void readMemory(ad_type address, word_type *word){
      // passos para ler uma posicao da memoria
      // 1 - armazena localmente endereco que se deseja buscar
      // 2 - notifica a memoria da acao
      // 3 - aguarda notificacao de que o dado esta armazenado localmente
      // 4 - carrega o dado

      memPosition = address;
      addressAvailable.notify();
      wait(dataOk);
      *word = localWord;

    };

    void startupSP(ad_type upSP){
      SP = upSP;
    };

    void execPOP(word_type *word){
      // passos para desempilhar
      // 1 - armazena localmente o valor do stack pointer
      // 2 - diminui a pilha incrementando o SP
      // 3 - notifica acao de leitura da memoria
      // 4 - aguarda notificao de leitura
      // 5 - carrega o dado armazenado

      memPosition=SP;
      SP++;
      addressAvailable.notify();
      wait(dataOk);
      *word=localWord;
    };

    void execPUSH(word_type word){
      // passo para empilhar
      // 1 - armazena o endereco de SP e o dado enviado
      // 2 - aumenta o tamanho da pilha decrementando SP
      // 3 - notifica acao de atualizacao da memoria
      // 4 - aguarda escrita na memoria funcionar

      memPosition=SP;
      localWord=word;
      SP--;
      writeMem.notify();
      wait(memWrote);
    };

  private:

    // instructions
    ad_type   PC, SP, memPosition;
    word_type localWord;
    sc_event  addressAvailable, wordAvailable;
    sc_event writeMem, readMem;
    sc_event dataOk, memWrote;

};

#endif
