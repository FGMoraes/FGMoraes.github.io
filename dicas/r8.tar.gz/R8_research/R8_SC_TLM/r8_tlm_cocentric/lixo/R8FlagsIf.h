#ifndef __R8FlagsIf_h
#define __R8FlagsIf_h

#ifndef __systemc_h
#define __systemc_h
#include <systemc.h>
#endif

#ifndef __common_defs_h
#define __common_defs_h
#include "../aditional/common_defs.h"
#endif

class R8FlagsIf : virtual public sc_interface{
  public:
    typedef sc_uint<flags_representation> flag_type;
    typedef sc_logic flag_value;
    typedef sc_lv<word_size> source_type;
    typedef sc_lv<result_size> result_type;

    virtual void getlnz(result_type) = 0;
    virtual void getlcv(result_type, source_type, source_type) = 0;
    virtual void getlnz_lcv(result_type, source_type, source_type) = 0;
    virtual flag_value getFlag(flag_type) = 0;
};

#endif
