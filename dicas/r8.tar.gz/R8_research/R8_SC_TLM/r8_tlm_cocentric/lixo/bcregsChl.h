#ifndef __bcregsChl_h
#define __bcregsChl_h

#include <systemc.h>
#include "R8RegsIf.h"
#include "regR8If.h"

class bcregsChl : public sc_channel, public R8RegsIf, public regR8If{

  public:

    typedef sc_uint<4> reg_type;
    typedef sc_lv<16> value_type;

    //elementos b�sicos do canal
    bcregsChl(sc_module_name name) : sc_channel(name) {}

    ~bcregsChl(){
      cout << "fim do processo" << endl;
    }

    //m�todos definidos em regR8If
    void updateReg(reg_type *reg, value_type *value){
      wait(updateRegEv);
      *reg=reg1;
      *value=val1;
      updateOk.notify();
    };

    void regNum(reg_type *reg){
      wait(num1Regs);
      *reg=reg1;
    };

    void regNum(reg_type *regist1, reg_type *regist2){
      wait(num2Regs);
      *regist1=reg1;
      *regist2=reg2;
    };

    void sendRegValue(value_type value){
      val1 = value;
      val1Available.notify();
    };

    void sendRegValue(value_type value1, value_type value2){
      val1 = value1;
      val2 = value2;
      val2Available.notify();
    };

    //m�todos definidos em R8RegsIf
    void writeReg(reg_type regist, value_type value){
      reg1=regist;
      val1=value;
      updateRegEv.notify();
      wait(updateOk);
    };

    void readReg(reg_type regist, value_type * value){
      reg1=regist;
      num1Regs.notify();
      wait(val1Available);
      *value=val1;
    };

    void readReg(reg_type regist1, value_type *value1, reg_type regist2, value_type *value2){
      reg1=regist1;
      reg2=regist2;
      num2Regs.notify();
      wait(val2Available);
      *value1=val1;
      *value2=val2;
    };


  private:
    reg_type reg1,reg2;
    value_type val1,val2;

    sc_event updateRegEv,num1Regs,num2Regs,val1Available,val2Available;
    sc_event updateOk;

};

#endif
