#ifndef _extChl_h
#define _extChl_h

#include "systemc.h"
#include "extMemIf.h"
#include "memExtIf.h"

class extChl: public sc_channel, public extMemIf, public memExtIf{
  public:

    typedef sc_lv<word_size>   word_type;
    typedef sc_uint<word_size> ad_type;

    extChl(sc_module_name name) : sc_channel(name) {
    }

    ~memoryChl(){
    }

};

#endif
