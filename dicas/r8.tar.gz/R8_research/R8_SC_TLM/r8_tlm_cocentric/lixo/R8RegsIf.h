#ifndef __R8RegsIf_h
#define __R8RegsIf_h

#ifndef __systemc_h
#define __systemc_h
#include <systemc.h>
#endif

#ifndef __common_defs_h
#define __common_defs_h
#include "../aditional/common_defs.h"
#endif

class R8RegsIf : virtual public sc_interface{
  public:
    typedef sc_uint<4> reg_type;
    typedef sc_lv<16> value_type;

    virtual void writeReg(reg_type, value_type) = 0;
    virtual void readReg(reg_type, value_type *) = 0;
    virtual void readReg(reg_type, value_type *, reg_type, value_type *) = 0;
};

#endif
