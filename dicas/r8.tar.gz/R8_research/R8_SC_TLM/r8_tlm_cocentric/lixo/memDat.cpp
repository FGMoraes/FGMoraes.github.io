#include "systemc.h"
#include "memR8If.h"
#include "memDat.h"

void memDat::receiveData(){
  while(true){
    porta->updateMem(&address, &data);
    if(address>1023){break;};
    memoria[address] = data;
  }
};

void memDat::sendData(){
  while(true){
    porta->getAddress(&address);
    if(address>1000){break;};
    data = memoria[address];
    porta->sendData(data);
  }
};

