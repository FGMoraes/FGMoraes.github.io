#ifndef __processor_op_h
#define __processor_op_h

#define R8_ADD(Target,Source1,Source2) portaRegs->readReg(Source1,&vSource1,Source2,&vSource2); iResult=vSource1.to_int()+vSource2.to_int(); vResult=iResult; portaFlag->getlnz_lcv(vResult,vSource1,vSource2); vTarget=vResult.range(15,0); portaRegs->writeReg(Target,vTarget);

#define R8_SUB(Target,Source1,Source2) portaRegs->readReg(Source1,&vSource1,Source2,&vSource2); iSource1=vSource1; iSource2=vSource2; iResult=0; iResult=iSource1-iSource2; vResult=iResult; portaFlag->getlnz_lcv(vResult, vSource1, vSource2); vTarget=vResult.range(15,0); portaRegs->writeReg(Target,vTarget);

#define R8_AND(Target,Source1,Source2) portaRegs->readReg(Source1,&vSource1,Source2,&vSource2); iResult=0; vResult=iResult; vResult=vSource1&vSource2; portaFlag->getlnz(vResult); vTarget= vResult(15,0); portaRegs->writeReg(Target,vTarget);

#define R8_OR(Target,Source1,Source2) portaRegs->readReg(Source1,&vSource1,Source2,&vSource2); iResult=0; vResult=iResult; vResult=vSource1|vSource2; portaFlag->getlnz(vResult); vTarget=vResult.range(15,0); portaRegs->writeReg(Target,vTarget);

#define R8_XOR(Target,Source1,Source2) portaRegs->readReg(Source1,&vSource1,Source2,&vSource2); iResult=0; vResult=iResult; vResult=vSource1^vSource2; portaFlag->getlnz(vResult); vTarget=vResult.range(15,0); portaRegs->writeReg(Target,vTarget);

#define R8_ADDI(Target,Const) portaRegs->readReg(Target,&vTarget); iTarget=vTarget; vConst16=("00000000",vConst8); iConst16=vConst16; iResult=0; iResult=iTarget+iConst16; vResult=iResult; portaFlag->getlnz_lcv(vResult, vTarget, vConst16); vTarget=vResult.range(15,0); portaRegs->writeReg(Target,vTarget);

#define R8_SUBI(Target,Const) portaRegs->readReg(Target,&vTarget); iTarget=vTarget; vConst16=("00000000",vConst8); iConst16=vConst16; iResult=0; iResult=iTarget-iConst16; vResult=iResult; portaFlag->getlnz_lcv(vResult, vTarget, vConst16); vTarget=vResult.range(15,0); portaRegs->writeReg(Target,vTarget);

#define R8_LDL(Target,Const) portaRegs->readReg(Target,&vTarget); vTarget=(vTarget.range(15,8),Const); portaRegs->writeReg(Target,vTarget);

#define R8_LDH(Target,Const) portaRegs->readReg(Target,&vTarget); vTarget=(Const,vTarget.range(7,0)); portaRegs->writeReg(Target,vTarget);

#define R8_LD(Target,Source1,Source2) portaRegs->readReg(Source1,&vSource1,Source2,&vSource2); iSource1=vSource1; iSource2=vSource2; iSource1+=iSource2; uSource1=iSource1; portaMem->readMemory(uSource1,&vTarget); portaRegs->writeReg(Target,vTarget);

#define R8_ST(Target,Source1,Source2) portaRegs->readReg(Source1,&vSource1,Source2,&vSource2); iSource1=vSource1; iSource2=vSource2; iSource1+=iSource2; uSource1=iSource1; portaRegs->readReg(rTarget, &vTarget); portaMem->writeMemory(uSource1,vTarget);

#define R8_SL0(Target,Source1) portaRegs->readReg(Source1,&vSource1); vTarget= (vSource1.range(14,0),"0"); vResult= ("0",vTarget); portaFlag->getlnz(vResult); portaRegs->writeReg(Target,vTarget);

#define R8_SL1(Target,Source1) portaRegs->readReg(Source1,&vSource1); vTarget = (vSource1.range(14,0),"1"); vResult= ("0",vTarget); portaFlag->getlnz(vResult); portaRegs->writeReg(Target,vTarget);

#define R8_SR0(Target,Source1) portaRegs->readReg(Source1,&vSource1); vTarget = ("0",vSource1.range(15,1)); vResult= ("0",vTarget); portaFlag->getlnz(vResult); portaRegs->writeReg(Target,vTarget);

#define R8_SR1(Target,Source1) portaRegs->readReg(Source1,&vSource1); vTarget = ("1",vSource1.range(15,1)); vResult= ("0",vTarget); portaFlag->getlnz(vResult); portaRegs->writeReg(Target,vTarget);

#define R8_NOT(Target,Source1) portaRegs->readReg(Source1,&vSource1); vTarget = ~ vSource1; vResult= ("0",vTarget); portaFlag->getlnz(vResult); portaRegs->writeReg(Target,vTarget);

#define R8_NOP()

#define R8_HALT()

#define R8_LDSP(Source) portaRegs->readReg(Source,&vSource1); uSource1=vSource1; portaMem->startupSP(uSource1);

#define R8_RTS() portaMem->execPOP(&vSource1); uSource1=vSource1; portaMem->updatePC(uSource1);

#define R8_POP(Target) portaMem->execPOP(&vSource1); portaRegs->writeReg(Target,vSource1);

#define R8_PUSH(Source) portaRegs->readReg(Source,&vSource1); portaMem->execPUSH(vSource1);

#define R8_JMPR(Source) portaMem->getPC(&uSource2); portaRegs->readReg(Source,&vSource1); uSource1=vSource1; uSource1+=uSource2; portaMem->updatePC(uSource1);

#define R8_JMPNR(Source) if(portaFlag->getFlag(negative)=="1"){R8_JMPR(Source);};

#define R8_JMPZR(Source) if(portaFlag->getFlag(zero)=="1"){R8_JMPR(Source);};

#define R8_JMPCR(Source) if(portaFlag->getFlag(carry)=="1"){R8_JMPR(Source);};

#define R8_JMPVR(Source) if(portaFlag->getFlag(overflow)=="1"){R8_JMPR(Source);};

#define R8_JMP(Source) portaRegs->readReg(Source,&vSource1); uSource1=vSource1; portaMem->updatePC(uSource1);

#define R8_JMPN(Source) if(portaFlag->getFlag(negative)=="1"){R8_JMP(Source);};

#define R8_JMPZ(Source) if(portaFlag->getFlag(zero)=="1"){R8_JMP(Source);};

#define R8_JMPC(Source) if(portaFlag->getFlag(carry)=="1"){R8_JMP(Source);};

#define R8_JMPV(Source) if(portaFlag->getFlag(overflow)=="1"){R8_JMP(Source);};

#define R8_JSRR(Source) portaMem->getPC(&uSource2); vSource2=uSource2; portaMem->execPUSH(vSource2); portaRegs->readReg(Source,&vSource1); uSource1=vSource1; uSource1+=uSource2; portaMem->updatePC(uSource1);

#define R8_JSR(Source) portaMem->getPC(&uSource2); vSource2=uSource2; portaMem->execPUSH(vSource2); portaRegs->readReg(Source,&vSource1); uSource1=vSource1; portaMem->updatePC(uSource1);

#define R8_JMPD(Constant) portaMem->getPC(&uSource2); uSource1=Constant; uSource1+=uSource2; portaMem->updatePC(uSource1);

#define R8_JMPND(Constant) if(portaFlag->getFlag(negative)=="1"){R8_JMPD(Constant);};

#define R8_JMPZD(Constant) if(portaFlag->getFlag(zero)=="1"){R8_JMPD(Constant);};

#define R8_JMPCD(Constant) if(portaFlag->getFlag(carry)=="1"){R8_JMPD(Constant);};

#define R8_JMPVD(Constant) if(portaFlag->getFlag(overflow)=="1"){R8_JMPD(Constant);};

#define R8_JSRD(Constant) portaMem->getPC(&uSource1); vSource1=uSource1; portaMem->execPUSH(vSource1); uSource2=Constant; uSource1+=uSource2; portaMem->updatePC(uSource1);

#endif