#ifndef __memory_h
#define __memory_h

#include <systemc.h>
#include <stdio.h>
#include <stdlib.h>

#include "common_defs.h"
#include "memR8If.h"
#include "estAsm.h"
#include "listAsm.h"

struct memory: public sc_module, public listAsm{

  typedef sc_uint<16> ad_type;
  typedef sc_lv<16> word_type;

  sc_port<memR8If> porta;
  word_type memoria[mem_size];
  ad_type address;

  SC_HAS_PROCESS(memory);

  memory(sc_module_name name) : sc_module(name), listAsm(){

    carregaSym();
    fillMem();

    SC_THREAD(sendWord);
    SC_THREAD(receiveWord);
  }

  ~memory(){
		int i;

		for(i=0; i<=getNroLinhas(); i++){
			cout << "memoria[" << i << "] : " << memoria[i] << endl;
		};

	}

  void sendWord();
  void receiveWord();
  void fillMem();

};

#endif
