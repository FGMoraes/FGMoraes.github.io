#include "common_defs.h"

#ifndef _MemExtIf
#define _MemExtIf

class memExtIf : virtual public sc_interface{
  public:
    typedef sc_lv<20> word_type;
    typedef sc_uint<$address_size> ad_type;

    virtual void loadWord(ad_type, word_type) = 0;
    virtual void memoryLoaded() = 0;

};

#endif