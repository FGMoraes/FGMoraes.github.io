#ifndef __memDat_h
#define __memDat_h

SC_MODULE(memDat){

  typedef sc_uint<16> ad_type;
  typedef sc_lv<16>  dt_type;

  sc_port<memR8If> porta;
  dt_type memoria[256];
  ad_type address;
  dt_type data;

  SC_HAS_PROCESS(memDat);

  memDat(sc_module_name name) : sc_module(name){
    SC_THREAD(sendData);    
    SC_THREAD(receiveData);    
  }

  void receiveData();
  void sendData();

};

#endif