#include "common_defs.h"

#ifndef _extMemIf
#define _extMemIf

class extMemIf : virtual public sc_interface{
  public:
    typedef char[20] word_type;

    virtual void writeMemory(word_type) = 0;
    virtual void finishWritting() = 0;

};

#endif