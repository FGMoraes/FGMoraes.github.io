var searchData=
[
  ['blocked',['BLOCKED',['../local__scheduler_8h.html#a48f6457243719e7031768d4100741159',1,'local_scheduler.h']]],
  ['borrowed_5fmaster',['borrowed_master',['../structTask.html#a41102163ec466c71558c82d49d169316',1,'Task']]],
  ['bss_5flenght',['bss_lenght',['../structTCB.html#a45d52494ac38380c17c0e1a40f5f8b30',1,'TCB']]],
  ['bss_5fsize',['bss_size',['../structTask.html#a4802250a9c2270155711e83ab440969e',1,'Task::bss_size()'],['../structServiceHeader.html#ac56fc252ae5ff71522f783dc22d7d4c7',1,'ServiceHeader::bss_size()']]]
];
