var searchData=
[
  ['page_5freleased',['page_released',['../cluster__scheduler_8c.html#adbc5e42e06578becadc564610883f9e0',1,'page_released(int cluster_id, int proc_address, int task_ID):&#160;cluster_scheduler.c'],['../cluster__scheduler_8h.html#ac53e455125174b243fdbb87ef42b1fdb',1,'page_released(int, int, int):&#160;cluster_scheduler.c']]],
  ['page_5fused',['page_used',['../cluster__scheduler_8c.html#ae87140522b80930044b967915ba9f427',1,'page_used(int cluster_id, int proc_address, int task_ID):&#160;cluster_scheduler.c'],['../cluster__scheduler_8h.html#a9b169875100912cf11b2626e17eae523',1,'page_used(int, int, int):&#160;cluster_scheduler.c']]],
  ['pipe_5fmsg_5fnumber',['PIPE_msg_number',['../communication_8c.html#a16ec43ffeee664a654bac2a2a9fe7337',1,'PIPE_msg_number():&#160;communication.c'],['../communication_8h.html#a16ec43ffeee664a654bac2a2a9fe7337',1,'PIPE_msg_number():&#160;communication.c']]],
  ['puts',['puts',['../utils_8c.html#ac4bb7070d519c1fe12628cfe4397082f',1,'puts(char *string):&#160;utils.c'],['../utils_8h.html#a9fc8461fb5cf3ebe4800d74c7439e78a',1,'puts(char *):&#160;utils.c']]]
];
