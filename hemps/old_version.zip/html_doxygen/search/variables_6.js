var searchData=
[
  ['global_5finst',['global_inst',['../packet_8c.html#ab6d4fc49a6f784d48903a475b426f21a',1,'packet.c']]],
  ['global_5fmaster_5faddress',['global_master_address',['../kernel__master_8c.html#a443b1bffc22c569740889da86214d050',1,'kernel_master.c']]]
];
