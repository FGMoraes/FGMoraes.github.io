var searchData=
[
  ['max_5fglobal_5ftasks',['MAX_GLOBAL_TASKS',['../new__task_8h.html#aaf8b707bc5b7ab968461559445bc4608',1,'new_task.h']]],
  ['max_5ftask_5fdependeces',['MAX_TASK_DEPENDECES',['../applications_8h.html#a3b2fb4575c7e452065f793351b576248',1,'applications.h']]],
  ['max_5ftask_5fslots',['MAX_TASK_SLOTS',['../communication_8h.html#a75cf53b6be6b24c6910d483b189c0e5f',1,'communication.h']]],
  ['max_5ftime_5fslice',['MAX_TIME_SLICE',['../local__scheduler_8h.html#a7a8524d52a91ba1841e95f6d4f0dcd6b',1,'local_scheduler.h']]],
  ['migrating',['MIGRATING',['../applications_8h.html#ad6c6d97469a102841e8a13b8d627611e',1,'MIGRATING():&#160;applications.h'],['../local__scheduler_8h.html#ad6c6d97469a102841e8a13b8d627611e',1,'MIGRATING():&#160;local_scheduler.h']]],
  ['migration_5fenabled',['MIGRATION_ENABLED',['../kernel__slave_8h.html#a9c58b7c980993976443e4cf591925713',1,'kernel_slave.h']]]
];
