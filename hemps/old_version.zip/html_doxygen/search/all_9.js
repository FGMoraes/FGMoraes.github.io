var searchData=
[
  ['kernel_5fmaster_2ec',['kernel_master.c',['../kernel__master_8c.html',1,'']]],
  ['kernel_5fmaster_2eh',['kernel_master.h',['../kernel__master_8h.html',1,'']]],
  ['kernel_5fslave_2ec',['kernel_slave.c',['../kernel__slave_8c.html',1,'']]],
  ['kernel_5fslave_2eh',['kernel_slave.h',['../kernel__slave_8h.html',1,'']]]
];
