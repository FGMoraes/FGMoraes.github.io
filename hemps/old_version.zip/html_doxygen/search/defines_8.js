var searchData=
[
  ['pending_5fservice_5ftam',['PENDING_SERVICE_TAM',['../pending__service_8h.html#ad09600a1643ccea3dfeb0b56f964165d',1,'pending_service.h']]]
];
