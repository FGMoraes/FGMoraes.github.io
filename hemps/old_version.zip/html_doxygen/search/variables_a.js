var searchData=
[
  ['master_5faddress',['master_address',['../structTCB.html#ae3222a6215294bbc81ffea87844ac590',1,'TCB']]],
  ['master_5fid',['master_ID',['../structNewTask.html#ae810fa48c954695ef5fa77e72d0f519f',1,'NewTask']]],
  ['max_5fneighbors_5flevel',['max_neighbors_level',['../reclustering_8c.html#a7e63c726de12ed9662da34d0874b0b2b',1,'reclustering.c']]],
  ['message',['message',['../structPipeSlot.html#aa64fba54f099ce4b36651ed7de0c967a',1,'PipeSlot']]],
  ['message_5frequest',['message_request',['../communication_8c.html#a1a8c4d25bc4160a2c3a6f291e65e54e1',1,'communication.c']]],
  ['min_5floan_5fproc_5fhops',['min_loan_proc_hops',['../structReclustering.html#aec1565caa47c09eb41997cf8402952ce',1,'Reclustering']]],
  ['msg_5flenght',['msg_lenght',['../structServiceHeader.html#ab76cc88a37a56d3ef4fc1f25a3efd782',1,'ServiceHeader']]],
  ['msg_5fwrite_5fpipe',['msg_write_pipe',['../kernel__slave_8c.html#a64272255f5bd2e1bd4ebcce94afcd0a0',1,'kernel_slave.c']]]
];
