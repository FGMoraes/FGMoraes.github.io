var searchData=
[
  ['new_5ftask_2ec',['new_task.c',['../new__task_8c.html',1,'']]],
  ['new_5ftask_2eh',['new_task.h',['../new__task_8h.html',1,'']]]
];
