var searchData=
[
  ['cluster_5fload',['cluster_load',['../kernel__master_8c.html#a185005b5b4195a6fdd931138c65c6248',1,'kernel_master.c']]],
  ['cluster_5fmaster_5faddress',['cluster_master_address',['../kernel__slave_8c.html#aeddeab4580534cfc17b584198443cc37',1,'kernel_slave.c']]],
  ['clusterid',['clusterID',['../reclustering_8c.html#a14d398ecc6d6c334449c7469825bea55',1,'clusterID():&#160;reclustering.c'],['../reclustering_8h.html#a14d398ecc6d6c334449c7469825bea55',1,'clusterID():&#160;reclustering.c']]],
  ['code_5fsize',['code_size',['../structTask.html#ab3b5025fcd589be58a9a4670f950cd7c',1,'Task::code_size()'],['../structNewTask.html#ae3ecb38d4388a930d30d2b4436418902',1,'NewTask::code_size()'],['../structServiceHeader.html#a0f1b459ced066f8efab9ac77d2368c94',1,'ServiceHeader::code_size()']]],
  ['computation_5fload',['computation_load',['../structTask.html#a70ab30b38da4ffbd53bae71995db7b8b',1,'Task']]],
  ['consumer_5ftask',['consumer_task',['../structPipeSlot.html#a72830b924f73bb1027e191724fac40a6',1,'PipeSlot::consumer_task()'],['../structServiceHeader.html#a3f738c69b51a50d3746ea868be62ab9d',1,'ServiceHeader::consumer_task()']]],
  ['cpu_5futilization',['cpu_utilization',['../local__scheduler_8c.html#a11ed9dabd036cff1bf7ffbb53c7f5b40',1,'local_scheduler.c']]],
  ['current',['current',['../kernel__slave_8c.html#a323af42a6e37bb759a8c9cb128cd4137',1,'kernel_slave.c']]],
  ['current_5fborrowed_5fmaster',['current_borrowed_master',['../structReclustering.html#af600b9f65c9ca4203b8e7dcf30364a3e',1,'Reclustering']]],
  ['current_5fborrowed_5fproc',['current_borrowed_proc',['../structReclustering.html#ae8c94c587e3b39fd095d339705563575',1,'Reclustering']]]
];
