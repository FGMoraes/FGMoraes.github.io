var searchData=
[
  ['os_5fidle',['OS_Idle',['../kernel__slave_8c.html#a3de1cf12c47aeba777f187830146da81',1,'OS_Idle():&#160;kernel_slave.c'],['../kernel__slave_8h.html#a3de1cf12c47aeba777f187830146da81',1,'OS_Idle():&#160;kernel_slave.c']]],
  ['os_5finterruptmaskclear',['OS_InterruptMaskClear',['../kernel__slave_8c.html#abbfeb606c0964bd3d75b360bd3b5d1c9',1,'OS_InterruptMaskClear(unsigned int Mask):&#160;kernel_slave.c'],['../kernel__slave_8h.html#a8451e27fc3d64a78415f9b2637ccedae',1,'OS_InterruptMaskClear(unsigned int):&#160;kernel_slave.c']]],
  ['os_5finterruptmaskset',['OS_InterruptMaskSet',['../kernel__slave_8c.html#afc3482fa699b1cfb6404e353cbd8bbd1',1,'OS_InterruptMaskSet(unsigned int Mask):&#160;kernel_slave.c'],['../kernel__slave_8h.html#a68490843eaefa13c2602b9723ed900bf',1,'OS_InterruptMaskSet(unsigned int):&#160;kernel_slave.c']]],
  ['os_5finterruptserviceroutine',['OS_InterruptServiceRoutine',['../kernel__slave_8c.html#aaba7ce120b052968dc3a1d0e544cd4c0',1,'OS_InterruptServiceRoutine(unsigned int status):&#160;kernel_slave.c'],['../kernel__slave_8h.html#a7d5cf7391b921e1389fe6c89908c7c6c',1,'OS_InterruptServiceRoutine(unsigned int):&#160;kernel_slave.c']]]
];
