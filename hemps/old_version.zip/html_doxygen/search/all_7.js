var searchData=
[
  ['handle_5fapp_5frequest',['handle_app_request',['../kernel__master_8c.html#a2a57f264156f56fffb3aed5482aaefa4',1,'kernel_master.c']]],
  ['handle_5fapp_5fterminated',['handle_app_terminated',['../kernel__master_8c.html#a91d2b190a0d04e2f737e49783725d219',1,'kernel_master.c']]],
  ['handle_5fmigration',['handle_migration',['../task__migration_8c.html#ae24fb915374f10a59bb1ef97d3d86d5c',1,'handle_migration(volatile ServiceHeader *p, unsigned int master_address):&#160;task_migration.c'],['../task__migration_8h.html#acb875e0bb094be9384e9d95ae27a68aa',1,'handle_migration(volatile ServiceHeader *, unsigned int):&#160;task_migration.c']]],
  ['handle_5fmigration_5fcode',['handle_migration_code',['../task__migration_8c.html#a6d19f78e6c80892639d2bdcc71ee95bc',1,'task_migration.c']]],
  ['handle_5fmigration_5fdata_5fbss',['handle_migration_DATA_BSS',['../task__migration_8c.html#a76335771693c167e46941fefa7d77450',1,'task_migration.c']]],
  ['handle_5fmigration_5frequest_5fmsg',['handle_migration_request_msg',['../task__migration_8c.html#ac3a083b45b6290744916f125c547ed35',1,'task_migration.c']]],
  ['handle_5fmigration_5fstack',['handle_migration_stack',['../task__migration_8c.html#a8225883f47ca4c88f83827dc42d47829',1,'task_migration.c']]],
  ['handle_5fmigration_5ftask_5flocation',['handle_migration_task_location',['../task__migration_8c.html#a30788f395516c7d86939bcc1e3e14f61',1,'task_migration.c']]],
  ['handle_5fmigration_5ftcb',['handle_migration_TCB',['../task__migration_8c.html#abfdd9daeba03fe88654767bd63833fa0',1,'task_migration.c']]],
  ['handle_5fnew_5fapp',['handle_new_app',['../kernel__master_8c.html#a0ef02a91c1482c1acf49324363e93609',1,'handle_new_app(int app_ID, volatile unsigned int *ref_address, unsigned int app_descriptor_size):&#160;kernel_master.c'],['../kernel__master_8h.html#a037a1ae686b3821630b7d9906e48b36f',1,'handle_new_app(int, volatile unsigned int *, unsigned int):&#160;kernel_master.c']]],
  ['handle_5fpacket',['handle_packet',['../kernel__master_8c.html#a2b2417c04cae31d37ede19d44f4dd440',1,'handle_packet():&#160;kernel_master.c'],['../kernel__slave_8c.html#aaa145a01fcee7fd7a822f3590563a746',1,'handle_packet(volatile ServiceHeader *p):&#160;kernel_slave.c']]],
  ['handle_5fpending_5fapplication',['handle_pending_application',['../kernel__master_8c.html#a842eed07a104dde54f327cd6d61182a8',1,'kernel_master.c']]],
  ['handle_5freclustering',['handle_reclustering',['../reclustering_8c.html#a4c3cce245ce78b58712c40f286f2f49f',1,'handle_reclustering(ServiceHeader *p):&#160;reclustering.c'],['../reclustering_8h.html#ae339508b332c07a4eca526ba1d5fa022',1,'handle_reclustering(ServiceHeader *):&#160;reclustering.c']]],
  ['handle_5ftask_5fmigration',['handle_task_migration',['../task__migration_8c.html#ae5c85d447c2d8b07e69aab14605f87e3',1,'task_migration.c']]],
  ['header',['header',['../structServiceHeader.html#aa266af26620897bf3271d016334499ed',1,'ServiceHeader']]]
];
