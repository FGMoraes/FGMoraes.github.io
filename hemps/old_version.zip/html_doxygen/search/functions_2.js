var searchData=
[
  ['dmni_5fread_5fdata',['DMNI_read_data',['../packet_8c.html#a078315ec58ca290e6c8465b1c0359981',1,'DMNI_read_data(unsigned int initial_address, unsigned int dmni_msg_size):&#160;packet.c'],['../packet_8h.html#a738fa18be17dfbdcff77f843cae28d8e',1,'DMNI_read_data(unsigned int, unsigned int):&#160;packet.c']]],
  ['dmni_5fsend_5fdata',['DMNI_send_data',['../packet_8c.html#ad666e30270ae79df6acd7f9e4fb84c5a',1,'DMNI_send_data(unsigned int initial_address, unsigned int dmni_msg_size):&#160;packet.c'],['../packet_8h.html#a39981b9b53c4d7e620d0d04a19a61de6',1,'DMNI_send_data(unsigned int, unsigned int):&#160;packet.c']]],
  ['dynamic_5fslice_5ftime',['dynamic_slice_time',['../local__scheduler_8c.html#a0889a4149aeba940d2a87bdc97805e6f',1,'local_scheduler.c']]]
];
