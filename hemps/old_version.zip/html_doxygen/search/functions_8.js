var searchData=
[
  ['map_5ftask',['map_task',['../cluster__scheduler_8c.html#a105eb9429b66c2c581c5eafdfea90f77',1,'map_task(int task_id):&#160;cluster_scheduler.c'],['../cluster__scheduler_8h.html#a6f45aaf4d66fb32d71a9bdf9d7517a67',1,'map_task(int):&#160;cluster_scheduler.c']]],
  ['migrate_5fcode',['migrate_CODE',['../task__migration_8c.html#a389fbb88879c82266726df3ac0655f71',1,'task_migration.c']]],
  ['migrate_5fdynamic_5fmemory',['migrate_dynamic_memory',['../task__migration_8c.html#aff185d2bff2f7d38fdf16243544a48de',1,'migrate_dynamic_memory(TCB *tcb_aux):&#160;task_migration.c'],['../task__migration_8h.html#a62634155d2ec5a78c89bd40bdd3363f5',1,'migrate_dynamic_memory(TCB *):&#160;task_migration.c']]]
];
