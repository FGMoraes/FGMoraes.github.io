var searchData=
[
  ['active',['active',['../structReclustering.html#a6472d9555c76fc079f47dab8808f64e9',1,'Reclustering']]],
  ['add_5ffifo',['add_fifo',['../pending__service_8c.html#a91163b0b78e8ae0104f61b3ae9f63512',1,'pending_service.c']]],
  ['address',['address',['../structProcessor.html#ab488b5789f3ce60a21fd3bf01c2fa109',1,'Processor']]],
  ['allocated_5fproc',['allocated_proc',['../structTask.html#a6aa4b8399b4d3216080cf3abb3796eda',1,'Task']]],
  ['allocated_5fprocessor',['allocated_processor',['../structNewTask.html#a945733d3e8bbb7e5657d97c6be5b47b3',1,'NewTask']]],
  ['app_5fid',['app_ID',['../structApplication.html#ac085c06443540cb5131b66f64d54e077',1,'Application']]],
  ['applications',['applications',['../applications_8c.html#a6ccfbf18604bfbd47ef9f4c4f0eb9eb7',1,'applications.c']]]
];
