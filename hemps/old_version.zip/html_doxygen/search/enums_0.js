var searchData=
[
  ['pipeslotstatus',['PipeSlotStatus',['../communication_8h.html#a6c3e2f426b3d6cdd779e3a1a5d5bca09',1,'communication.h']]]
];
