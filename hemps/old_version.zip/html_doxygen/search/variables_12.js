var searchData=
[
  ['waiting_5fapp_5fallocation',['waiting_app_allocation',['../kernel__master_8c.html#a867ba5de5242a5c8869bba30d97bc4cd',1,'kernel_master.c']]]
];
