var searchData=
[
  ['data_5flenght',['data_lenght',['../structTCB.html#a3f246604f26d4db72c31f60e7e8b2e4f',1,'TCB']]],
  ['data_5fsize',['data_size',['../structTask.html#ad018b6d77222855d82346200cb6749c2',1,'Task']]],
  ['deadline',['deadline',['../structScheduling.html#a3e8d79850b57ac6e24e1427ec4a1c76b',1,'Scheduling']]],
  ['debug',['DEBUG',['../local__scheduler_8h.html#ad72dbcf6d0153db1b8d8a58001feed83',1,'local_scheduler.h']]],
  ['dependence',['Dependence',['../structDependence.html',1,'']]],
  ['dependences',['dependences',['../structTask.html#a565ed150f87d0da544aaf13f1cd6b67a',1,'Task']]],
  ['dependences_5fnumber',['dependences_number',['../structTask.html#afa22a03cee182093959578114954ae4f',1,'Task']]],
  ['dmni_5fread_5fdata',['DMNI_read_data',['../packet_8c.html#a078315ec58ca290e6c8465b1c0359981',1,'DMNI_read_data(unsigned int initial_address, unsigned int dmni_msg_size):&#160;packet.c'],['../packet_8h.html#a738fa18be17dfbdcff77f843cae28d8e',1,'DMNI_read_data(unsigned int, unsigned int):&#160;packet.c']]],
  ['dmni_5fsend_5fdata',['DMNI_send_data',['../packet_8c.html#ad666e30270ae79df6acd7f9e4fb84c5a',1,'DMNI_send_data(unsigned int initial_address, unsigned int dmni_msg_size):&#160;packet.c'],['../packet_8h.html#a39981b9b53c4d7e620d0d04a19a61de6',1,'DMNI_send_data(unsigned int, unsigned int):&#160;packet.c']]],
  ['dynamic_5fslice_5ftime',['dynamic_slice_time',['../local__scheduler_8c.html#a0889a4149aeba940d2a87bdc97805e6f',1,'local_scheduler.c']]]
];
