var searchData=
[
  ['neighbors_5flevel',['neighbors_level',['../structReclustering.html#abaac2962690bf6746558fa7a491b153c',1,'Reclustering']]],
  ['net_5faddress',['net_address',['../kernel__slave_8c.html#a04fef1c59ccb2602b2902620d50ac931',1,'kernel_slave.c']]],
  ['new_5ftask_5flist',['new_task_list',['../new__task_8c.html#a4c39e0aac4d994e731c2eaff819828e5',1,'new_task.c']]]
];
