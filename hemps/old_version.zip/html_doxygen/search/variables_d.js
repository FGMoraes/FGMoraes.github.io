var searchData=
[
  ['payload_5fsize',['payload_size',['../structServiceHeader.html#a8d5ceba42e691e12b2828baed6b1c16f',1,'ServiceHeader']]],
  ['pc',['pc',['../structTCB.html#ab34c59cc1d5c871da68aadf78091cc2f',1,'TCB']]],
  ['pending_5fapp_5fto_5fmap',['pending_app_to_map',['../kernel__master_8c.html#a1a3196da5ed028756f53730e45c4774a',1,'kernel_master.c']]],
  ['pending_5floan_5fdelivery',['pending_loan_delivery',['../structReclustering.html#a0f89bf6ecbc3cafc5b8b1e4128d2903e',1,'Reclustering']]],
  ['pending_5fservice_5ffirst',['pending_service_first',['../pending__service_8c.html#a3e2691e2b224780c868a2a0ae0319623',1,'pending_service.c']]],
  ['pending_5fservice_5flast',['pending_service_last',['../pending__service_8c.html#a3af88a17469948d2b4b67db34c6d2d71',1,'pending_service.c']]],
  ['pending_5fservices_5ffifo',['pending_services_FIFO',['../pending__service_8c.html#ae3174a73de91f5f836b18877fa4cee1a',1,'pending_service.c']]],
  ['period',['period',['../structScheduling.html#aec637570080f3d645dd3b917e0fed06a',1,'Scheduling']]],
  ['pipe',['pipe',['../communication_8c.html#a76dea9c1dcc6f5118f0f366066913369',1,'communication.c']]],
  ['pipe_5ffree_5fpositions',['pipe_free_positions',['../communication_8c.html#a07ba9cd9231ff3f458f1b8c644b4055a',1,'communication.c']]],
  ['pkt_5fsize',['pkt_size',['../structServiceHeader.html#a4b5e8eb631f3876147a30fb8866296c6',1,'ServiceHeader']]],
  ['proc_5faddress',['proc_address',['../structTaskLocaion.html#a5f1589f12838885e6d5b13011699aec9',1,'TaskLocaion']]],
  ['proc_5fto_5fmigrate',['proc_to_migrate',['../structTCB.html#a97b8e26f7b08bb7c5da493f0dc691701',1,'TCB']]],
  ['processors',['processors',['../processors_8c.html#acd8ab4e9c5356696afabf2f095d4e904',1,'processors.c']]],
  ['producer_5ftask',['producer_task',['../structPipeSlot.html#a40cc5a83d7c1f3357297cc75da93f0d2',1,'PipeSlot::producer_task()'],['../structServiceHeader.html#a29037e65b8d3316605164601578a4179',1,'ServiceHeader::producer_task()']]]
];
