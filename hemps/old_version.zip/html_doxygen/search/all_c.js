var searchData=
[
  ['neighbors_5flevel',['neighbors_level',['../structReclustering.html#abaac2962690bf6746558fa7a491b153c',1,'Reclustering']]],
  ['net_5faddress',['net_address',['../kernel__slave_8c.html#a04fef1c59ccb2602b2902620d50ac931',1,'kernel_slave.c']]],
  ['new_5ftask_2ec',['new_task.c',['../new__task_8c.html',1,'']]],
  ['new_5ftask_2eh',['new_task.h',['../new__task_8h.html',1,'']]],
  ['new_5ftask_5flist',['new_task_list',['../new__task_8c.html#a4c39e0aac4d994e731c2eaff819828e5',1,'new_task.c']]],
  ['newtask',['NewTask',['../structNewTask.html',1,'']]],
  ['no_5fdeadline',['NO_DEADLINE',['../local__scheduler_8h.html#abad70bd3210c32cb69ac55061e16ae42',1,'local_scheduler.h']]],
  ['noc_5finterruption',['noc_interruption',['../kernel__master_8h.html#adc4c54b04aa9355cb7f41f53858d5a13',1,'kernel_master.h']]]
];
