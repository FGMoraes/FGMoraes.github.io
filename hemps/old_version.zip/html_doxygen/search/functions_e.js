var searchData=
[
  ['write_5flocal_5fmsg_5fto_5ftask',['write_local_msg_to_task',['../kernel__slave_8c.html#a959e19d6dcf39cf00062626d436a4a30',1,'kernel_slave.c']]]
];
