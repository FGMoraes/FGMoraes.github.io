var searchData=
[
  ['update_5fproc_5fslack_5ftime',['update_proc_slack_time',['../processors_8c.html#a5cb21df0ef57b958353108fee576d2b6',1,'update_proc_slack_time(int proc_address, int slack_time):&#160;processors.c'],['../processors_8h.html#ae6b50047e879d42fe32b740eaa022d4a',1,'update_proc_slack_time(int, int):&#160;processors.c']]],
  ['update_5freal_5ftime',['update_real_time',['../local__scheduler_8c.html#a376780341c3bcff63f1dca124e5ed9e1',1,'local_scheduler.c']]],
  ['update_5fslack_5ftime',['update_slack_time',['../local__scheduler_8c.html#a77e445eb92be23e3b867df9b958b1aa0',1,'local_scheduler.c']]]
];
