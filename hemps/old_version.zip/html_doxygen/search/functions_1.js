var searchData=
[
  ['clear_5fapp_5ftasks_5flocations',['clear_app_tasks_locations',['../task__location_8c.html#a9e1007b2ae2d78e3a70b961ef86990fb',1,'clear_app_tasks_locations(int app_ID):&#160;task_location.c'],['../task__location_8h.html#a0b3fcac5cf0f89d3f2bb44ceee94d444',1,'clear_app_tasks_locations(int):&#160;task_location.c']]],
  ['clear_5fscheduling',['clear_scheduling',['../local__scheduler_8c.html#a499313d0331fdffe688bc926f7a95b03',1,'clear_scheduling(Scheduling *scheduling_tcb):&#160;local_scheduler.c'],['../local__scheduler_8h.html#a664e47f55da2255ec0bde22be781f2d9',1,'clear_scheduling(Scheduling *):&#160;local_scheduler.c']]]
];
