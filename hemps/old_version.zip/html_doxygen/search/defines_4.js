var searchData=
[
  ['external_5fapp_5freg',['external_app_reg',['../kernel__master_8h.html#a6d6ba7a9832105a5d3b08f7808e38fa0',1,'kernel_master.h']]]
];
