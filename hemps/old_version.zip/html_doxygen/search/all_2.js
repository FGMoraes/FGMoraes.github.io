var searchData=
[
  ['clear_5fapp_5ftasks_5flocations',['clear_app_tasks_locations',['../task__location_8c.html#a9e1007b2ae2d78e3a70b961ef86990fb',1,'clear_app_tasks_locations(int app_ID):&#160;task_location.c'],['../task__location_8h.html#a0b3fcac5cf0f89d3f2bb44ceee94d444',1,'clear_app_tasks_locations(int):&#160;task_location.c']]],
  ['clear_5fscheduling',['clear_scheduling',['../local__scheduler_8c.html#a499313d0331fdffe688bc926f7a95b03',1,'clear_scheduling(Scheduling *scheduling_tcb):&#160;local_scheduler.c'],['../local__scheduler_8h.html#a664e47f55da2255ec0bde22be781f2d9',1,'clear_scheduling(Scheduling *):&#160;local_scheduler.c']]],
  ['cluster_5fload',['cluster_load',['../kernel__master_8c.html#a185005b5b4195a6fdd931138c65c6248',1,'kernel_master.c']]],
  ['cluster_5fmaster_5faddress',['cluster_master_address',['../kernel__slave_8c.html#aeddeab4580534cfc17b584198443cc37',1,'kernel_slave.c']]],
  ['cluster_5fscheduler_2ec',['cluster_scheduler.c',['../cluster__scheduler_8c.html',1,'']]],
  ['cluster_5fscheduler_2eh',['cluster_scheduler.h',['../cluster__scheduler_8h.html',1,'']]],
  ['clusterid',['clusterID',['../reclustering_8c.html#a14d398ecc6d6c334449c7469825bea55',1,'clusterID():&#160;reclustering.c'],['../reclustering_8h.html#a14d398ecc6d6c334449c7469825bea55',1,'clusterID():&#160;reclustering.c']]],
  ['code_5fsize',['code_size',['../structTask.html#ab3b5025fcd589be58a9a4670f950cd7c',1,'Task::code_size()'],['../structNewTask.html#ae3ecb38d4388a930d30d2b4436418902',1,'NewTask::code_size()'],['../structServiceHeader.html#a0f1b459ced066f8efab9ac77d2368c94',1,'ServiceHeader::code_size()']]],
  ['communication_2ec',['communication.c',['../communication_8c.html',1,'']]],
  ['communication_2eh',['communication.h',['../communication_8h.html',1,'']]],
  ['computation_5fload',['computation_load',['../structTask.html#a70ab30b38da4ffbd53bae71995db7b8b',1,'Task']]],
  ['constant_5fpkt_5fsize',['CONSTANT_PKT_SIZE',['../packet_8h.html#acaf743f1db9063f3e7556f6ad46f0f76',1,'packet.h']]],
  ['consumer_5ftask',['consumer_task',['../structPipeSlot.html#a72830b924f73bb1027e191724fac40a6',1,'PipeSlot::consumer_task()'],['../structServiceHeader.html#a3f738c69b51a50d3746ea868be62ab9d',1,'ServiceHeader::consumer_task()']]],
  ['cpu_5futilization',['cpu_utilization',['../local__scheduler_8c.html#a11ed9dabd036cff1bf7ffbb53c7f5b40',1,'local_scheduler.c']]],
  ['current',['current',['../kernel__slave_8c.html#a323af42a6e37bb759a8c9cb128cd4137',1,'kernel_slave.c']]],
  ['current_5fborrowed_5fmaster',['current_borrowed_master',['../structReclustering.html#af600b9f65c9ca4203b8e7dcf30364a3e',1,'Reclustering']]],
  ['current_5fborrowed_5fproc',['current_borrowed_proc',['../structReclustering.html#ae8c94c587e3b39fd095d339705563575',1,'Reclustering']]]
];
