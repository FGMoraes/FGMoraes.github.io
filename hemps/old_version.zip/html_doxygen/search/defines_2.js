var searchData=
[
  ['constant_5fpkt_5fsize',['CONSTANT_PKT_SIZE',['../packet_8h.html#acaf743f1db9063f3e7556f6ad46f0f76',1,'packet.h']]]
];
