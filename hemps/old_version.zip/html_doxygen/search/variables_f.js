var searchData=
[
  ['schedule_5fafter_5fsyscall',['schedule_after_syscall',['../kernel__slave_8c.html#ad8ae03a539dab5e8354d8b496aef7a0b',1,'kernel_slave.c']]],
  ['schedule_5foverhead',['schedule_overhead',['../local__scheduler_8c.html#a0e519d91d8258e3ff7a057beee450e1d',1,'local_scheduler.c']]],
  ['scheduling',['scheduling',['../local__scheduler_8c.html#a553a924acc3bc3dfcff14e719103a8e2',1,'local_scheduler.c']]],
  ['scheduling_5fptr',['scheduling_ptr',['../structTCB.html#ac377ba0e10960324cc7922b9ed4163a5',1,'TCB']]],
  ['service',['service',['../structServiceHeader.html#af72ebfaf14c07a3951b5b28b1ea36315',1,'ServiceHeader']]],
  ['sh_5fslot2',['sh_slot2',['../packet_8c.html#a4c9cba2b8b7ed0ff32fd246d4ae6ada7',1,'packet.c']]],
  ['slack_5ftime',['slack_time',['../structScheduling.html#a36af5aa033031e3d32ec5bf8b76c3bae',1,'Scheduling::slack_time()'],['../structProcessor.html#a8ff929f5b3cd939e32f977891d21b2ef',1,'Processor::slack_time()']]],
  ['source_5fpe',['source_PE',['../structServiceHeader.html#a437dd60b39e8120943862fa1735ea3da',1,'ServiceHeader']]],
  ['starting_5fx_5fcluster_5fsize',['starting_x_cluster_size',['../reclustering_8c.html#ab8d21bdd758e447c4f8fd9193ed0ea97',1,'reclustering.c']]],
  ['starting_5fy_5fcluster_5fsize',['starting_y_cluster_size',['../reclustering_8c.html#a28215b4708de2c310c0e5965b18078ee',1,'reclustering.c']]],
  ['status',['status',['../structTask.html#af3c9b00f6ffaef332b5cff52592e88fd',1,'Task::status()'],['../structApplication.html#adbb5d4d9d9f8c15ddc9b468253a88364',1,'Application::status()'],['../structPipeSlot.html#a092ad83f49d4f6929fb3ca75b39ccc2e',1,'PipeSlot::status()'],['../structScheduling.html#acc10c85497f9f7433e39e094b518f19e',1,'Scheduling::status()']]]
];
