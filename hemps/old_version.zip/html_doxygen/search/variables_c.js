var searchData=
[
  ['offset',['offset',['../structTCB.html#aee19caebb78939bf33eeda5db61cf3f0',1,'TCB']]],
  ['order',['order',['../structPipeSlot.html#afd89b3b7b4a9f196781cc5ae3141ea86',1,'PipeSlot']]]
];
