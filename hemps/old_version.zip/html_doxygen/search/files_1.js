var searchData=
[
  ['cluster_5fscheduler_2ec',['cluster_scheduler.c',['../cluster__scheduler_8c.html',1,'']]],
  ['cluster_5fscheduler_2eh',['cluster_scheduler.h',['../cluster__scheduler_8h.html',1,'']]],
  ['communication_2ec',['communication.c',['../communication_8c.html',1,'']]],
  ['communication_2eh',['communication.h',['../communication_8h.html',1,'']]]
];
