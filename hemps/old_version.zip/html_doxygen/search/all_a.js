var searchData=
[
  ['last',['last',['../new__task_8c.html#ab0b853bc4e4e9658036bf7e604f398ad',1,'new_task.c']]],
  ['last_5fidle_5ftime',['last_idle_time',['../kernel__slave_8c.html#adb15335763f14fa38786b1afd7b0598f',1,'kernel_slave.c']]],
  ['local_5fscheduler_2ec',['local_scheduler.c',['../local__scheduler_8c.html',1,'']]],
  ['local_5fscheduler_2eh',['local_scheduler.h',['../local__scheduler_8h.html',1,'']]],
  ['lst',['LST',['../local__scheduler_8c.html#a2ef099309505d58a0bd13193564a4ea4',1,'LST(unsigned int current_time):&#160;local_scheduler.c'],['../local__scheduler_8h.html#a3cbd190a811c0e8e784700c0df4a378e',1,'LST(unsigned int):&#160;local_scheduler.c']]]
];
