var searchData=
[
  ['free',['FREE',['../applications_8h.html#a9a8e700d56e7d858108b755ad3edb52e',1,'FREE():&#160;applications.h'],['../local__scheduler_8h.html#a9a8e700d56e7d858108b755ad3edb52e',1,'FREE():&#160;local_scheduler.h']]]
];
