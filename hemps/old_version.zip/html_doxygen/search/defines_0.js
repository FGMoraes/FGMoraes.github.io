var searchData=
[
  ['allocated',['ALLOCATED',['../applications_8h.html#aaa0db48d5bc1e51c3fde24e3b8ade641',1,'applications.h']]],
  ['app_5freq_5freg',['app_req_reg',['../kernel__master_8h.html#a82aa102b0980beac8fffff385e5fed15',1,'kernel_master.h']]]
];
