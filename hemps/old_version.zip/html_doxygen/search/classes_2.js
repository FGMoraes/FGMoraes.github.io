var searchData=
[
  ['message',['Message',['../structMessage.html',1,'']]],
  ['messagerequest',['MessageRequest',['../structMessageRequest.html',1,'']]]
];
