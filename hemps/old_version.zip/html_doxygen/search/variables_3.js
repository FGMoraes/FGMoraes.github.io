var searchData=
[
  ['data_5flenght',['data_lenght',['../structTCB.html#a3f246604f26d4db72c31f60e7e8b2e4f',1,'TCB']]],
  ['data_5fsize',['data_size',['../structTask.html#ad018b6d77222855d82346200cb6749c2',1,'Task']]],
  ['deadline',['deadline',['../structScheduling.html#a3e8d79850b57ac6e24e1427ec4a1c76b',1,'Scheduling']]],
  ['dependences',['dependences',['../structTask.html#a565ed150f87d0da544aaf13f1cd6b67a',1,'Task']]],
  ['dependences_5fnumber',['dependences_number',['../structTask.html#afa22a03cee182093959578114954ae4f',1,'Task']]]
];
