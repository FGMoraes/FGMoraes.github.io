var searchData=
[
  ['task_5fdescriptor_5fsize',['TASK_DESCRIPTOR_SIZE',['../kernel__master_8h.html#adcd8754824f790f3cea21d53b84c53dd',1,'kernel_master.h']]],
  ['task_5fmigration_5fdebug',['TASK_MIGRATION_DEBUG',['../task__migration_8c.html#a7acd186c1a2d4977d5557ca12bb79f57',1,'task_migration.c']]],
  ['task_5frunning',['TASK_RUNNING',['../applications_8h.html#a17e3f99a030e5dfefb8f9815600e3fed',1,'applications.h']]],
  ['terminated_5ftask',['TERMINATED_TASK',['../applications_8h.html#ab28aed42cc67b68f42d997f978fdbd83',1,'applications.h']]]
];
