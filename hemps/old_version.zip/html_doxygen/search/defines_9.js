var searchData=
[
  ['ready',['READY',['../local__scheduler_8h.html#ad1235d5ce36f7267285e82dccd428aa6',1,'local_scheduler.h']]],
  ['ready_5fto_5fload',['READY_TO_LOAD',['../applications_8h.html#ad5f87c7f5069ee8d52ca95dcabbb379e',1,'applications.h']]],
  ['reclustering_5fdebug',['RECLUSTERING_DEBUG',['../reclustering_8c.html#a9b92e3c096343c21b7afd2ca770ce58e',1,'reclustering.c']]],
  ['requested',['REQUESTED',['../applications_8h.html#a8d327616b24831c981d529c58cb7736a',1,'applications.h']]],
  ['running',['RUNNING',['../applications_8h.html#a6fb7181d994ee98e735494be55809708',1,'RUNNING():&#160;applications.h'],['../local__scheduler_8h.html#a6fb7181d994ee98e735494be55809708',1,'RUNNING():&#160;local_scheduler.h']]]
];
