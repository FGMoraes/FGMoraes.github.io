var searchData=
[
  ['ready_5ftime',['ready_time',['../structScheduling.html#afec2122f8b01ee912fcd73af664aaf9f',1,'Scheduling']]],
  ['reclustering',['reclustering',['../reclustering_8c.html#aeff8191311b73d0bc4e73aec7212c373',1,'reclustering.c']]],
  ['reg',['reg',['../structTCB.html#aa10b776b23d7f5586240f7b1113dfe38',1,'TCB']]],
  ['remaining_5fexec_5ftime',['remaining_exec_time',['../structScheduling.html#acd2650d3cc08cc1145d9fee578d07452',1,'Scheduling']]],
  ['requested',['requested',['../structMessageRequest.html#a6bc4af5c822e64f51e62ae148a8f3964',1,'MessageRequest']]],
  ['requester',['requester',['../structMessageRequest.html#ab0572c912ed62f68a2ff0a0d937b4883',1,'MessageRequest']]],
  ['requester_5fproc',['requester_proc',['../structMessageRequest.html#a3b98038dda5707c7d9532bd7e2b431f2',1,'MessageRequest']]],
  ['running_5fstart_5ftime',['running_start_time',['../structScheduling.html#a9abdf43fbd575dafab54970605529815',1,'Scheduling']]]
];
