var searchData=
[
  ['fires_5freclustering_5fprotocol',['fires_reclustering_protocol',['../reclustering_8c.html#a238833ad11e424e93e279cc6f1852264',1,'reclustering.c']]],
  ['first',['first',['../new__task_8c.html#a2392eca2ce03c1584a56722daa3c5ca6',1,'new_task.c']]],
  ['flits',['flits',['../structDependence.html#aaa418748e69b6c83628ec85fede957a7',1,'Dependence']]],
  ['free',['FREE',['../applications_8h.html#a9a8e700d56e7d858108b755ad3edb52e',1,'FREE():&#160;applications.h'],['../local__scheduler_8h.html#a9a8e700d56e7d858108b755ad3edb52e',1,'FREE():&#160;local_scheduler.h']]],
  ['free_5fpages',['free_pages',['../structProcessor.html#a120bb091e599886bf31912d41a30efb0',1,'Processor']]]
];
