var searchData=
[
  ['id',['id',['../structTask.html#a1bdc8139dd647f9701e9f43e588749d7',1,'Task::id()'],['../structTCB.html#a453409a559526647015e8ed1ed3da06a',1,'TCB::id()'],['../structTaskLocaion.html#a3801f580033ab31b632dcbdaa142d2dc',1,'TaskLocaion::id()']]],
  ['idle_5ftcb',['idle_tcb',['../kernel__slave_8c.html#ac695e7fe3cd710abda602d3917476290',1,'kernel_slave.c']]],
  ['initial_5faddress',['initial_address',['../structTask.html#a77794948646e047b0d12398ad06e359d',1,'Task::initial_address()'],['../structNewTask.html#abdf33a7e2ce2cdfdeb6bd4d60f34da30',1,'NewTask::initial_address()'],['../structServiceHeader.html#a80920badc0391e5f821b21d8ef0bc242',1,'ServiceHeader::initial_address()']]],
  ['instant_5foverhead',['instant_overhead',['../local__scheduler_8c.html#ad75fb999de49939d2849b1b8f05d35ec',1,'local_scheduler.c']]],
  ['is_5fglobal_5fmaster',['is_global_master',['../kernel__master_8c.html#a3da9c356a52f90cf1d738be4073f71fb',1,'kernel_master.c']]]
];
