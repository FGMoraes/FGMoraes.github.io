var searchData=
[
  ['newtask',['NewTask',['../structNewTask.html',1,'']]]
];
