var searchData=
[
  ['last',['last',['../new__task_8c.html#ab0b853bc4e4e9658036bf7e604f398ad',1,'new_task.c']]],
  ['last_5fidle_5ftime',['last_idle_time',['../kernel__slave_8c.html#adb15335763f14fa38786b1afd7b0598f',1,'kernel_slave.c']]]
];
