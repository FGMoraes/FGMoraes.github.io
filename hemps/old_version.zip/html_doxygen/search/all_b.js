var searchData=
[
  ['map_5ftask',['map_task',['../cluster__scheduler_8c.html#a105eb9429b66c2c581c5eafdfea90f77',1,'map_task(int task_id):&#160;cluster_scheduler.c'],['../cluster__scheduler_8h.html#a6f45aaf4d66fb32d71a9bdf9d7517a67',1,'map_task(int):&#160;cluster_scheduler.c']]],
  ['master_5faddress',['master_address',['../structTCB.html#ae3222a6215294bbc81ffea87844ac590',1,'TCB']]],
  ['master_5fid',['master_ID',['../structNewTask.html#ae810fa48c954695ef5fa77e72d0f519f',1,'NewTask']]],
  ['max_5fglobal_5ftasks',['MAX_GLOBAL_TASKS',['../new__task_8h.html#aaf8b707bc5b7ab968461559445bc4608',1,'new_task.h']]],
  ['max_5fneighbors_5flevel',['max_neighbors_level',['../reclustering_8c.html#a7e63c726de12ed9662da34d0874b0b2b',1,'reclustering.c']]],
  ['max_5ftask_5fdependeces',['MAX_TASK_DEPENDECES',['../applications_8h.html#a3b2fb4575c7e452065f793351b576248',1,'applications.h']]],
  ['max_5ftask_5fslots',['MAX_TASK_SLOTS',['../communication_8h.html#a75cf53b6be6b24c6910d483b189c0e5f',1,'communication.h']]],
  ['max_5ftime_5fslice',['MAX_TIME_SLICE',['../local__scheduler_8h.html#a7a8524d52a91ba1841e95f6d4f0dcd6b',1,'local_scheduler.h']]],
  ['message',['Message',['../structMessage.html',1,'Message'],['../structPipeSlot.html#aa64fba54f099ce4b36651ed7de0c967a',1,'PipeSlot::message()']]],
  ['message_5frequest',['message_request',['../communication_8c.html#a1a8c4d25bc4160a2c3a6f291e65e54e1',1,'communication.c']]],
  ['messagerequest',['MessageRequest',['../structMessageRequest.html',1,'']]],
  ['migrate_5fcode',['migrate_CODE',['../task__migration_8c.html#a389fbb88879c82266726df3ac0655f71',1,'task_migration.c']]],
  ['migrate_5fdynamic_5fmemory',['migrate_dynamic_memory',['../task__migration_8c.html#aff185d2bff2f7d38fdf16243544a48de',1,'migrate_dynamic_memory(TCB *tcb_aux):&#160;task_migration.c'],['../task__migration_8h.html#a62634155d2ec5a78c89bd40bdd3363f5',1,'migrate_dynamic_memory(TCB *):&#160;task_migration.c']]],
  ['migrating',['MIGRATING',['../applications_8h.html#ad6c6d97469a102841e8a13b8d627611e',1,'MIGRATING():&#160;applications.h'],['../local__scheduler_8h.html#ad6c6d97469a102841e8a13b8d627611e',1,'MIGRATING():&#160;local_scheduler.h']]],
  ['migration_5fenabled',['MIGRATION_ENABLED',['../kernel__slave_8h.html#a9c58b7c980993976443e4cf591925713',1,'kernel_slave.h']]],
  ['min_5floan_5fproc_5fhops',['min_loan_proc_hops',['../structReclustering.html#aec1565caa47c09eb41997cf8402952ce',1,'Reclustering']]],
  ['msg_5flenght',['msg_lenght',['../structServiceHeader.html#ab76cc88a37a56d3ef4fc1f25a3efd782',1,'ServiceHeader']]],
  ['msg_5fwrite_5fpipe',['msg_write_pipe',['../kernel__slave_8c.html#a64272255f5bd2e1bd4ebcce94afcd0a0',1,'kernel_slave.c']]]
];
