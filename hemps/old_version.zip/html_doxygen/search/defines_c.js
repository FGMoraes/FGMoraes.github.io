var searchData=
[
  ['waiting',['WAITING',['../local__scheduler_8h.html#a13ee57d95da6b6509d43bb1b3f67bb02',1,'local_scheduler.h']]],
  ['waiting_5freclustering',['WAITING_RECLUSTERING',['../applications_8h.html#acc9f56c8e85540aea5fc907529e4433a',1,'applications.h']]]
];
