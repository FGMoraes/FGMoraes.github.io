// =============================================================
// Módulo controlador:  prioridade + decodificador_semaforo
//
// Entradas: sensor_ns, sensor_lo, modo[1:0]
// Saídas:   nsLD[2:0], loLD[2:0], som
//
// =============================================================

module controlador (
    
 
);
  

endmodule


