if {[file isdirectory work]} { vdel -all -lib work }
vlib work
vmap work work

vlog -work work calc.sv tb_calc.sv

vsim -voptargs=+acc=lprn -t ns work.tb

do wave.do

run 800 ns

