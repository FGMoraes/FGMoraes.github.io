// --------------------------------------------
//  Calculadora Pilha  27/maio/2026 - Moraes
// --------------------------------------------

// Package  --------------------------------------
package p_ula;
    typedef enum logic [3:0] {
        uAND, uOR, uXOR, uADD, uSUB, uINC, uNEG, uDEC, uCLEAR, uLOAD, uCPX, uUP, uXY
    } op_alu;
endpackage

// Calculadora--------------------------------------
module calculadora (
    input  logic          clock,reset,
    input  p_ula::op_alu  opmode,
    input  logic [7:0]    din,
    output logic [7:0]    saida,
    output logic          z
);
    import p_ula::*;

    logic [7:0] regX, regY, regZ, regT, outalu;

    assign saida = <completar>;
    assign z     = <completar>;  

    // ----------------------------------
    // ALU
    // ----------------------------------
    always_comb begin
        unique case (opmode)
            uAND:   outalu = <completar>;
            uOR:    outalu = <completar>;
             ....
            uNEG:   outalu = <completar>;;
            default: outalu = 0;   // uCLEAR: default
        endcase
    end

    // ----------------------------------
    // Registers
    // ----------------------------------
    always_ff @(posedge clock or posedge reset) begin
        if (reset) begin
            regX <= '0;
            regY <= '0;
            regZ <= '0;
            regT <= '0;
        end else begin
            unique case (opmode)

                // Operations that affect only register X
                uINC, uDEC, uNEG, uCLEAR: begin
                    regX <= outalu;
                end

               <completar>;

            endcase
        end
    end

endmodule