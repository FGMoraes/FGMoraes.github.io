onerror {resume}
quietly WaveActivateNextPane {} 0
add wave -noupdate /tb/DUT/reset
add wave -noupdate /tb/DUT/clock
add wave -noupdate /tb/DUT/opmode
add wave -noupdate -radix hexadecimal /tb/DUT/din
add wave -noupdate -divider registradores
add wave -noupdate -color violet -radix hexadecimal /tb/DUT/regX
add wave -noupdate -color violet -radix hexadecimal /tb/DUT/regY
add wave -noupdate -color violet -radix hexadecimal /tb/DUT/regZ
add wave -noupdate -color violet -radix hexadecimal /tb/DUT/regT
add wave -noupdate -divider Saidas
add wave -noupdate -radix hexadecimal /tb/DUT/saida
add wave -noupdate /tb/DUT/z
TreeUpdate [SetDefaultTree]
WaveRestoreCursors {{Cursor 1} {59 ns} 0}
quietly wave cursor active 1
configure wave -namecolwidth 150
configure wave -valuecolwidth 100
configure wave -justifyvalue left
configure wave -signalnamewidth 1
configure wave -snapdistance 10
configure wave -datasetprefix 0
configure wave -rowmargin 4
configure wave -childrowmargin 2
configure wave -gridoffset 0
configure wave -gridperiod 1
configure wave -griddelta 40
configure wave -timeline 0
configure wave -timelineunits ns
update
WaveRestoreZoom {30 ns} {90 ns}
