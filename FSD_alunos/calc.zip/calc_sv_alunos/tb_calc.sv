// --------------------------------------------
// Testbench da Calcularado Pilha  27/maio/2026
// --------------------------------------------
module tb;

    import p_ula::*;

    logic        reset;
    logic        clock = 1'b0;
    logic        z;
    logic [7:0]  din;
    logic [7:0]  saida;
    op_alu       opmode;


    typedef struct packed {
        op_alu      op;
        logic [7:0] ent;
    } test_record_t;

    // programa de teste
    const test_record_t teste_pr[] = '{
        '{op: uLOAD,  ent: 8'hE9},
        '{op: uLOAD,  ent: 8'h24},
        '{op: uLOAD,  ent: 8'h3F},
        '{op: uLOAD,  ent: 8'h45},
        '{op: uADD,   ent: 8'h00},
        '{op: uDEC,   ent: 8'h00},
        '{op: uNEG,   ent: 8'h00},
        '{op: uXY,    ent: 8'h00},
        '{op: uCPX,   ent: 8'h00},
        '{op: uADD,   ent: 8'h00},
        '{op: uADD,   ent: 8'h00},
        '{op: uSUB,   ent: 8'h00},
        '{op: uINC,   ent: 8'h00},
        '{op: uLOAD,  ent: 8'hDA},
        '{op: uXOR,   ent: 8'h00},
        '{op: uNEG,   ent: 8'h00},
        '{op: uCLEAR, ent: 8'h00},
        '{op: uUP,    ent: 8'h00}
    };
    
    always #5ns clock = ~clock;

    initial begin
        reset = 1'b1;
        #3ns;
        reset = 1'b0;
    end

    calculadora DUT (
        .reset  (reset),
        .clock  (clock),
        .opmode (opmode),
        .din    (din),
        .saida  (saida),
        .z      (z)
    );

    initial begin
        #14ns;

        foreach (teste_pr[i]) begin
            opmode = teste_pr[i].op;
            din    = teste_pr[i].ent;
            #10ns;
        end

        #10ns;

        $finish;
    end

endmodule